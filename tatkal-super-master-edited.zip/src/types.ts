export type PageView = 
  | 'home'
  | 'tatkal-software'
  | 'vps-hosting'
  | 'ip-services'
  | 'about-us'
  | 'contact'
  | 'payment'
  | 'dashboard'
  | 'admin'
  | 'reseller'
  | 'order-tracking'
  | 'cart';

export type Currency = 'INR' | 'USD';

export type BillingCycle = 'monthly' | 'quarterly' | 'yearly' | 'lifetime';

export type ServiceCategory = 
  | 'tatkal-software'
  | 'windows-vps'
  | 'linux-vps'
  | 'dedicated-server'
  | 'residential-ip'
  | 'static-ip'
  | 'datacenter-proxy'
  | 'rdp';

export type DigitalDeliveryType = 
  | 'software_license'
  | 'vps_server'
  | 'proxy_credentials'
  | 'dedicated_server';

export type ServerTypeKey = 'normal' | 'gold' | 'diamond';

export interface VpsCategoryPlan {
  id: string;
  serverType: ServerTypeKey; // 'normal' | 'gold' | 'diamond'
  categoryName: string; // 'Normal' | 'Gold Server' | 'Diamond Pro AMD'
  ram: string; // '4 GB' | '8 GB' | '16 GB' | '32 GB'
  priceINR: number;
  priceUSD: number;
  vCpu: string;
  nvme: string;
  bandwidth: string;
  popular?: boolean;
  isActive: boolean;
}

export interface VpsServerCategoryMeta {
  id: string;
  serverType: ServerTypeKey;
  categoryName: string;
  displayName: string;
  badge: string; // e.g. "GOLD SERVER 3.0GHz", "DIAMOND PRO AMD 3.1GHz"
  premiumColor: 'gold' | 'diamond' | 'blue';
  clockSpeed?: string;
  description: string;
  allowedRams: string[];
  isActive: boolean;
}

export interface VpsPricingTier {
  ram: string; // '4 GB' | '8 GB' | '16 GB' | '32 GB'
  priceINR: number;
  priceUSD: number;
  vCpu: string;
  nvme: string;
  bandwidth: string;
  popular?: boolean;
}

export interface VpsInventoryItem {
  _id?: string;
  serverId: string;
  ipRange: string;
  serverLabel: string;
  availableStock: number;
  status: 'active' | 'out_of_stock' | 'maintenance' | 'reserved';
  category: string;
  planType: '4GB' | '8GB' | '16GB' | '32GB' | 'custom' | string;
  location: string;
  cpu: string;
  ram: string;
  storage: string;
  bandwidth: string;
  isActive: boolean;
  basePriceINR?: number;
  createdAt?: string;
  updatedAt?: string;
}

export interface PlanItem {
  id: string;
  name: string;
  category: ServiceCategory;
  tagline: string;
  popular?: boolean;
  featured?: boolean;
  priceINR: number;
  priceUSD: number;
  originalPriceINR?: number;
  period: string; // e.g. '/month' or '/license'
  specs: {
    label: string;
    value: string;
    iconName?: string;
  }[];
  features: string[];
  badge?: string;
  stockStatus: 'in-stock' | 'low-stock' | 'instant' | 'out-of-stock';
  stockQuantity: number;
  minStockAlert?: number;
  activationTime: string;
  location?: string;
  digitalDeliveryType?: DigitalDeliveryType;
  downloadUrl?: string;
  deliveryNotes?: string;
  isActive?: boolean;
  inventoryItem?: VpsInventoryItem;
  selectedRam?: string;
}

export interface User {
  id: string;
  name: string;
  email: string;
  phone: string;
  role: 'customer' | 'admin' | 'reseller';
  joinedDate: string;
  walletBalance: number;
  avatar?: string;
  isReseller?: boolean;
  resellerDiscount?: number; // percentage, e.g. 30
  resellerTier?: 'silver' | 'gold' | 'platinum';
  resellerAgencyName?: string;
  resellerApiKey?: string;
}

export interface ActiveService {
  id: string;
  serviceName: string;
  category: ServiceCategory;
  planId: string;
  ipAddress?: string;
  username?: string;
  password?: string;
  port?: number;
  status: 'active' | 'suspended' | 'provisioning' | 'rebooting';
  expiryDate: string;
  renewalPriceINR: number;
  location: string;
  os?: string;
  licenseKey?: string;
  downloadUrl?: string;
  proxyFormat?: string; // ip:port:user:pass
  deliveryEmailSent?: boolean;
  usageStats?: {
    cpuUsage: number;
    ramUsage: number;
    bandwidthGB: number;
    maxBandwidthGB: number;
  };
}

export interface DeliveryLog {
  id: string;
  orderId: string;
  timestamp: string;
  channel: 'email' | 'telegram' | 'sms' | 'dashboard';
  recipient: string;
  status: 'delivered' | 'pending' | 'failed';
  contentPreview: string;
}

export interface PaymentVerificationRequest {
  id: string;
  orderId: string;
  orderNumber: string;
  customerName: string;
  customerEmail: string;
  customerPhone: string;
  planName: string;
  amount: number;
  currency: Currency;
  upiId: string; // 'abhishekrajbha@ybl'
  utrNumber: string;
  screenshotUrl: string;
  submittedAt: string;
  status: 'pending' | 'approved' | 'rejected';
  adminNotes?: string;
  verifiedAt?: string;
  verifiedBy?: string;
}

export interface Order {
  id: string;
  orderNumber: string;
  date: string;
  customerName: string;
  customerEmail: string;
  customerPhone: string;
  items: {
    planId: string;
    planName: string;
    category: ServiceCategory;
    price: number;
    quantity: number;
    billingCycle: BillingCycle;
    configuredOptions?: Record<string, string>;
  }[];
  subtotal: number;
  discount: number;
  tax: number;
  total: number;
  currency: Currency;
  paymentMethod: 'upi' | 'razorpay' | 'phonepe' | 'cashfree' | 'payu' | 'qr-code' | 'wallet' | 'card';
  paymentStatus: 'paid' | 'pending' | 'failed' | 'pending_verification' | 'rejected';
  fulfillmentStatus: 'active' | 'processing' | 'delivered';
  transactionId: string;
  utrNumber?: string;
  upiId?: string;
  paymentScreenshot?: string;
  rejectionReason?: string;
  razorpayPaymentId?: string;
  razorpayOrderId?: string;
  couponApplied?: string;
  provisionedCredentials?: {
    ip?: string;
    username?: string;
    password?: string;
    port?: number;
    licenseKey?: string;
    downloadLink?: string;
    proxyString?: string;
    guideUrl?: string;
  };
  deliveryLogs?: DeliveryLog[];
  trackingTimeline: {
    step: string;
    timestamp: string;
    completed: boolean;
    description: string;
  }[];
}

export interface PaymentRecord {
  id: string;
  orderId: string;
  orderNumber: string;
  customerName: string;
  customerEmail: string;
  gateway: 'razorpay' | 'phonepe' | 'cashfree' | 'payu' | 'upi_qr' | 'wallet';
  gatewayTransactionId: string;
  amount: number;
  currency: Currency;
  status: 'captured' | 'authorized' | 'failed' | 'refunded';
  createdAt: string;
  methodDetails: string;
}

export interface TicketMessage {
  id: string;
  senderId: string;
  senderName: string;
  senderRole: 'customer' | 'admin' | 'agent';
  message: string;
  timestamp: string;
}

export interface SupportTicket {
  id: string;
  ticketNumber: string;
  userId: string;
  userName: string;
  userEmail: string;
  department: 'tatkal-software' | 'vps-hosting' | 'ip-proxies' | 'billing' | 'reseller';
  priority: 'urgent' | 'high' | 'normal';
  subject: string;
  status: 'open' | 'in_progress' | 'resolved' | 'closed';
  createdAt: string;
  updatedAt: string;
  messages: TicketMessage[];
}

export interface ResellerWholesaleOrder {
  id: string;
  resellerId: string;
  productName: string;
  quantity: number;
  totalDeducted: number;
  generatedKeys: string[];
  clientLabel?: string;
  date: string;
}

export interface ResellerWalletTx {
  id: string;
  resellerId: string;
  amount: number;
  type: 'credit' | 'debit';
  bonusAmount?: number;
  description: string;
  paymentGateway?: string;
  date: string;
  status: 'completed' | 'pending';
}

export interface Coupon {
  code: string;
  discountPercentage: number;
  maxDiscountINR?: number;
  minOrderValueINR?: number;
  description: string;
  isActive: boolean;
  usesCount?: number;
}

export interface Testimonial {
  id: string;
  name: string;
  role: string;
  location: string;
  rating: number;
  comment: string;
  avatar: string;
  verifiedPurchase: string;
  date: string;
}

export interface FaqItem {
  id: string;
  question: string;
  answer: string;
  category: 'general' | 'tatkal-software' | 'vps-hosting' | 'ip-services' | 'payment-delivery' | 'reseller';
}

export interface DatacenterNode {
  id: string;
  city: string;
  country: string;
  latencyMs: number;
  status: 'optimal' | 'operational';
  bandwidthGbps: number;
  coordinates: { x: number; y: number }; // percentage on map
}
