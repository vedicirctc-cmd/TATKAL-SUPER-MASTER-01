import React, { createContext, useContext, useState, useEffect } from 'react';
import { 
  PageView, 
  Currency, 
  PlanItem, 
  User, 
  Order, 
  ActiveService, 
  Coupon,
  SupportTicket,
  PaymentRecord,
  ResellerWalletTx,
  ResellerWholesaleOrder,
  DeliveryLog,
  VpsInventoryItem,
  VpsPricingTier,
  VpsCategoryPlan,
  VpsServerCategoryMeta,
  PaymentVerificationRequest
} from '../types';
import { 
  PLANS_DATA, 
  INITIAL_ORDERS, 
  INITIAL_SERVICES, 
  COUPONS_DATA, 
  INITIAL_PAYMENTS, 
  INITIAL_TICKETS,
  INITIAL_RESELLER_TX,
  INITIAL_RESELLER_ORDERS
} from '../data/mockData';
import { inventoryDb, getServerTypeFromItem } from '../data/inventoryDb';
import confetti from 'canvas-confetti';

interface Toast {
  id: string;
  type: 'success' | 'info' | 'error' | 'warning';
  title: string;
  message: string;
}

interface AppContextType {
  currentPage: PageView;
  setCurrentPage: (page: PageView) => void;
  currency: Currency;
  setCurrency: (c: Currency) => void;
  formatPrice: (inr: number, usd?: number) => string;
  
  // Auth
  user: User | null;
  login: (email: string, role?: 'customer' | 'admin' | 'reseller') => void;
  logout: () => void;
  register: (name: string, email: string, phone: string, isReseller?: boolean) => void;
  switchRole: (role: 'customer' | 'admin' | 'reseller') => void;
  isAuthModalOpen: boolean;
  setIsAuthModalOpen: (open: boolean) => void;
  authModalMode: 'login' | 'register';
  setAuthModalMode: (mode: 'login' | 'register') => void;

  // VPS Inventory System (MongoDB collection: inventory)
  inventory: VpsInventoryItem[];
  vpsPricingTiers: VpsPricingTier[];
  categoryPlans: VpsCategoryPlan[];
  serverCategories: VpsServerCategoryMeta[];
  addInventoryItem: (item: Omit<VpsInventoryItem, '_id'> & { _id?: string }) => void;
  updateInventoryItem: (id: string, updates: Partial<VpsInventoryItem>) => void;
  deleteInventoryItem: (id: string) => void;
  updateInventoryStock: (id: string, newStock: number) => void;
  toggleInventoryActive: (id: string) => void;
  bulkImportInventory: (rawText: string) => { importedCount: number; errors: string[] };
  updateVpsPricingTier: (ram: string, newPriceINR: number) => void;
  updateCategoryPlan: (id: string, updates: Partial<VpsCategoryPlan>) => void;
  addCategoryPlan: (plan: Omit<VpsCategoryPlan, 'id'>) => void;
  deleteCategoryPlan: (id: string) => void;
  toggleCategoryPlanActive: (id: string) => void;
  updateServerCategory: (id: string, updates: Partial<VpsServerCategoryMeta>) => void;
  getPlansForServer: (item: VpsInventoryItem) => VpsCategoryPlan[];
  getStartingPriceForServer: (item: VpsInventoryItem) => number;
  openCheckoutWithInventory: (inventoryItem: VpsInventoryItem, selectedRam: string) => void;
  resetInventoryToDefaults: () => void;

  // Products & Stock Management
  products: PlanItem[];
  addProduct: (product: Partial<PlanItem>) => void;
  updateProduct: (id: string, updates: Partial<PlanItem>) => void;
  deleteProduct: (id: string) => void;
  updateProductStock: (id: string, newStock: number) => void;

  // Checkout & Cart
  selectedPlanForCheckout: PlanItem | null;
  openCheckout: (plan: PlanItem) => void;
  closeCheckout: () => void;
  isCheckoutOpen: boolean;
  coupons: Coupon[];
  appliedCoupon: Coupon | null;
  applyCoupon: (code: string) => { success: boolean; message: string };
  removeCoupon: () => void;
  calculateDiscount: (amount: number) => number;
  addCoupon: (coupon: Coupon) => void;
  deleteCoupon: (code: string) => void;
  
  // Order & Payment Processing
  completeOrder: (paymentDetails: {
    method: 'upi' | 'razorpay' | 'phonepe' | 'cashfree' | 'payu' | 'qr-code' | 'wallet' | 'card';
    customerName: string;
    customerEmail: string;
    customerPhone: string;
    gatewayTransactionId?: string;
    customOptions?: Record<string, string>;
  }) => Order;

  // Manual Payment Verification Pipeline (UPI: abhishekrajbha@ybl)
  paymentVerifications: PaymentVerificationRequest[];
  submitPaymentVerification: (data: {
    orderId?: string;
    orderNumber?: string;
    customerName: string;
    customerEmail: string;
    customerPhone: string;
    planName: string;
    amount: number;
    upiId: string;
    utrNumber: string;
    screenshotUrl: string;
    adminNotes?: string;
  }) => PaymentVerificationRequest;
  approvePaymentVerification: (verificationId: string, adminNotes?: string) => void;
  rejectPaymentVerification: (verificationId: string, reason: string) => void;
  updatePaymentScreenshot: (orderId: string, screenshotUrl: string, utrNumber: string) => void;
  createOrderWithManualPayment: (data: {
    plan: PlanItem;
    customerName: string;
    customerEmail: string;
    customerPhone: string;
    utrNumber: string;
    screenshotUrl: string;
    customOptions?: Record<string, string>;
  }) => Order;

  // Payments Ledger
  payments: PaymentRecord[];

  // Orders & Tracking
  orders: Order[];
  activeServices: ActiveService[];
  selectedOrderForInvoice: Order | null;
  setSelectedOrderForInvoice: (order: Order | null) => void;
  trackOrderNumber: string;
  setTrackOrderNumber: (num: string) => void;
  
  // Service management actions
  rebootService: (serviceId: string) => void;
  selectedServiceForConsole: ActiveService | null;
  setSelectedServiceForConsole: (srv: ActiveService | null) => void;

  // Support Tickets System
  tickets: SupportTicket[];
  createTicket: (department: SupportTicket['department'], priority: SupportTicket['priority'], subject: string, initialMessage: string) => SupportTicket;
  replyTicket: (ticketId: string, message: string, senderRole?: 'customer' | 'admin' | 'agent') => void;
  updateTicketStatus: (ticketId: string, status: SupportTicket['status']) => void;

  // Reseller System
  resellerTx: ResellerWalletTx[];
  resellerOrders: ResellerWholesaleOrder[];
  resellerTransactions: ResellerWalletTx[];
  resellerWholesaleOrders: ResellerWholesaleOrder[];
  rechargeResellerWallet: (amount: number, gateway: string) => void;
  purchaseResellerBulk: (planId: string, quantity: number, clientLabel?: string) => { success: boolean; keys: string[]; order: ResellerWholesaleOrder } & ResellerWholesaleOrder;
  updateResellerSettings: (agencyName: string, apiKey: string) => void;

  // Demo Modal
  isDemoModalOpen: boolean;
  setIsDemoModalOpen: (open: boolean) => void;

  // Toasts
  toasts: Toast[];
  addToast: (type: 'success' | 'info' | 'error' | 'warning', title: string, message: string) => void;
  removeToast: (id: string) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentPage, setCurrentPage] = useState<PageView>('home');
  const [currency, setCurrency] = useState<Currency>('INR');
  
  // Auth state
  const [user, setUser] = useState<User | null>(() => {
    const saved = localStorage.getItem('tsm_user');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch {
        // fallback
      }
    }
    return {
      id: 'usr-901',
      name: 'Rahul Verma',
      email: 'rahul.verma@example.com',
      phone: '+91 98765 43210',
      role: 'customer',
      joinedDate: '2026-06-15',
      walletBalance: 2500,
      isReseller: true,
      resellerTier: 'gold',
      resellerDiscount: 30,
      resellerAgencyName: 'Verma High-Speed Tatkal Solutions',
      resellerApiKey: 'tsm_live_sec_99a820b41c9f7a01',
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80'
    };
  });

  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [authModalMode, setAuthModalMode] = useState<'login' | 'register'>('login');

  // VPS Inventory State (MongoDB collection: inventory)
  const [inventory, setInventory] = useState<VpsInventoryItem[]>(() => {
    return inventoryDb.getInventory();
  });

  const [vpsPricingTiers, setVpsPricingTiers] = useState<VpsPricingTier[]>(() => {
    return inventoryDb.getPricingTiers();
  });

  const [categoryPlans, setCategoryPlans] = useState<VpsCategoryPlan[]>(() => {
    return inventoryDb.getCategoryPlans();
  });

  const [serverCategories, setServerCategories] = useState<VpsServerCategoryMeta[]>(() => {
    return inventoryDb.getServerCategories();
  });

  // Products state (Stock management)
  const [products, setProducts] = useState<PlanItem[]>(() => {
    const saved = localStorage.getItem('tsm_products');
    return saved ? JSON.parse(saved) : PLANS_DATA;
  });

  // Coupons
  const [coupons, setCoupons] = useState<Coupon[]>(() => {
    const saved = localStorage.getItem('tsm_coupons');
    return saved ? JSON.parse(saved) : COUPONS_DATA;
  });
  const [appliedCoupon, setAppliedCoupon] = useState<Coupon | null>(null);

  // Checkout state
  const [selectedPlanForCheckout, setSelectedPlanForCheckout] = useState<PlanItem | null>(null);
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);

  // Orders and Services
  const [orders, setOrders] = useState<Order[]>(() => {
    const saved = localStorage.getItem('tsm_orders');
    return saved ? JSON.parse(saved) : INITIAL_ORDERS;
  });

  const [activeServices, setActiveServices] = useState<ActiveService[]>(() => {
    const saved = localStorage.getItem('tsm_services');
    return saved ? JSON.parse(saved) : INITIAL_SERVICES;
  });

  // Payments Ledger
  const [payments, setPayments] = useState<PaymentRecord[]>(() => {
    const saved = localStorage.getItem('tsm_payments');
    return saved ? JSON.parse(saved) : INITIAL_PAYMENTS;
  });

  // Tickets
  const [tickets, setTickets] = useState<SupportTicket[]>(() => {
    const saved = localStorage.getItem('tsm_tickets');
    return saved ? JSON.parse(saved) : INITIAL_TICKETS;
  });

  // Reseller transactions and bulk orders
  const [resellerTx, setResellerTx] = useState<ResellerWalletTx[]>(() => {
    const saved = localStorage.getItem('tsm_reseller_tx');
    return saved ? JSON.parse(saved) : INITIAL_RESELLER_TX;
  });

  const [resellerOrders, setResellerOrders] = useState<ResellerWholesaleOrder[]>(() => {
    const saved = localStorage.getItem('tsm_reseller_orders');
    return saved ? JSON.parse(saved) : INITIAL_RESELLER_ORDERS;
  });

  // Manual Payment Verifications Pipeline (UPI ID: abhishekrajbha@ybl)
  const [paymentVerifications, setPaymentVerifications] = useState<PaymentVerificationRequest[]>(() => {
    const saved = localStorage.getItem('tsm_payment_verifications');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch {
        // fallback
      }
    }
    return [
      {
        id: 'VERIF-9821',
        orderId: 'ord-88912',
        orderNumber: 'TSM-2026-88912',
        customerName: 'Rahul Verma',
        customerEmail: 'rahul.verma@example.com',
        customerPhone: '+91 98765 43210',
        planName: 'Tatkal Super Master PRO (6 Slots)',
        amount: 999,
        currency: 'INR',
        upiId: 'abhishekrajbha@ybl',
        utrNumber: '423589214782',
        screenshotUrl: 'https://images.unsplash.com/photo-1554224155-8d04cb21cd6c?w=600&auto=format&fit=crop&q=80',
        submittedAt: '2026-08-22 18:40:12',
        status: 'pending',
        adminNotes: 'Awaiting bank terminal UTR match'
      },
      {
        id: 'VERIF-9820',
        orderId: 'ord-88913',
        orderNumber: 'TSM-2026-88913',
        customerName: 'Vikram Joshi',
        customerEmail: 'vikram.j@example.com',
        customerPhone: '+91 98112 34567',
        planName: 'Diamond Pro AMD (16 GB NVMe)',
        amount: 2799,
        currency: 'INR',
        upiId: 'abhishekrajbha@ybl',
        utrNumber: '423577189021',
        screenshotUrl: 'https://images.unsplash.com/photo-1563986768609-322da13575f3?w=600&auto=format&fit=crop&q=80',
        submittedAt: '2026-08-22 16:15:00',
        status: 'approved',
        adminNotes: 'Verified on YBL merchant portal. VPS deployed instantly.',
        verifiedAt: '2026-08-22 16:18:22',
        verifiedBy: 'Senior NOC Admin'
      }
    ];
  });

  const [selectedOrderForInvoice, setSelectedOrderForInvoice] = useState<Order | null>(null);
  const [trackOrderNumber, setTrackOrderNumber] = useState<string>('');
  const [selectedServiceForConsole, setSelectedServiceForConsole] = useState<ActiveService | null>(null);
  const [isDemoModalOpen, setIsDemoModalOpen] = useState(false);

  // Toasts
  const [toasts, setToasts] = useState<Toast[]>([]);

  // Sync with LocalStorage
  useEffect(() => {
    if (user) {
      localStorage.setItem('tsm_user', JSON.stringify(user));
    }
  }, [user]);

  useEffect(() => {
    localStorage.setItem('tsm_products', JSON.stringify(products));
  }, [products]);

  useEffect(() => {
    localStorage.setItem('tsm_orders', JSON.stringify(orders));
  }, [orders]);

  useEffect(() => {
    localStorage.setItem('tsm_services', JSON.stringify(activeServices));
  }, [activeServices]);

  useEffect(() => {
    localStorage.setItem('tsm_payments', JSON.stringify(payments));
  }, [payments]);

  useEffect(() => {
    localStorage.setItem('tsm_payment_verifications', JSON.stringify(paymentVerifications));
  }, [paymentVerifications]);

  useEffect(() => {
    localStorage.setItem('tsm_tickets', JSON.stringify(tickets));
  }, [tickets]);

  useEffect(() => {
    localStorage.setItem('tsm_coupons', JSON.stringify(coupons));
  }, [coupons]);

  useEffect(() => {
    localStorage.setItem('tsm_reseller_tx', JSON.stringify(resellerTx));
  }, [resellerTx]);

  useEffect(() => {
    localStorage.setItem('tsm_reseller_orders', JSON.stringify(resellerOrders));
  }, [resellerOrders]);

  const addToast = (type: 'success' | 'info' | 'error' | 'warning', title: string, message: string) => {
    const id = Math.random().toString(36).substring(2, 9);
    setToasts(prev => [...prev, { id, type, title, message }]);
    setTimeout(() => {
      removeToast(id);
    }, 5000);
  };

  const removeToast = (id: string) => {
    setToasts(prev => prev.filter(t => t.id !== id));
  };

  const formatPrice = (inr: number, usd?: number) => {
    if (currency === 'USD') {
      const u = usd !== undefined ? usd : Math.round(inr / 85);
      return `$${u}`;
    }
    return `₹${inr.toLocaleString('en-IN')}`;
  };

  const login = (email: string, role: 'customer' | 'admin' | 'reseller' = 'customer') => {
    const newUser: User = {
      id: 'usr-' + Math.floor(100 + Math.random() * 900),
      name: email.split('@')[0].replace('.', ' ').toUpperCase(),
      email,
      phone: '+91 98765 43210',
      role,
      joinedDate: '2026-08-22',
      walletBalance: role === 'reseller' ? 8500 : 2000,
      isReseller: role === 'reseller',
      resellerTier: 'gold',
      resellerDiscount: 30,
      resellerAgencyName: role === 'reseller' ? `${email.split('@')[0].toUpperCase()} Tatkal Agency` : undefined,
      resellerApiKey: role === 'reseller' ? `tsm_live_${Math.random().toString(36).substring(2, 12)}` : undefined,
      avatar: role === 'admin' 
        ? 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80'
        : 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80'
    };
    setUser(newUser);
    setIsAuthModalOpen(false);
    addToast('success', 'Logged in successfully', `Welcome back, ${newUser.name}!`);
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('tsm_user');
    addToast('info', 'Logged out', 'You have been safely signed out.');
    if (currentPage === 'dashboard' || currentPage === 'admin' || currentPage === 'reseller') {
      setCurrentPage('home');
    }
  };

  const register = (name: string, email: string, phone: string, isReseller = false) => {
    const newUser: User = {
      id: 'usr-' + Math.floor(100 + Math.random() * 900),
      name,
      email,
      phone,
      role: isReseller ? 'reseller' : 'customer',
      joinedDate: '2026-08-22',
      walletBalance: isReseller ? 5000 : 500, // Welcome credit
      isReseller,
      resellerTier: isReseller ? 'silver' : undefined,
      resellerDiscount: isReseller ? 25 : undefined,
      resellerAgencyName: isReseller ? `${name} Travels & IT` : undefined,
      resellerApiKey: isReseller ? `tsm_live_${Math.random().toString(36).substring(2, 14)}` : undefined,
      avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80'
    };
    setUser(newUser);
    setIsAuthModalOpen(false);
    addToast('success', 'Account Registered!', isReseller ? 'Reseller Portal unlocked with ₹5000 demo credit!' : 'Welcome! ₹500 welcome credit added.');
  };

  const switchRole = (role: 'customer' | 'admin' | 'reseller') => {
    if (user) {
      const updated: User = { 
        ...user, 
        role,
        isReseller: role === 'reseller' || user.isReseller,
        resellerDiscount: user.resellerDiscount || 30
      };
      setUser(updated);
      addToast('info', 'Mode Switched', `Active view changed to ${role.toUpperCase()}`);
      if (role === 'admin') setCurrentPage('admin');
      else if (role === 'reseller') setCurrentPage('reseller');
      else setCurrentPage('dashboard');
    }
  };

  // Product Management (Stock system)
  const addProduct = (newProd: Partial<PlanItem>) => {
    const id = newProd.id || 'prod-' + Math.random().toString(36).substring(2, 8);
    const item: PlanItem = {
      id,
      name: newProd.name || 'New Service Plan',
      category: newProd.category || 'tatkal-software',
      tagline: newProd.tagline || 'High-performance automation service',
      priceINR: Number(newProd.priceINR) || 499,
      priceUSD: Number(newProd.priceUSD) || 9,
      originalPriceINR: Number(newProd.originalPriceINR) || 999,
      period: newProd.period || '/month',
      stockStatus: (newProd.stockQuantity && newProd.stockQuantity > 0) ? 'in-stock' : 'out-of-stock',
      stockQuantity: newProd.stockQuantity !== undefined ? Number(newProd.stockQuantity) : 50,
      minStockAlert: newProd.minStockAlert || 5,
      activationTime: newProd.activationTime || 'Instant (< 60s)',
      badge: newProd.badge,
      location: newProd.location || 'Mumbai Datacenter',
      digitalDeliveryType: newProd.digitalDeliveryType || 'software_license',
      downloadUrl: newProd.downloadUrl || 'https://downloads.tatkalsupermaster.com/v4.8/TSM_Pro_Setup.exe',
      deliveryNotes: newProd.deliveryNotes || 'Instant auto-delivery upon payment',
      isActive: true,
      specs: newProd.specs || [
        { label: 'Speed', value: 'Ultra Fast <0.5s' },
        { label: 'Uptime', value: '99.99% SLA' }
      ],
      features: newProd.features || [
        'Instant Activation',
        '24/7 Priority Support',
        'Automatic Updates'
      ]
    };

    setProducts(prev => [item, ...prev]);
    addToast('success', 'Product Added', `${item.name} has been created and listed with ${item.stockQuantity} in stock.`);
  };

  const updateProduct = (id: string, updates: Partial<PlanItem>) => {
    setProducts(prev => prev.map(p => {
      if (p.id === id) {
        const merged = { ...p, ...updates };
        if (merged.stockQuantity !== undefined) {
          if (merged.stockQuantity <= 0) merged.stockStatus = 'out-of-stock';
          else if (merged.minStockAlert && merged.stockQuantity <= merged.minStockAlert) merged.stockStatus = 'low-stock';
          else merged.stockStatus = 'in-stock';
        }
        return merged;
      }
      return p;
    }));
    addToast('info', 'Product Updated', 'Product specifications and inventory updated successfully.');
  };

  const deleteProduct = (id: string) => {
    setProducts(prev => prev.filter(p => p.id !== id));
    addToast('info', 'Product Removed', 'Product has been removed from catalog.');
  };

  const updateProductStock = (id: string, newStock: number) => {
    updateProduct(id, { stockQuantity: newStock });
  };

  // ==========================================
  // VPS INVENTORY CRUD & SYSTEM (MongoDB: inventory)
  // ==========================================
  const addInventoryItem = (item: Omit<VpsInventoryItem, '_id'> & { _id?: string }) => {
    const inserted = inventoryDb.insertOne(item);
    setInventory(inventoryDb.getInventory());
    addToast('success', 'Inventory Added', `Node ${inserted.ipRange} (${inserted.availableStock} in stock) added to MongoDB inventory.`);
  };

  const updateInventoryItem = (id: string, updates: Partial<VpsInventoryItem>) => {
    const updated = inventoryDb.updateOne(id, updates);
    if (updated) {
      setInventory(inventoryDb.getInventory());
      addToast('info', 'Inventory Updated', `Node ${updated.ipRange} updated. Stock: ${updated.availableStock}.`);
    }
  };

  const deleteInventoryItem = (id: string) => {
    const ok = inventoryDb.deleteOne(id);
    if (ok) {
      setInventory(inventoryDb.getInventory());
      addToast('info', 'Inventory Deleted', 'Server node deleted from MongoDB inventory.');
    }
  };

  const updateInventoryStock = (id: string, newStock: number) => {
    const updated = inventoryDb.updateOne(id, { availableStock: Math.max(0, newStock) });
    if (updated) {
      setInventory(inventoryDb.getInventory());
      addToast('success', 'Stock Updated', `${updated.ipRange} stock set to ${updated.availableStock}.`);
    }
  };

  const toggleInventoryActive = (id: string) => {
    const item = inventory.find(i => i._id === id || i.serverId === id);
    if (item) {
      const updated = inventoryDb.updateOne(id, { isActive: !item.isActive });
      if (updated) {
        setInventory(inventoryDb.getInventory());
        addToast('info', 'Status Changed', `${updated.ipRange} is now ${updated.isActive ? 'Active' : 'Disabled'}.`);
      }
    }
  };

  const bulkImportInventory = (rawText: string) => {
    const result = inventoryDb.bulkImport(rawText);
    setInventory(inventoryDb.getInventory());
    if (result.importedCount > 0) {
      addToast('success', 'Bulk Import Successful', `Imported / Updated ${result.importedCount} nodes into MongoDB inventory collection.`);
    } else {
      addToast('warning', 'Bulk Import', 'No valid inventory nodes found in input.');
    }
    return result;
  };

  const updateVpsPricingTier = (ram: string, newPriceINR: number) => {
    const tiers = vpsPricingTiers.map(t => {
      if (t.ram === ram) {
        return {
          ...t,
          priceINR: newPriceINR,
          priceUSD: Math.round(newPriceINR / 75)
        };
      }
      return t;
    });
    inventoryDb.savePricingTiers(tiers);
    setVpsPricingTiers(tiers);
    addToast('success', 'Pricing Updated', `VPS Linux ${ram} plan price updated to ₹${newPriceINR.toLocaleString('en-IN')}/mo.`);
  };

  // Category-specific plans CRUD for MongoDB Dynamic Pricing
  const updateCategoryPlan = (id: string, updates: Partial<VpsCategoryPlan>) => {
    const updated = inventoryDb.updateCategoryPlan(id, updates);
    if (updated) {
      setCategoryPlans(inventoryDb.getCategoryPlans());
      addToast('success', 'Plan Updated', `${updated.categoryName} (${updated.ram}) price set to ₹${updated.priceINR.toLocaleString('en-IN')}/mo.`);
    }
  };

  const addCategoryPlan = (plan: Omit<VpsCategoryPlan, 'id'>) => {
    const created = inventoryDb.addCategoryPlan(plan);
    setCategoryPlans(inventoryDb.getCategoryPlans());
    addToast('success', 'Plan Added', `New ${created.categoryName} (${created.ram}) plan added at ₹${created.priceINR.toLocaleString('en-IN')}/mo.`);
  };

  const deleteCategoryPlan = (id: string) => {
    const deleted = inventoryDb.deleteCategoryPlan(id);
    if (deleted) {
      setCategoryPlans(inventoryDb.getCategoryPlans());
      addToast('info', 'Plan Deleted', 'Category plan removed from database.');
    }
  };

  const toggleCategoryPlanActive = (id: string) => {
    const toggled = inventoryDb.toggleCategoryPlanActive(id);
    if (toggled) {
      setCategoryPlans(inventoryDb.getCategoryPlans());
      addToast('info', 'Plan Status Changed', `${toggled.categoryName} (${toggled.ram}) is now ${toggled.isActive ? 'Enabled' : 'Disabled'}.`);
    }
  };

  const updateServerCategory = (id: string, updates: Partial<VpsServerCategoryMeta>) => {
    const updated = inventoryDb.updateServerCategory(id, updates);
    if (updated) {
      setServerCategories(inventoryDb.getServerCategories());
      addToast('success', 'Category Updated', `${updated.displayName} settings updated successfully.`);
    }
  };

  // Resolve active plans for a specific server node based on category
  const getPlansForServer = (item: VpsInventoryItem): VpsCategoryPlan[] => {
    const serverType = getServerTypeFromItem(item);
    const plans = categoryPlans.filter(p => p.serverType === serverType && p.isActive);
    if (plans.length > 0) return plans;

    // Fallback if no specific plans configured
    if (serverType === 'gold') {
      return [
        { id: 'fb-g8', serverType: 'gold', categoryName: 'Gold Server', ram: '8 GB', priceINR: 1500, priceUSD: 20, vCpu: '4 vCPU AMD Ryzen 9', nvme: '160 GB NVMe Gen4', bandwidth: '10 Gbps Dedicated Line', popular: true, isActive: true },
        { id: 'fb-g16', serverType: 'gold', categoryName: 'Gold Server', ram: '16 GB', priceINR: 2199, priceUSD: 29, vCpu: '8 vCPU AMD EPYC Genoa', nvme: '320 GB NVMe Gen4', bandwidth: '10 Gbps Dedicated Line', popular: false, isActive: true }
      ];
    } else if (serverType === 'diamond') {
      return [
        { id: 'fb-d16', serverType: 'diamond', categoryName: 'Diamond Pro AMD', ram: '16 GB', priceINR: 2799, priceUSD: 37, vCpu: '8 vCPU AMD EPYC + Ryzen 9', nvme: '320 GB NVMe Gen4', bandwidth: '10 Gbps Dedicated Line', popular: true, isActive: true },
        { id: 'fb-d32', serverType: 'diamond', categoryName: 'Diamond Pro AMD', ram: '32 GB', priceINR: 3199, priceUSD: 42, vCpu: '16 vCPU Dual Cluster', nvme: '640 GB NVMe Gen4', bandwidth: '10 Gbps Dedicated Line', popular: false, isActive: true }
      ];
    } else {
      return [
        { id: 'fb-n4', serverType: 'normal', categoryName: 'Normal', ram: '4 GB', priceINR: 700, priceUSD: 10, vCpu: '2 vCPU AMD EPYC', nvme: '80 GB NVMe Gen4', bandwidth: '10 Gbps Unmetered', popular: false, isActive: true },
        { id: 'fb-n8', serverType: 'normal', categoryName: 'Normal', ram: '8 GB', priceINR: 1399, priceUSD: 19, vCpu: '4 vCPU AMD EPYC', nvme: '160 GB NVMe Gen4', bandwidth: '10 Gbps Unmetered', popular: true, isActive: true },
        { id: 'fb-n16', serverType: 'normal', categoryName: 'Normal', ram: '16 GB', priceINR: 1799, priceUSD: 24, vCpu: '8 vCPU AMD Ryzen 9', nvme: '320 GB NVMe Gen4', bandwidth: '10 Gbps Unmetered', popular: false, isActive: true },
        { id: 'fb-n32', serverType: 'normal', categoryName: 'Normal', ram: '32 GB', priceINR: 2500, priceUSD: 34, vCpu: '16 vCPU Ryzen 9 PRO', nvme: '640 GB NVMe Gen4', bandwidth: '10 Gbps Unmetered', popular: false, isActive: true }
      ];
    }
  };

  const getStartingPriceForServer = (item: VpsInventoryItem): number => {
    const plans = getPlansForServer(item);
    if (plans.length === 0) {
      const serverType = getServerTypeFromItem(item);
      return serverType === 'diamond' ? 2799 : serverType === 'gold' ? 1500 : 700;
    }
    return Math.min(...plans.map(p => p.priceINR));
  };

  const openCheckoutWithInventory = (invItem: VpsInventoryItem, selectedRam: string) => {
    if (invItem.availableStock <= 0) {
      addToast('error', 'Out of Stock', `${invItem.ipRange} is currently sold out.`);
      return;
    }

    const serverType = getServerTypeFromItem(invItem);
    const availablePlans = getPlansForServer(invItem);
    
    // Find matching category plan for the server type and selected RAM
    let selectedPlan = availablePlans.find(p => p.ram.toLowerCase() === selectedRam.toLowerCase());
    if (!selectedPlan && availablePlans.length > 0) {
      selectedPlan = availablePlans[0];
    }

    const priceINR = selectedPlan ? selectedPlan.priceINR : 
      serverType === 'diamond' ? (selectedRam.includes('32') ? 3199 : 2799) :
      serverType === 'gold' ? (selectedRam.includes('16') ? 2199 : 1500) :
      (selectedRam.includes('32') ? 2500 : selectedRam.includes('16') ? 1799 : selectedRam.includes('8') ? 1399 : 700);

    const priceUSD = selectedPlan ? selectedPlan.priceUSD : Math.max(1, Math.round(priceINR / 75));
    const effectiveRam = selectedPlan ? selectedPlan.ram : selectedRam;
    const vCpu = selectedPlan ? selectedPlan.vCpu : invItem.cpu;
    const nvme = selectedPlan ? selectedPlan.nvme : invItem.storage;
    const bandwidth = selectedPlan ? selectedPlan.bandwidth : (invItem.bandwidth || '10 Gbps Unmetered');

    const isWindows = invItem.category.toLowerCase().includes('windows');
    const badgeText = serverType === 'diamond' 
      ? 'DIAMOND PRO AMD 3.1GHz' 
      : serverType === 'gold' 
      ? 'GOLD SERVER 3.0GHz' 
      : 'SUPER FAST 10GBPS';

    // Build plan representation for checkout
    const customPlan: PlanItem = {
      id: `vps-inv-${invItem.serverId}-${effectiveRam.replace(/\s+/g, '')}`,
      name: `${invItem.serverLabel} (${effectiveRam})`,
      category: isWindows ? 'windows-vps' : 'linux-vps',
      tagline: `IP Subnet: ${invItem.ipRange} • ${invItem.location} • Latency < 1.0ms`,
      priceINR: priceINR,
      priceUSD: priceUSD,
      originalPriceINR: Math.round(priceINR * 1.5),
      period: '/month',
      stockStatus: invItem.availableStock <= 0 ? 'out-of-stock' : invItem.availableStock < 20 ? 'low-stock' : 'in-stock',
      stockQuantity: invItem.availableStock,
      minStockAlert: 10,
      activationTime: 'Instant Hypervisor Provisioning (< 45s)',
      badge: badgeText,
      location: invItem.location,
      digitalDeliveryType: 'vps_server',
      deliveryNotes: `Instant automated provisioning on IP Subnet ${invItem.ipRange} with root/Administrator access.`,
      isActive: invItem.isActive,
      inventoryItem: invItem,
      selectedRam: effectiveRam,
      specs: [
        { label: 'Subnet IP Pool', value: `${invItem.ipRange}.x /24` },
        { label: 'RAM Memory', value: effectiveRam },
        { label: 'vCPU Cores', value: vCpu },
        { label: 'NVMe Storage', value: nvme },
        { label: 'Uplink Speed', value: bandwidth },
        { label: 'Datacenter', value: invItem.location }
      ],
      features: [
        `Guaranteed Subnet Allocation on ${invItem.ipRange}`,
        'Direct Tier-4 Equinix / CtrlS Datacenter Cross-Connect',
        'Instant Root SSH & RDP Console Access via Dashboard',
        'Anti-DDoS Scrubbing & Zero Packet Drop SLA',
        '1-Click OS Reinstall (Ubuntu 24.04, Debian 12, Windows Server 2022)',
        '24/7 Tatkal NOC Infrastructure Monitoring'
      ]
    };

    setSelectedPlanForCheckout(customPlan);
    setIsCheckoutOpen(true);
  };

  const resetInventoryToDefaults = () => {
    inventoryDb.resetToDefaults();
    setInventory(inventoryDb.getInventory());
    setCategoryPlans(inventoryDb.getCategoryPlans());
    setServerCategories(inventoryDb.getServerCategories());
    setVpsPricingTiers(inventoryDb.getPricingTiers());
    addToast('success', 'Database Reset', 'MongoDB inventory restored to initial 24 subnets and pricing rules (Normal, Gold Server, Diamond Pro AMD).');
  };

  // Coupons
  const applyCoupon = (code: string) => {
    const trimmed = code.trim().toUpperCase();
    const found = coupons.find(c => c.code.toUpperCase() === trimmed && c.isActive);
    if (!found) {
      return { success: false, message: 'Invalid or expired coupon code.' };
    }
    setAppliedCoupon(found);
    addToast('success', 'Coupon Applied!', `${found.discountPercentage}% discount added successfully.`);
    return { success: true, message: `Coupon applied: ${found.discountPercentage}% discount!` };
  };

  const removeCoupon = () => {
    setAppliedCoupon(null);
    addToast('info', 'Coupon Removed', 'Coupon discount has been removed.');
  };

  const calculateDiscount = (amount: number) => {
    if (!appliedCoupon) return 0;
    let disc = (amount * appliedCoupon.discountPercentage) / 100;
    if (appliedCoupon.maxDiscountINR && disc > appliedCoupon.maxDiscountINR) {
      disc = appliedCoupon.maxDiscountINR;
    }
    return Math.round(disc);
  };

  const addCoupon = (coupon: Coupon) => {
    setCoupons(prev => [coupon, ...prev]);
    addToast('success', 'Coupon Created', `Promo code ${coupon.code} (${coupon.discountPercentage}% OFF) is now live.`);
  };

  const deleteCoupon = (code: string) => {
    setCoupons(prev => prev.filter(c => c.code !== code));
    addToast('info', 'Coupon Deleted', `Promo code ${code} removed.`);
  };

  const openCheckout = (plan: PlanItem) => {
    setSelectedPlanForCheckout(plan);
    setIsCheckoutOpen(true);
  };

  const closeCheckout = () => {
    setIsCheckoutOpen(false);
  };

  // COMPLETE ORDER WITH AUTO STOCK REDUCTION & DIGITAL DELIVERY
  const completeOrder = (paymentDetails: {
    method: 'upi' | 'razorpay' | 'phonepe' | 'cashfree' | 'payu' | 'qr-code' | 'wallet' | 'card';
    customerName: string;
    customerEmail: string;
    customerPhone: string;
    gatewayTransactionId?: string;
    customOptions?: Record<string, string>;
  }): Order => {
    if (!selectedPlanForCheckout) {
      throw new Error('No plan selected');
    }

    const plan = selectedPlanForCheckout;

    // Check inventory stock if attached
    if (plan.inventoryItem) {
      const invCheck = inventoryDb.findOne({ _id: plan.inventoryItem._id, serverId: plan.inventoryItem.serverId });
      if (!invCheck || invCheck.availableStock <= 0) {
        throw new Error(`Sorry, server node ${plan.inventoryItem.ipRange} is currently Out of Stock.`);
      }
    } else {
      const currentProduct = products.find(p => p.id === plan.id);
      if (currentProduct && currentProduct.stockQuantity <= 0) {
        throw new Error('Sorry, this product is currently Out of Stock.');
      }
    }

    const basePrice = currency === 'USD' ? plan.priceUSD : plan.priceINR;
    const discount = calculateDiscount(basePrice);
    const total = Math.max(0, basePrice - discount);

    // If paid by wallet, ensure user has balance
    if (paymentDetails.method === 'wallet') {
      if (!user || user.walletBalance < total) {
        throw new Error('Insufficient wallet balance. Please top-up or choose UPI/Razorpay.');
      }
      setUser({ ...user, walletBalance: user.walletBalance - total });
    }

    // 1. AUTO REDUCE STOCK BY 1 IN MONGODB INVENTORY & PRODUCT STATE
    let remainingInventoryStock: number | null = null;
    if (plan.inventoryItem) {
      const decRes = inventoryDb.decrementStock(plan.inventoryItem._id || plan.inventoryItem.serverId, 1);
      if (decRes.success) {
        remainingInventoryStock = decRes.remainingStock;
        setInventory(inventoryDb.getInventory());
      }
    }

    const currentProduct = products.find(p => p.id === plan.id);
    if (currentProduct) {
      const newStock = Math.max(0, currentProduct.stockQuantity - 1);
      updateProductStock(currentProduct.id, newStock);
    }

    const orderNum = 'TSM-2026-' + Math.floor(10000 + Math.random() * 90000);
    const orderId = 'ord-' + Math.random().toString(36).substring(2, 9);
    const gatewayTxn = paymentDetails.gatewayTransactionId || 
      (paymentDetails.method === 'razorpay' ? 'pay_rzp_live_' + Math.random().toString(36).substring(2, 12) :
       paymentDetails.method === 'phonepe' ? 'T2608' + Math.floor(100000000 + Math.random() * 900000000) :
       paymentDetails.method === 'cashfree' ? 'cf_order_' + Math.random().toString(36).substring(2, 10) :
       'UPI-TXN-' + Math.floor(10000000000 + Math.random() * 90000000000));

    const now = new Date();
    const formattedDate = now.toISOString().split('T')[0];
    const formattedTime = now.toTimeString().split(' ')[0];

    // Auto-Generate Real Subnet IP for VPS or Proxy based on node
    let ipGenerated = `103.145.${Math.floor(40 + Math.random() * 180)}.${Math.floor(10 + Math.random() * 220)}`;
    if (plan.inventoryItem) {
      const rawSubnet = plan.inventoryItem.ipRange.replace(/[^0-9.]/g, '').replace(/\.+$/, '');
      const octetCount = rawSubnet.split('.').filter(Boolean).length;
      const lastHost = Math.floor(10 + Math.random() * 230);
      if (octetCount === 3) {
        ipGenerated = `${rawSubnet}.${lastHost}`;
      } else if (octetCount === 2) {
        ipGenerated = `${rawSubnet}.${Math.floor(10 + Math.random() * 200)}.${lastHost}`;
      } else if (octetCount === 1 && rawSubnet.length > 0) {
        ipGenerated = `${rawSubnet}.100.${Math.floor(10 + Math.random() * 200)}.${lastHost}`;
      }
    }

    const randomKey = `TSM-PRO-${Math.floor(1000 + Math.random() * 9000)}-${Math.random().toString(36).substring(2, 6).toUpperCase()}-9942-IN`;
    const randomPass = `TSM_${Math.random().toString(36).substring(2, 6)}#${Math.floor(1000 + Math.random() * 9000)}!`;

    const isSoftware = plan.category === 'tatkal-software';
    const isVps = plan.category.includes('vps') || plan.category === 'rdp' || plan.category === 'dedicated-server' || Boolean(plan.inventoryItem);
    const isProxy = plan.category.includes('ip') || plan.category === 'datacenter-proxy';

    const credentials = {
      ip: isVps || isProxy ? ipGenerated : undefined,
      username: isVps ? (plan.category === 'linux-vps' || !plan.category.includes('windows') ? 'root' : 'Administrator') : isProxy ? 'tsm_user' + Math.floor(10 + Math.random() * 90) : undefined,
      password: isVps || isProxy ? randomPass : undefined,
      port: isVps ? (plan.category === 'linux-vps' || !plan.category.includes('windows') ? 22 : 3389) : isProxy ? 8080 : undefined,
      licenseKey: isSoftware ? randomKey : undefined,
      downloadLink: isSoftware ? (plan.downloadUrl || 'https://downloads.tatkalsupermaster.com/v4.8/TSM_Pro_Setup.exe') : undefined,
      proxyString: isProxy ? `${ipGenerated}:8080:tsm_user99:${randomPass}` : undefined,
      guideUrl: 'https://tatkalsupermaster.com/docs/quickstart'
    };

    const deliveryLogs: DeliveryLog[] = [
      {
        id: 'del-' + Math.random().toString(36).substring(2, 7),
        orderId,
        timestamp: `${formattedDate} ${formattedTime}`,
        channel: 'email',
        recipient: paymentDetails.customerEmail,
        status: 'delivered',
        contentPreview: isSoftware 
          ? `License Key: ${randomKey} & Setup Download Link sent to inbox.`
          : `Server Access IP: ${ipGenerated} (${plan.inventoryItem ? plan.inventoryItem.ipRange : 'VPS'}) with RDP/SSH credentials.`
      },
      {
        id: 'del-' + Math.random().toString(36).substring(2, 7),
        orderId,
        timestamp: `${formattedDate} ${formattedTime}`,
        channel: 'telegram',
        recipient: paymentDetails.customerPhone,
        status: 'delivered',
        contentPreview: `Instant Telegram notification sent to ${paymentDetails.customerPhone}`
      },
      {
        id: 'del-' + Math.random().toString(36).substring(2, 7),
        orderId,
        timestamp: `${formattedDate} ${formattedTime}`,
        channel: 'dashboard',
        recipient: paymentDetails.customerEmail,
        status: 'delivered',
        contentPreview: `Service node mounted on ${ipGenerated} in Customer Dashboard.`
      }
    ];

    const newOrder: Order = {
      id: orderId,
      orderNumber: orderNum,
      date: formattedDate,
      customerName: paymentDetails.customerName || (user ? user.name : 'Valued Customer'),
      customerEmail: paymentDetails.customerEmail || (user ? user.email : 'customer@example.com'),
      customerPhone: paymentDetails.customerPhone || (user ? user.phone : '+91 98765 00000'),
      items: [
        {
          planId: plan.id,
          planName: plan.name,
          category: plan.category,
          price: basePrice,
          quantity: 1,
          billingCycle: 'monthly',
          configuredOptions: {
            ...paymentDetails.customOptions,
            ...(plan.selectedRam ? { RAM: plan.selectedRam } : {}),
            ...(plan.inventoryItem ? { 'Subnet Range': plan.inventoryItem.ipRange, Location: plan.inventoryItem.location } : {})
          }
        }
      ],
      subtotal: basePrice,
      discount: discount,
      tax: 0,
      total: total,
      currency: currency,
      paymentMethod: paymentDetails.method,
      paymentStatus: 'paid',
      fulfillmentStatus: 'delivered',
      transactionId: gatewayTxn,
      razorpayPaymentId: gatewayTxn,
      razorpayOrderId: 'order_rzp_' + Math.random().toString(36).substring(2, 10),
      couponApplied: appliedCoupon?.code,
      provisionedCredentials: credentials,
      deliveryLogs,
      trackingTimeline: [
        { step: 'Order Placed', timestamp: `${formattedDate} ${formattedTime}`, completed: true, description: 'Order registered in system' },
        { step: 'Razorpay / UPI Payment Verified', timestamp: `${formattedDate} ${formattedTime}`, completed: true, description: `${paymentDetails.method.toUpperCase()} verification approved (${gatewayTxn})` },
        { step: 'MongoDB Inventory Stock Reduced', timestamp: `${formattedDate} ${formattedTime}`, completed: true, description: `Stock updated (-1). Remaining stock: ${remainingInventoryStock !== null ? remainingInventoryStock : 'Synced'}` },
        { step: 'VPS Server Node Provisioned', timestamp: `${formattedDate} ${formattedTime}`, completed: true, description: `IP ${ipGenerated} assigned with root credentials` },
        { step: 'Delivered Instantly', timestamp: `${formattedDate} ${formattedTime}`, completed: true, description: 'Credentials dispatched to Dashboard & Telegram' }
      ]
    };

    // 2. Add to Orders
    setOrders(prev => [newOrder, ...prev]);

    // 3. Add to Payments Ledger
    const newPayment: PaymentRecord = {
      id: 'pay-' + Math.random().toString(36).substring(2, 8),
      orderId: newOrder.id,
      orderNumber: newOrder.orderNumber,
      customerName: newOrder.customerName,
      customerEmail: newOrder.customerEmail,
      gateway: paymentDetails.method === 'upi' || paymentDetails.method === 'qr-code' ? 'upi_qr' :
               paymentDetails.method === 'wallet' ? 'wallet' : 
               paymentDetails.method === 'phonepe' ? 'phonepe' :
               paymentDetails.method === 'cashfree' ? 'cashfree' :
               paymentDetails.method === 'payu' ? 'payu' : 'razorpay',
      gatewayTransactionId: gatewayTxn,
      amount: total,
      currency: currency,
      status: 'captured',
      createdAt: `${formattedDate} ${formattedTime}`,
      methodDetails: `${paymentDetails.method.toUpperCase()} Instant Payment via Razorpay Gateway`
    };
    setPayments(prev => [newPayment, ...prev]);

    // 4. Add to Active Services
    const expiryDate = new Date();
    expiryDate.setDate(expiryDate.getDate() + 30);

    const newService: ActiveService = {
      id: 'srv-' + Math.floor(100 + Math.random() * 900),
      serviceName: `${plan.name} (Active Node)`,
      category: plan.category,
      planId: plan.id,
      ipAddress: credentials.ip,
      username: credentials.username,
      password: credentials.password,
      port: credentials.port,
      licenseKey: credentials.licenseKey,
      downloadUrl: credentials.downloadLink,
      proxyFormat: credentials.proxyString,
      status: 'active',
      expiryDate: expiryDate.toISOString().split('T')[0],
      renewalPriceINR: plan.priceINR,
      location: plan.location || (plan.inventoryItem ? plan.inventoryItem.location : 'Mumbai CtrlS Datacenter'),
      os: plan.category.includes('win') ? 'Windows Server 2022' : 'Ubuntu 24.04 LTS',
      deliveryEmailSent: true,
      usageStats: {
        cpuUsage: 12 + Math.floor(Math.random() * 10),
        ramUsage: 22 + Math.floor(Math.random() * 15),
        bandwidthGB: 1.8,
        maxBandwidthGB: 1000
      }
    };
    setActiveServices(prev => [newService, ...prev]);

    // Celebrate
    try {
      confetti({
        particleCount: 100,
        spread: 70,
        origin: { y: 0.6 }
      });
    } catch {
      // ignore
    }

    const stockMsg = remainingInventoryStock !== null 
      ? `Stock remaining: ${remainingInventoryStock}` 
      : 'Stock updated';
    addToast('success', 'Order Placed & Node Provisioned!', `Order #${newOrder.orderNumber} fulfilled. IP: ${ipGenerated}. ${stockMsg}.`);
    setIsCheckoutOpen(false);
    setAppliedCoupon(null);
    return newOrder;
  };

  const rebootService = (serviceId: string) => {
    setActiveServices(prev => prev.map(s => {
      if (s.id === serviceId) {
        return { ...s, status: 'rebooting' };
      }
      return s;
    }));

    addToast('info', 'Reboot Initiated', 'Server hardware reboot signal sent. Restarting in ~20 seconds.');

    setTimeout(() => {
      setActiveServices(prev => prev.map(s => {
        if (s.id === serviceId) {
          return { ...s, status: 'active' };
        }
        return s;
      }));
      addToast('success', 'Server Online', 'Server has successfully rebooted and is accepting connections.');
    }, 3500);
  };

  // Support Tickets System
  const createTicket = (
    department: SupportTicket['department'], 
    priority: SupportTicket['priority'], 
    subject: string, 
    initialMessage: string
  ): SupportTicket => {
    const now = new Date();
    const formatted = now.toISOString().replace('T', ' ').substring(0, 19);
    const ticketId = 'tkt-' + Math.floor(100 + Math.random() * 900);
    const ticketNum = 'TSM-TK-' + Math.floor(1000 + Math.random() * 9000);

    const newTicket: SupportTicket = {
      id: ticketId,
      ticketNumber: ticketNum,
      userId: user?.id || 'usr-guest',
      userName: user?.name || 'Guest User',
      userEmail: user?.email || 'guest@example.com',
      department,
      priority,
      subject,
      status: 'open',
      createdAt: formatted,
      updatedAt: formatted,
      messages: [
        {
          id: 'msg-' + Math.random().toString(36).substring(2, 7),
          senderId: user?.id || 'usr-guest',
          senderName: user?.name || 'Customer',
          senderRole: 'customer',
          message: initialMessage,
          timestamp: formatted
        }
      ]
    };

    setTickets(prev => [newTicket, ...prev]);
    addToast('success', 'Ticket Created', `Support ticket #${ticketNum} submitted. Agent response time is <15 mins.`);
    return newTicket;
  };

  const replyTicket = (ticketId: string, message: string, senderRole: 'customer' | 'admin' | 'agent' = 'customer') => {
    const now = new Date();
    const formatted = now.toISOString().replace('T', ' ').substring(0, 19);

    setTickets(prev => prev.map(t => {
      if (t.id === ticketId) {
        const newMsg = {
          id: 'msg-' + Math.random().toString(36).substring(2, 7),
          senderId: user?.id || 'usr-901',
          senderName: senderRole === 'admin' ? 'Super Admin' : senderRole === 'agent' ? 'Support Engineer' : (user?.name || 'Customer'),
          senderRole,
          message,
          timestamp: formatted
        };
        return {
          ...t,
          status: senderRole === 'admin' || senderRole === 'agent' ? 'in_progress' : t.status,
          updatedAt: formatted,
          messages: [...t.messages, newMsg]
        };
      }
      return t;
    }));

    addToast('info', 'Reply Sent', 'Message appended to ticket discussion.');
  };

  const updateTicketStatus = (ticketId: string, status: SupportTicket['status']) => {
    setTickets(prev => prev.map(t => {
      if (t.id === ticketId) {
        return { ...t, status, updatedAt: new Date().toISOString().replace('T', ' ').substring(0, 19) };
      }
      return t;
    }));
    addToast('info', 'Status Updated', `Ticket marked as ${status.replace('_', ' ').toUpperCase()}`);
  };

  // Reseller System
  const rechargeResellerWallet = (amount: number, gateway: string) => {
    let bonus = 0;
    if (amount >= 20000) bonus = Math.round(amount * 0.10); // 10% bonus
    else if (amount >= 5000) bonus = Math.round(amount * 0.05); // 5% bonus

    const totalCredit = amount + bonus;
    if (user) {
      setUser({ ...user, walletBalance: (user.walletBalance || 0) + totalCredit });
    }

    const newTx: ResellerWalletTx = {
      id: 'tx-' + Math.random().toString(36).substring(2, 8),
      resellerId: user?.id || 'usr-901',
      amount,
      bonusAmount: bonus,
      type: 'credit',
      description: `Wallet Top-up via ${gateway} ${bonus > 0 ? `(+₹${bonus} Bonus Cash)` : ''}`,
      paymentGateway: gateway,
      date: new Date().toISOString().replace('T', ' ').substring(0, 19),
      status: 'completed'
    };

    setResellerTx(prev => [newTx, ...prev]);
    addToast('success', 'Wallet Recharged!', `₹${amount.toLocaleString()} + ₹${bonus} bonus credited to your reseller wallet.`);
  };

  const purchaseResellerBulk = (planId: string, quantity: number, clientLabel?: string): { success: boolean; keys: string[]; order: ResellerWholesaleOrder } & ResellerWholesaleOrder => {
    const product = products.find(p => p.id === planId);
    if (!product) throw new Error('Product not found');

    if (product.stockQuantity < quantity) {
      throw new Error(`Insufficient inventory. Only ${product.stockQuantity} licenses available in stock.`);
    }

    const discountRate = user?.resellerDiscount || 30;
    const baseTotal = product.priceINR * quantity;
    const discountedTotal = Math.round(baseTotal * (1 - discountRate / 100));

    if (!user || user.walletBalance < discountedTotal) {
      throw new Error(`Insufficient wallet balance. You need ₹${discountedTotal.toLocaleString('en-IN')}. Please top-up.`);
    }

    // Deduct user wallet
    setUser({ ...user, walletBalance: user.walletBalance - discountedTotal });

    // Deduct stock
    updateProductStock(product.id, Math.max(0, product.stockQuantity - quantity));

    // Generate keys
    const generatedKeys: string[] = [];
    for (let i = 0; i < quantity; i++) {
      const code = `TSM-RES-${Math.floor(1000 + Math.random() * 9000)}-${Math.random().toString(36).substring(2, 6).toUpperCase()}-${Math.floor(1000 + Math.random() * 9000)}`;
      generatedKeys.push(code);
    }

    const newOrder: ResellerWholesaleOrder = {
      id: 'rso-' + Math.random().toString(36).substring(2, 8),
      resellerId: user.id,
      productName: `${product.name} (${quantity}-Pack Wholesale)`,
      quantity,
      totalDeducted: discountedTotal,
      generatedKeys,
      clientLabel: clientLabel || 'Direct Sub-Agent Allocation',
      date: new Date().toISOString().replace('T', ' ').substring(0, 19)
    };

    const newTx: ResellerWalletTx = {
      id: 'tx-' + Math.random().toString(36).substring(2, 8),
      resellerId: user.id,
      amount: discountedTotal,
      type: 'debit',
      description: `Wholesale Purchase: ${quantity}x ${product.name} (${discountRate}% margin applied)`,
      date: new Date().toISOString().replace('T', ' ').substring(0, 19),
      status: 'completed'
    };

    setResellerOrders(prev => [newOrder, ...prev]);
    setResellerTx(prev => [newTx, ...prev]);

    addToast('success', 'Bulk Generation Complete!', `${quantity} license keys generated. ₹${discountedTotal} deducted.`);
    return {
      ...newOrder,
      success: true,
      keys: generatedKeys,
      order: newOrder
    };
  };

  const updateResellerSettings = (agencyName: string, apiKey: string) => {
    if (user) {
      setUser({ ...user, resellerAgencyName: agencyName, resellerApiKey: apiKey });
      addToast('success', 'Agency Profile Updated', 'White-label brand & API key configuration saved.');
    }
  };

  return (
    <AppContext.Provider value={{
      currentPage,
      setCurrentPage,
      currency,
      setCurrency,
      formatPrice,
      user,
      login,
      logout,
      register,
      switchRole,
      isAuthModalOpen,
      setIsAuthModalOpen,
      authModalMode,
      setAuthModalMode,
      inventory,
      vpsPricingTiers,
      categoryPlans,
      serverCategories,
      addInventoryItem,
      updateInventoryItem,
      deleteInventoryItem,
      updateInventoryStock,
      toggleInventoryActive,
      bulkImportInventory,
      updateVpsPricingTier,
      updateCategoryPlan,
      addCategoryPlan,
      deleteCategoryPlan,
      toggleCategoryPlanActive,
      updateServerCategory,
      getPlansForServer,
      getStartingPriceForServer,
      openCheckoutWithInventory,
      resetInventoryToDefaults,
      products,
      addProduct,
      updateProduct,
      deleteProduct,
      updateProductStock,
      selectedPlanForCheckout,
      openCheckout,
      closeCheckout,
      isCheckoutOpen,
      coupons,
      appliedCoupon,
      applyCoupon,
      removeCoupon,
      calculateDiscount,
      addCoupon,
      deleteCoupon,
      completeOrder,
      payments,
      orders,
      activeServices,
      selectedOrderForInvoice,
      setSelectedOrderForInvoice,
      trackOrderNumber,
      setTrackOrderNumber,
      rebootService,
      selectedServiceForConsole,
      setSelectedServiceForConsole,
      tickets,
      createTicket,
      replyTicket,
      updateTicketStatus,
      resellerTx,
      resellerOrders,
      resellerTransactions: resellerTx,
      resellerWholesaleOrders: resellerOrders,
      rechargeResellerWallet,
      purchaseResellerBulk,
      updateResellerSettings,
      isDemoModalOpen,
      setIsDemoModalOpen,
      toasts,
      addToast,
      removeToast
    }}>
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
