import { 
  PlanItem, 
  Coupon, 
  Testimonial, 
  FaqItem, 
  DatacenterNode, 
  Order, 
  ActiveService,
  SupportTicket,
  PaymentRecord,
  ResellerWalletTx,
  ResellerWholesaleOrder
} from '../types';

export const PLANS_DATA: PlanItem[] = [
  // Tatkal Software Plans
  {
    id: 'tatkal-starter',
    name: 'Tatkal Super Lite',
    category: 'tatkal-software',
    tagline: 'Ideal for individual travelers & occasional ticket booking',
    priceINR: 499,
    priceUSD: 9,
    originalPriceINR: 999,
    period: '/month',
    stockStatus: 'in-stock',
    stockQuantity: 45,
    minStockAlert: 5,
    activationTime: 'Instant (under 60s)',
    badge: 'Starter Choice',
    digitalDeliveryType: 'software_license',
    downloadUrl: 'https://downloads.tatkalsupermaster.com/v4.8/TSM_Lite_Setup.exe',
    deliveryNotes: 'Auto-generates 1 Lite Software License Key with 2 concurrent passenger slots.',
    isActive: true,
    specs: [
      { label: 'Booking Slots', value: '2 Concurrent Slots' },
      { label: 'Auto Captcha', value: 'Standard AI Solver' },
      { label: 'Form Auto-Fill', value: 'Ultra Fast <0.5s' },
      { label: 'Master List Sync', value: 'Up to 6 Passengers' },
      { label: 'Payment Gateway', value: 'UPI & NetBanking Fast-forward' },
    ],
    features: [
      'Fast 10:00 AM & 11:00 AM Tatkal Trigger',
      'Auto Bank OTP Interception Support',
      'Instant IRCTC Session Refresh',
      'Encrypted Local Storage for Credentials',
      'Email & Telegram Support',
      'Free Weekly Updates'
    ]
  },
  {
    id: 'tatkal-pro',
    name: 'Tatkal Super Master PRO',
    category: 'tatkal-software',
    tagline: 'High-speed professional automation engine with zero-lag routing',
    popular: true,
    featured: true,
    priceINR: 999,
    priceUSD: 16,
    originalPriceINR: 1999,
    period: '/month',
    stockStatus: 'in-stock',
    stockQuantity: 78,
    minStockAlert: 10,
    activationTime: 'Instant (under 30s)',
    badge: 'Most Popular',
    digitalDeliveryType: 'software_license',
    downloadUrl: 'https://downloads.tatkalsupermaster.com/v4.8/TSM_Pro_Setup.exe',
    deliveryNotes: 'Auto-generates 1 PRO Master Key with 6 multi-slots & neural OCR captcha solver.',
    isActive: true,
    specs: [
      { label: 'Booking Slots', value: '6 Concurrent Slots' },
      { label: 'Auto Captcha', value: 'Zero-Latency OCR Engine' },
      { label: 'Speed Optimization', value: 'Turbo Network Bypass' },
      { label: 'Proxy Integration', value: 'Residential & Static SOCKS5' },
      { label: 'Multi-ID Support', value: '5 IRCTC Accounts' },
    ],
    features: [
      'Ultra Low Latency Booking Algorithm',
      'Automatic Payment Auto-Approval Integration',
      'IRCTC Dynamic Error Auto-Retry',
      'Direct Railway API Sync Speedup',
      'Dedicated Discord & Telegram VIP Channel',
      'Instant License Key Generator with 1-Click Reset'
    ]
  },
  {
    id: 'tatkal-enterprise',
    name: 'Tatkal Enterprise Suite',
    category: 'tatkal-software',
    tagline: 'Ultimate agency-grade solution with unlimited slots & dedicated proxies',
    priceINR: 2499,
    priceUSD: 39,
    originalPriceINR: 4499,
    period: '/month',
    stockStatus: 'in-stock',
    stockQuantity: 20,
    minStockAlert: 5,
    activationTime: 'Instant + VIP Setup',
    badge: 'Agency Grade',
    digitalDeliveryType: 'software_license',
    downloadUrl: 'https://downloads.tatkalsupermaster.com/v4.8/TSM_Enterprise_Setup.exe',
    deliveryNotes: 'Auto-generates Enterprise Master Agency Key with unlimited sub-agent slots.',
    isActive: true,
    specs: [
      { label: 'Booking Slots', value: 'Unlimited Slots' },
      { label: 'Auto Captcha', value: 'Enterprise Neural Solver' },
      { label: 'Multi-User Agency', value: 'Up to 10 Agents' },
      { label: 'Proxy Included', value: '3 Dedicated High-Speed IPs' },
      { label: 'Priority Gateway', value: 'Direct Banking Tunneling' },
    ],
    features: [
      'White-label Agent Dashboard',
      'Multi-Device License Sync (Windows / RDP)',
      'Sub-second Train Seat Lock Mechanism',
      'Automated PNR Confirmation Tracker',
      '24/7 Dedicated Account Manager on Call',
      'Custom Script Customization & API Access'
    ]
  },

  // Windows VPS Plans
  {
    id: 'vps-win-starter',
    name: 'Windows VPS - Ultra Turbo',
    category: 'windows-vps',
    tagline: 'Tuned specifically for Tatkal software with <2ms Mumbai Railway Server Latency',
    priceINR: 799,
    priceUSD: 12,
    originalPriceINR: 1299,
    period: '/month',
    stockStatus: 'in-stock',
    stockQuantity: 15,
    minStockAlert: 3,
    activationTime: 'Instant (< 2 mins)',
    location: 'Mumbai Datacenter (CtrlS)',
    digitalDeliveryType: 'vps_server',
    deliveryNotes: 'Auto-provisions Windows Server 2022 instance in Mumbai with Administrator RDP credentials.',
    isActive: true,
    specs: [
      { label: 'vCPU Cores', value: '2 vCPU (Intel Xeon 3.8GHz)' },
      { label: 'RAM', value: '4 GB DDR4 High-Speed' },
      { label: 'Storage', value: '60 GB NVMe Gen4 SSD' },
      { label: 'Bandwidth', value: '1 Gbps Unmetered Port' },
      { label: 'OS', value: 'Windows Server 2022 / 2019' },
    ],
    features: [
      'Full Administrator RDP Access',
      'Pre-installed Chrome, Edge & Tatkal Tools',
      'Dedicated Static Clean IPv4 Included',
      'DDoS Protection up to 500 Gbps',
      'Instant Reboot & Web Console via Dashboard',
      '99.99% Guaranteed SLA Uptime'
    ]
  },
  {
    id: 'vps-win-pro',
    name: 'Windows VPS - Extreme Power',
    category: 'windows-vps',
    tagline: 'Extreme performance for running multiple browser tabs & parallel booking sessions',
    popular: true,
    featured: true,
    priceINR: 1399,
    priceUSD: 22,
    originalPriceINR: 2299,
    period: '/month',
    stockStatus: 'in-stock',
    stockQuantity: 28,
    minStockAlert: 5,
    activationTime: 'Instant (< 2 mins)',
    badge: 'Bestseller',
    location: 'Mumbai / Delhi Low-Ping',
    digitalDeliveryType: 'vps_server',
    deliveryNotes: 'Auto-provisions AMD EPYC 4 vCPU Windows Server with low-jitter Mumbai Equinix routing.',
    isActive: true,
    specs: [
      { label: 'vCPU Cores', value: '4 vCPU (AMD EPYC 4.2GHz)' },
      { label: 'RAM', value: '8 GB DDR4 High-Speed' },
      { label: 'Storage', value: '120 GB NVMe Gen4 SSD' },
      { label: 'Bandwidth', value: '10 Gbps Port (Uncapped)' },
      { label: 'OS', value: 'Windows Server 2022 Enterprise' },
    ],
    features: [
      'Sub-millisecond Local Routing to IRCTC Gateways',
      'Pure NVMe Read/Write speeds (>4500 MB/s)',
      'Dual IP Whitelisting & Firewall Rules',
      '1-Click Automated Daily Backups',
      'Priority 24/7 Telegram Remote Assistance',
      'Zero Throttling Guaranteed'
    ]
  },
  {
    id: 'vps-win-enterprise',
    name: 'Windows VPS - Beast Server',
    category: 'windows-vps',
    tagline: 'Maximized power for heavy agents, large teams, and heavy automated tasks',
    priceINR: 2499,
    priceUSD: 39,
    originalPriceINR: 3999,
    period: '/month',
    stockStatus: 'low-stock',
    stockQuantity: 4,
    minStockAlert: 3,
    activationTime: 'Instant (< 3 mins)',
    badge: 'Heavy Load',
    location: 'Mumbai Equinix MB2',
    digitalDeliveryType: 'vps_server',
    deliveryNotes: 'High-density 8 vCPU / 16 GB RAM dedicated node in Equinix MB2.',
    isActive: true,
    specs: [
      { label: 'vCPU Cores', value: '8 vCPU (Ryzen 9 / EPYC)' },
      { label: 'RAM', value: '16 GB High Frequency RAM' },
      { label: 'Storage', value: '250 GB Enterprise NVMe' },
      { label: 'Bandwidth', value: '10 Gbps Dedicated Uplink' },
      { label: 'OS', value: 'Windows 10 Pro / Server 2022' },
    ],
    features: [
      '2 Dedicated Static Clean IPv4 Addresses',
      'Automated Anti-Hang & Task Priority Booster',
      'Custom ISO Mounting Support',
      'Dedicated 1-on-1 Engineer Setup',
      'Instant Auto-failover IP Routing',
      'Hardware Level Performance Isolation'
    ]
  },

  // Linux VPS Plans
  {
    id: 'vps-linux-lite',
    name: 'Linux Cloud VPS - Dev & Node',
    category: 'linux-vps',
    tagline: 'Optimized Linux VPS for Python automation, headless bots, and proxies',
    priceINR: 449,
    priceUSD: 7,
    originalPriceINR: 799,
    period: '/month',
    stockStatus: 'in-stock',
    stockQuantity: 35,
    minStockAlert: 5,
    activationTime: 'Instant (< 60s)',
    location: 'Mumbai / Bangalore',
    digitalDeliveryType: 'vps_server',
    deliveryNotes: 'Provisions Ubuntu 24.04 LTS VPS with Root SSH access on port 22.',
    isActive: true,
    specs: [
      { label: 'vCPU Cores', value: '1 vCPU AMD EPYC' },
      { label: 'RAM', value: '2 GB ECC RAM' },
      { label: 'Storage', value: '30 GB NVMe' },
      { label: 'Port Speed', value: '1 Gbps' },
      { label: 'OS', value: 'Ubuntu / Debian / CentOS' },
    ],
    features: [
      'Full Root SSH Access',
      'Docker & Python 3.12 Ready',
      'Static IPv4 + /64 IPv6 Block',
      'Custom Reverse DNS (rDNS) Control',
      'Live Metrics & Web Terminal in Dashboard'
    ]
  },
  {
    id: 'vps-linux-power',
    name: 'Linux Cloud VPS - Turbo Node',
    category: 'linux-vps',
    tagline: 'High concurrency server for running multiple microservices & automated scrapers',
    priceINR: 899,
    priceUSD: 14,
    originalPriceINR: 1499,
    period: '/month',
    stockStatus: 'in-stock',
    stockQuantity: 22,
    minStockAlert: 5,
    activationTime: 'Instant (< 60s)',
    location: 'Mumbai / Singapore',
    digitalDeliveryType: 'vps_server',
    deliveryNotes: 'Provisions 4 vCPU High Clock Linux container with BBR congestion tuning.',
    isActive: true,
    specs: [
      { label: 'vCPU Cores', value: '4 vCPU High Clock' },
      { label: 'RAM', value: '8 GB ECC RAM' },
      { label: 'Storage', value: '80 GB NVMe Gen4' },
      { label: 'Port Speed', value: '10 Gbps' },
      { label: 'OS', value: 'Ubuntu 24.04 / AlmaLinux / Debian' },
    ],
    features: [
      'Kernel Level TCP BBR Speed Congestion Tuning',
      'Unmetered Inbound & Outbound Traffic',
      'API-Driven Automated Snapshots',
      'Custom Firewall & Port Forwarding Manager',
      '24/7 SLA Guarantee'
    ]
  },

  // Residential & Static IP Plans
  {
    id: 'ip-residential-pack',
    name: 'Premium Residential Clean IPs (5 Pack)',
    category: 'residential-ip',
    tagline: '100% ISP-level genuine Indian home IPs (Jio, Airtel, ACT, BSNL) for zero detection',
    popular: true,
    priceINR: 599,
    priceUSD: 9,
    originalPriceINR: 999,
    period: '/pack (5 IPs)',
    stockStatus: 'in-stock',
    stockQuantity: 95,
    minStockAlert: 15,
    activationTime: 'Instant Auto-Allocated',
    badge: '100% Clean Score',
    digitalDeliveryType: 'proxy_credentials',
    deliveryNotes: 'Auto-delivers 5 Jio/Airtel SOCKS5 Proxy strings (IP:Port:User:Pass) with IP whitelist access.',
    isActive: true,
    specs: [
      { label: 'IP Count', value: '5 Dedicated Residential IPs' },
      { label: 'ISP Networks', value: 'Jio / Airtel / ACT Fibernet' },
      { label: 'Protocols', value: 'HTTP, HTTPS & SOCKS5' },
      { label: 'Fraud Score', value: '0 (Guaranteed Clean)' },
      { label: 'Rotation', value: 'Static ISP / On-Demand' },
    ],
    features: [
      'Bypasses Cloudflare, Akamai & IRCTC bot shields',
      'Fast 100 Mbps+ throughput per connection',
      'Dual Auth: Username/Password & IP Whitelist',
      'Instant replacement if flagged within 24h',
      'Compatible with all Tatkal software & browser extensions'
    ]
  },
  {
    id: 'ip-static-dedicated',
    name: 'Static Dedicated High-Speed IP',
    category: 'static-ip',
    tagline: 'Permanent fixed IP address for uninterrupted sessions & consistent reputation',
    priceINR: 349,
    priceUSD: 6,
    originalPriceINR: 599,
    period: '/month per IP',
    stockStatus: 'in-stock',
    stockQuantity: 60,
    minStockAlert: 10,
    activationTime: 'Instant',
    digitalDeliveryType: 'proxy_credentials',
    deliveryNotes: 'Delivers 1 Dedicated Static IPv4 with WireGuard / SOCKS5 connection parameters.',
    isActive: true,
    specs: [
      { label: 'Type', value: 'Dedicated Static IPv4' },
      { label: 'Location', value: 'Mumbai Central / Delhi NCR' },
      { label: 'Ping to IRCTC', value: '< 3ms' },
      { label: 'Uptime', value: '99.99%' },
      { label: 'Bandwidth', value: 'Unlimited GB' },
    ],
    features: [
      'Zero sharing with other users (100% Dedicated)',
      'High Trust Score on all major verification nodes',
      'Configurable rDNS and Geo-Location headers',
      'Instant port forwarding and firewall rules',
      'Available with SOCKS5 & WireGuard Tunnel'
    ]
  },
  {
    id: 'proxy-datacenter',
    name: 'Ultra-Fast Datacenter Proxies (10 Pack)',
    category: 'datacenter-proxy',
    tagline: 'Gigabit-speed proxies hosted directly in Tier-4 Mumbai carrier hotels',
    priceINR: 499,
    priceUSD: 8,
    originalPriceINR: 899,
    period: '/pack (10 IPs)',
    stockStatus: 'in-stock',
    stockQuantity: 80,
    minStockAlert: 10,
    activationTime: 'Instant',
    digitalDeliveryType: 'proxy_credentials',
    deliveryNotes: 'Generates 10 Datacenter HTTP/SOCKS5 proxy entries with instant rotation endpoint.',
    isActive: true,
    specs: [
      { label: 'IP Count', value: '10 High Speed IPs' },
      { label: 'Port Speed', value: '10 Gbps Backbone' },
      { label: 'Protocols', value: 'HTTP / SOCKS5' },
      { label: 'Concurrency', value: 'Unlimited Threads' },
      { label: 'Subnets', value: 'Diverse Class-C Subnets' },
    ],
    features: [
      'Sub-millisecond handshake response time',
      'Ideal for heavy automated monitoring and scraping',
      'Auto-Rotating or Sticky Session mode',
      'API endpoint for automated proxy list export',
      'Full IPv4 & IPv6 dual-stack support'
    ]
  },
  {
    id: 'rdp-premium',
    name: 'Dedicated High-Speed RDP',
    category: 'rdp',
    tagline: 'Ready-to-use remote desktop with pre-configured browsers, extensions & zero setup',
    priceINR: 699,
    priceUSD: 11,
    originalPriceINR: 1199,
    period: '/month',
    stockStatus: 'in-stock',
    stockQuantity: 18,
    minStockAlert: 4,
    activationTime: 'Instant (< 90s)',
    badge: 'Plug & Play',
    digitalDeliveryType: 'vps_server',
    deliveryNotes: 'Pre-configured Windows 11 RDP with instant Chrome/Edge auto-booking setup.',
    isActive: true,
    specs: [
      { label: 'OS', value: 'Windows 11 Pro / Server 2022' },
      { label: 'RAM', value: '6 GB DDR4' },
      { label: 'Internet Speed', value: '1 Gbps Download/Upload' },
      { label: 'Access', value: 'Direct Microsoft RDP Client' },
      { label: 'Software', value: 'Pre-installed & Configured' },
    ],
    features: [
      'Access from any Android, iPhone, Mac, or PC',
      'No complex configuration needed — just double click to connect',
      'Integrated Chrome profiles with auto-fill scripts ready',
      'Ultra smooth 60 FPS remote desktop rendering',
      'Automatic restart on crash'
    ]
  },
  {
    id: 'dedicated-server-beast',
    name: 'Bare-Metal Dedicated Server',
    category: 'dedicated-server',
    tagline: 'Raw dedicated hardware for massive agencies & high-volume processing',
    priceINR: 4999,
    priceUSD: 79,
    originalPriceINR: 7999,
    period: '/month',
    stockStatus: 'low-stock',
    stockQuantity: 2,
    minStockAlert: 1,
    activationTime: 'Within 2 Hours',
    badge: 'Maximum Power',
    digitalDeliveryType: 'dedicated_server',
    deliveryNotes: 'Bare-metal Intel Xeon Gold 32-thread node with 64GB ECC and IPMI remote control.',
    isActive: true,
    specs: [
      { label: 'Processor', value: 'Intel Xeon Gold 16 Cores / 32 Threads' },
      { label: 'RAM', value: '64 GB ECC Registered' },
      { label: 'Storage', value: '2x 1TB Enterprise NVMe RAID 1' },
      { label: 'Network', value: '10 Gbps Redundant Uplink' },
      { label: 'IPs', value: '5 Usable Static Clean IPs' },
    ],
    features: [
      '100% Dedicated physical hardware with IPMI/iDRAC remote management',
      'Custom hardware RAID configuration',
      'Direct carrier peering with National Internet Exchange of India (NIXI)',
      'Enterprise SLA with 99.999% network uptime guarantee',
      'Dedicated Senior Systems Engineer support'
    ]
  }
];

export const INITIAL_SERVICES: ActiveService[] = [
  {
    id: 'srv-001',
    serviceName: 'Tatkal Super Master PRO (Monthly)',
    category: 'tatkal-software',
    planId: 'tatkal-pro',
    status: 'active',
    expiryDate: '2026-09-22',
    renewalPriceINR: 999,
    location: 'Cloud License Server',
    licenseKey: 'TSM-PRO-8849-XK21-9942-IN',
    downloadUrl: 'https://downloads.tatkalsupermaster.com/v4.8/TSM_Pro_Setup.exe',
    deliveryEmailSent: true,
    usageStats: {
      cpuUsage: 14,
      ramUsage: 35,
      bandwidthGB: 18.4,
      maxBandwidthGB: 100
    }
  },
  {
    id: 'srv-002',
    serviceName: 'Windows VPS - Extreme Power (Mumbai MB2)',
    category: 'windows-vps',
    planId: 'vps-win-pro',
    ipAddress: '103.145.78.112',
    username: 'Administrator',
    password: 'TSM_WinVps_#2026Secure!',
    port: 3389,
    status: 'active',
    expiryDate: '2026-09-18',
    renewalPriceINR: 1399,
    location: 'Mumbai CtrlS Datacenter',
    os: 'Windows Server 2022 Enterprise',
    deliveryEmailSent: true,
    usageStats: {
      cpuUsage: 28,
      ramUsage: 64,
      bandwidthGB: 245.8,
      maxBandwidthGB: 2000
    }
  },
  {
    id: 'srv-003',
    serviceName: 'Premium Residential Clean IPs (5 Pack)',
    category: 'residential-ip',
    planId: 'ip-residential-pack',
    status: 'active',
    expiryDate: '2026-09-30',
    renewalPriceINR: 599,
    location: 'Mumbai & Delhi Airtel/Jio',
    ipAddress: '157.34.192.88',
    port: 8080,
    username: 'tsm_usr82',
    password: 'sec992_ResidentialPass',
    proxyFormat: '157.34.192.88:8080:tsm_usr82:sec992_ResidentialPass',
    deliveryEmailSent: true,
    usageStats: {
      cpuUsage: 5,
      ramUsage: 12,
      bandwidthGB: 42.1,
      maxBandwidthGB: 500
    }
  }
];

export const INITIAL_ORDERS: Order[] = [
  {
    id: 'ord-88912',
    orderNumber: 'TSM-2026-88912',
    date: '2026-08-20',
    customerName: 'Rahul Verma',
    customerEmail: 'rahul.verma@example.com',
    customerPhone: '+91 98765 43210',
    items: [
      {
        planId: 'tatkal-pro',
        planName: 'Tatkal Super Master PRO',
        category: 'tatkal-software',
        price: 999,
        quantity: 1,
        billingCycle: 'monthly',
      }
    ],
    subtotal: 999,
    discount: 100,
    tax: 0,
    total: 899,
    currency: 'INR',
    paymentMethod: 'upi',
    paymentStatus: 'paid',
    fulfillmentStatus: 'delivered',
    transactionId: 'UPI-TXN-99882314589',
    razorpayPaymentId: 'pay_UPI_99882314589',
    couponApplied: 'WELCOME10',
    provisionedCredentials: {
      licenseKey: 'TSM-PRO-8849-XK21-9942-IN',
      downloadLink: 'https://downloads.tatkalsupermaster.com/v4.8/TSM_Pro_Setup.exe',
      guideUrl: 'https://tatkalsupermaster.com/docs/quickstart'
    },
    deliveryLogs: [
      {
        id: 'del-01',
        orderId: 'ord-88912',
        timestamp: '2026-08-20 14:32:30',
        channel: 'email',
        recipient: 'rahul.verma@example.com',
        status: 'delivered',
        contentPreview: 'Your Tatkal Super Master PRO License Key & Download Link'
      },
      {
        id: 'del-02',
        orderId: 'ord-88912',
        timestamp: '2026-08-20 14:32:32',
        channel: 'telegram',
        recipient: '@tatkalsupermaster',
        status: 'delivered',
        contentPreview: 'TSM Activation Key: TSM-PRO-8849-XK21-9942-IN'
      }
    ],
    trackingTimeline: [
      { step: 'Order Placed', timestamp: '2026-08-20 14:32:00', completed: true, description: 'Order received via website' },
      { step: 'Payment Verified', timestamp: '2026-08-20 14:32:15', completed: true, description: 'UPI Payment ₹899 verified via Instant Gateway' },
      { step: 'Stock Reduced & Allocated', timestamp: '2026-08-20 14:32:18', completed: true, description: 'Stock reserved in database' },
      { step: 'License Generated & Dispatched', timestamp: '2026-08-20 14:32:30', completed: true, description: 'License key & setup .EXE dispatched to Telegram & Email' }
    ]
  },
  {
    id: 'ord-88913',
    orderNumber: 'TSM-2026-88913',
    date: '2026-08-18',
    customerName: 'Rahul Verma',
    customerEmail: 'rahul.verma@example.com',
    customerPhone: '+91 98765 43210',
    items: [
      {
        planId: 'vps-win-pro',
        planName: 'Windows VPS - Extreme Power',
        category: 'windows-vps',
        price: 1399,
        quantity: 1,
        billingCycle: 'monthly',
      }
    ],
    subtotal: 1399,
    discount: 0,
    tax: 0,
    total: 1399,
    currency: 'INR',
    paymentMethod: 'razorpay',
    paymentStatus: 'paid',
    fulfillmentStatus: 'delivered',
    transactionId: 'pay_Nz9938LqA12b',
    razorpayPaymentId: 'pay_Nz9938LqA12b',
    provisionedCredentials: {
      ip: '103.145.78.112',
      username: 'Administrator',
      password: 'TSM_WinVps_#2026Secure!',
      port: 3389
    },
    deliveryLogs: [
      {
        id: 'del-03',
        orderId: 'ord-88913',
        timestamp: '2026-08-18 09:14:30',
        channel: 'email',
        recipient: 'rahul.verma@example.com',
        status: 'delivered',
        contentPreview: 'Your Windows VPS RDP Credentials (IP: 103.145.78.112:3389)'
      }
    ],
    trackingTimeline: [
      { step: 'Order Placed', timestamp: '2026-08-18 09:12:00', completed: true, description: 'Order created' },
      { step: 'Razorpay Payment Verified', timestamp: '2026-08-18 09:12:35', completed: true, description: 'Razorpay payment ₹1399 approved' },
      { step: 'VPS Provisioned', timestamp: '2026-08-18 09:14:10', completed: true, description: 'Windows Server 2022 container deployed in Mumbai MB2' },
      { step: 'RDP Credentials Sent', timestamp: '2026-08-18 09:14:30', completed: true, description: 'RDP IP, Port & Password delivered to dashboard & email' }
    ]
  }
];

export const INITIAL_PAYMENTS: PaymentRecord[] = [
  {
    id: 'pay-001',
    orderId: 'ord-88912',
    orderNumber: 'TSM-2026-88912',
    customerName: 'Rahul Verma',
    customerEmail: 'rahul.verma@example.com',
    gateway: 'razorpay',
    gatewayTransactionId: 'pay_UPI_99882314589',
    amount: 899,
    currency: 'INR',
    status: 'captured',
    createdAt: '2026-08-20 14:32:15',
    methodDetails: 'UPI (PhonePe / UPI ID)'
  },
  {
    id: 'pay-002',
    orderId: 'ord-88913',
    orderNumber: 'TSM-2026-88913',
    customerName: 'Rahul Verma',
    customerEmail: 'rahul.verma@example.com',
    gateway: 'razorpay',
    gatewayTransactionId: 'pay_Nz9938LqA12b',
    amount: 1399,
    currency: 'INR',
    status: 'captured',
    createdAt: '2026-08-18 09:12:35',
    methodDetails: 'HDFC Credit Card (Visa)'
  }
];

export const INITIAL_TICKETS: SupportTicket[] = [
  {
    id: 'tkt-101',
    ticketNumber: 'TSM-TK-9021',
    userId: 'usr-901',
    userName: 'Rahul Verma',
    userEmail: 'rahul.verma@example.com',
    department: 'tatkal-software',
    priority: 'high',
    subject: 'Assistance with Master List CSV Import in Tatkal Super Master PRO v4.8',
    status: 'resolved',
    createdAt: '2026-08-19 11:20:00',
    updatedAt: '2026-08-19 11:45:00',
    messages: [
      {
        id: 'msg-1',
        senderId: 'usr-901',
        senderName: 'Rahul Verma',
        senderRole: 'customer',
        message: 'Hello, I want to import a CSV list of 12 passengers. How do I format the berth preference column?',
        timestamp: '2026-08-19 11:20:00'
      },
      {
        id: 'msg-2',
        senderId: 'agent-1',
        senderName: 'Tatkal Support Engineer',
        senderRole: 'agent',
        message: 'Hi Rahul! You can use the template inside Settings > Master List > Download Sample CSV. Set berth preference to LB (Lower), MB (Middle), UB (Upper), or SL (Side Lower).',
        timestamp: '2026-08-19 11:45:00'
      }
    ]
  }
];

export const INITIAL_RESELLER_TX: ResellerWalletTx[] = [
  {
    id: 'tx-001',
    resellerId: 'usr-901',
    amount: 10000,
    type: 'credit',
    bonusAmount: 500,
    description: 'Wallet Top-up via Razorpay UPI (+5% Cashback Bonus)',
    paymentGateway: 'Razorpay UPI',
    date: '2026-08-15 10:30:00',
    status: 'completed'
  },
  {
    id: 'tx-002',
    resellerId: 'usr-901',
    amount: 3495,
    type: 'debit',
    description: 'Bulk Purchase: 5x Tatkal Super Master PRO Monthly Licenses (30% Reseller Margin)',
    date: '2026-08-16 16:20:00',
    status: 'completed'
  }
];

export const INITIAL_RESELLER_ORDERS: ResellerWholesaleOrder[] = [
  {
    id: 'rso-001',
    resellerId: 'usr-901',
    productName: 'Tatkal Super Master PRO (5-Pack Wholesale)',
    quantity: 5,
    totalDeducted: 3495,
    generatedKeys: [
      'TSM-RES-7821-VK01-9921',
      'TSM-RES-7821-VK02-9922',
      'TSM-RES-7821-VK03-9923',
      'TSM-RES-7821-VK04-9924',
      'TSM-RES-7821-VK05-9925'
    ],
    clientLabel: 'Shree Ganesh Travels Sub-Agents',
    date: '2026-08-16 16:20:00'
  }
];

export const COUPONS_DATA: Coupon[] = [
  {
    code: 'MASTER20',
    discountPercentage: 20,
    maxDiscountINR: 500,
    description: 'Get 20% OFF on all VPS Hosting & Tatkal Software plans!',
    isActive: true,
    usesCount: 184
  },
  {
    code: 'TATKAL50',
    discountPercentage: 50,
    maxDiscountINR: 300,
    minOrderValueINR: 499,
    description: 'Special 50% discount for new Tatkal Software registrations!',
    isActive: true,
    usesCount: 412
  },
  {
    code: 'WELCOME10',
    discountPercentage: 10,
    maxDiscountINR: 200,
    description: 'Flat 10% instant discount on your first order.',
    isActive: true,
    usesCount: 92
  },
  {
    code: 'SPEED100',
    discountPercentage: 15,
    maxDiscountINR: 1000,
    description: '15% OFF on Residential & Static IP bundles.',
    isActive: true,
    usesCount: 45
  }
];

export const TESTIMONIALS_DATA: Testimonial[] = [
  {
    id: 'test-1',
    name: 'Amitabh Sharma',
    role: 'Authorized Travel Agent',
    location: 'Patna, Bihar',
    rating: 5,
    comment: 'The Mumbai VPS has insane latency — under 1.8ms to IRCTC servers! The Tatkal Super Master Pro software auto-fills in half a second. My confirmed ticket ratio went from 40% to 98% within the first week. Outstanding support on Telegram!',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
    verifiedPurchase: 'Tatkal Super Master PRO + Windows VPS',
    date: '2 days ago'
  },
  {
    id: 'test-2',
    name: 'Vikram Joshi',
    role: 'Tours & Travels Operator',
    location: 'Jaipur, Rajasthan',
    rating: 5,
    comment: 'Used other tools in the past that got blocked or had lag at 10:00 AM. Tatkal Super Master’s Residential Clean IPs never get flagged. The captcha bypass is instant. Truly agency-grade quality.',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
    verifiedPurchase: 'Residential Clean IPs Pack + RDP',
    date: '5 days ago'
  },
  {
    id: 'test-3',
    name: 'Deepak Patel',
    role: 'Frequent Commuter',
    location: 'Ahmedabad, Gujarat',
    rating: 5,
    comment: 'I was skeptical at first, but the instant UPI activation and simple setup surprised me. Got my Diwali holiday confirmed tickets in AC 2-Tier in under 40 seconds. Customer service answered my Telegram ping at 9:45 AM immediately.',
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80',
    verifiedPurchase: 'Tatkal Super Lite Plan',
    date: '1 week ago'
  },
  {
    id: 'test-4',
    name: 'Suresh Nambiar',
    role: 'Corporate Travel Desk',
    location: 'Bengaluru, Karnataka',
    rating: 5,
    comment: 'Managing bookings for 200+ employees requires absolute reliability. Their Bare-Metal Dedicated Server and Enterprise Tatkal Suite give us smooth performance with zero crashes even during peak holiday rush.',
    avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&auto=format&fit=crop&q=80',
    verifiedPurchase: 'Tatkal Enterprise Suite',
    date: '2 weeks ago'
  }
];

export const FAQS_DATA: FaqItem[] = [
  {
    id: 'faq-1',
    category: 'general',
    question: 'How fast is server and software activation after payment?',
    answer: 'Activation is 100% automated and instant! For Tatkal Software licenses, Residential IPs, and Windows VPS, your credentials, download links, and license keys are generated and displayed on your screen and dispatched via Telegram/Email within 30 to 90 seconds after payment confirmation.'
  },
  {
    id: 'faq-2',
    category: 'tatkal-software',
    question: 'How does the Tatkal Super Master software work?',
    answer: 'Tatkal Super Master is a lightweight, high-performance automation suite that securely stores your passenger master list, auto-selects payment routes, resolves visual and audio captchas in sub-seconds using local AI neural models, and speeds up form submission by synchronizing directly with IRCTC endpoints with zero lag.'
  },
  {
    id: 'faq-3',
    category: 'vps-hosting',
    question: 'Why should I use your Windows VPS instead of my home PC?',
    answer: 'Our Windows VPS servers are located directly in Tier-4 Mumbai and Delhi carrier-grade datacenters with 10 Gbps uplinks and sub-2 millisecond latency to IRCTC booking gateways. Your home internet typically has 40-120ms latency and high jitter. A VPS ensures you have the fastest connection at the critical 10:00 AM & 11:00 AM booking windows.'
  },
  {
    id: 'faq-4',
    category: 'ip-services',
    question: 'What is the difference between Residential IPs and Datacenter Proxies?',
    answer: 'Residential IPs originate from real Indian consumer ISPs like Jio, Airtel, and ACT Fibernet, meaning they look 100% like real home users to anti-bot algorithms. Datacenter proxies offer raw 10Gbps gigabit speed and are ideal for high-thread scanning, while Residential IPs are best for undetectable booking sessions.'
  },
  {
    id: 'faq-5',
    category: 'payment-delivery',
    question: 'What payment methods do you support?',
    answer: 'We support all major Indian payment gateways including Razorpay, PhonePe, Cashfree, and PayU. You can pay with UPI (Google Pay, PhonePe, Paytm, BHIM, CRED), Instant Dynamic QR Code, Credit/Debit Cards, NetBanking, and Prepaid Wallet.'
  },
  {
    id: 'faq-6',
    category: 'reseller',
    question: 'How does the Reseller Program work?',
    answer: 'Resellers get access to a dedicated portal with 25% to 35% wholesale discounts, bulk license generation tools, white-label client branding, instant prepaid wallet recharges with bonus cash, and automated REST API keys for integrating into their own booking applications.'
  },
  {
    id: 'faq-7',
    category: 'vps-hosting',
    question: 'Can I connect to the Windows VPS from my mobile phone or Mac?',
    answer: 'Yes! You can connect using Microsoft Remote Desktop (RD Client) available free on Android Google Play Store, iOS App Store, Mac App Store, and Windows. We provide step-by-step 1-minute video connection guides.'
  },
  {
    id: 'faq-8',
    category: 'tatkal-software',
    question: 'Is my IRCTC login password safe in the software?',
    answer: 'Absolutely. We use AES-256 local client-side encryption. Your credentials never leave your local machine or private VPS container. We have a strict zero-knowledge architecture.'
  }
];

export const DATACENTER_NODES: DatacenterNode[] = [
  { id: 'node-bom', city: 'Mumbai (CtrlS & Equinix)', country: 'India', latencyMs: 1.4, status: 'optimal', bandwidthGbps: 10, coordinates: { x: 38, y: 55 } },
  { id: 'node-del', city: 'Delhi NCR (Noida DC)', country: 'India', latencyMs: 3.2, status: 'optimal', bandwidthGbps: 10, coordinates: { x: 42, y: 38 } },
  { id: 'node-blr', city: 'Bangalore (Electronic City)', country: 'India', latencyMs: 4.1, status: 'optimal', bandwidthGbps: 10, coordinates: { x: 41, y: 72 } },
  { id: 'node-maa', city: 'Chennai (SIPCOT DC)', country: 'India', latencyMs: 4.8, status: 'optimal', bandwidthGbps: 10, coordinates: { x: 46, y: 74 } },
  { id: 'node-sin', city: 'Singapore (Equinix SG1)', country: 'Asia-Pacific', latencyMs: 24.5, status: 'operational', bandwidthGbps: 40, coordinates: { x: 68, y: 70 } },
  { id: 'node-fra', city: 'Frankfurt (Main)', country: 'Europe', latencyMs: 110.2, status: 'operational', bandwidthGbps: 100, coordinates: { x: 22, y: 30 } }
];

export const COMPANY_STATS = [
  { label: 'Confirmed Bookings Daily', value: '45,000+', icon: 'Zap' },
  { label: 'Active VPS & RDP Servers', value: '8,200+', icon: 'Server' },
  { label: 'Clean Residential IPs', value: '150,000+', icon: 'Globe' },
  { label: 'Average IRCTC Latency', value: '< 1.8 ms', icon: 'Activity' },
  { label: 'Network SLA Uptime', value: '99.99%', icon: 'ShieldCheck' },
  { label: 'Satisfied Travel Agents', value: '14,500+', icon: 'Users' },
];
