import { VpsInventoryItem, VpsPricingTier, VpsCategoryPlan, VpsServerCategoryMeta, ServerTypeKey } from '../types';

export const DEFAULT_SERVER_CATEGORIES: VpsServerCategoryMeta[] = [
  {
    id: 'cat-normal',
    serverType: 'normal',
    categoryName: 'High-Speed Subnet',
    displayName: 'Linux VPS (Normal Servers)',
    badge: 'SUPER FAST 10GBPS',
    premiumColor: 'blue',
    clockSpeed: '3.8GHz Turbo',
    description: 'Tier-4 Datacenter low-latency subnet nodes with unmetered 10Gbps optical uplink.',
    allowedRams: ['4 GB', '8 GB', '16 GB', '32 GB'],
    isActive: true
  },
  {
    id: 'cat-gold',
    serverType: 'gold',
    categoryName: 'Gold Server',
    displayName: 'Gold Server',
    badge: 'GOLD SERVER 3.0GHz',
    premiumColor: 'gold',
    clockSpeed: '3.0GHz',
    description: 'Enterprise AMD EPYC / Ryzen 9 low-jitter nodes with dedicated line routing.',
    allowedRams: ['8 GB', '16 GB'],
    isActive: true
  },
  {
    id: 'cat-diamond',
    serverType: 'diamond',
    categoryName: 'Diamond Pro AMD',
    displayName: 'Diamond Pro AMD Server',
    badge: 'DIAMOND PRO AMD 3.1GHz',
    premiumColor: 'diamond',
    clockSpeed: '3.1GHz',
    description: 'Flagship dual cluster AMD EPYC 9654 Genoa + Ryzen 9 with zero-packet-drop guarantee.',
    allowedRams: ['16 GB', '32 GB'],
    isActive: true
  }
];

export const DEFAULT_CATEGORY_PLANS: VpsCategoryPlan[] = [
  // Normal Servers (Linux VPS)
  {
    id: 'plan-norm-4gb',
    serverType: 'normal',
    categoryName: 'Normal',
    ram: '4 GB',
    priceINR: 700,
    priceUSD: 10,
    vCpu: '2 vCPU AMD EPYC',
    nvme: '80 GB NVMe Gen4',
    bandwidth: '10 Gbps Unmetered',
    popular: false,
    isActive: true
  },
  {
    id: 'plan-norm-8gb',
    serverType: 'normal',
    categoryName: 'Normal',
    ram: '8 GB',
    priceINR: 1399,
    priceUSD: 19,
    vCpu: '4 vCPU AMD EPYC',
    nvme: '160 GB NVMe Gen4',
    bandwidth: '10 Gbps Unmetered',
    popular: true,
    isActive: true
  },
  {
    id: 'plan-norm-16gb',
    serverType: 'normal',
    categoryName: 'Normal',
    ram: '16 GB',
    priceINR: 1799,
    priceUSD: 24,
    vCpu: '8 vCPU AMD Ryzen 9',
    nvme: '320 GB NVMe Gen4',
    bandwidth: '10 Gbps Unmetered',
    popular: false,
    isActive: true
  },
  {
    id: 'plan-norm-32gb',
    serverType: 'normal',
    categoryName: 'Normal',
    ram: '32 GB',
    priceINR: 2500,
    priceUSD: 34,
    vCpu: '16 vCPU AMD Ryzen 9 PRO',
    nvme: '640 GB NVMe Gen4',
    bandwidth: '10 Gbps Unmetered',
    popular: false,
    isActive: true
  },

  // Gold Servers (ONLY 8 GB and 16 GB)
  {
    id: 'plan-gold-8gb',
    serverType: 'gold',
    categoryName: 'Gold Server',
    ram: '8 GB',
    priceINR: 1500,
    priceUSD: 20,
    vCpu: '4 vCPU AMD Ryzen 9 7950X (3.0 GHz)',
    nvme: '160 GB NVMe Gen4',
    bandwidth: '10 Gbps Dedicated Line',
    popular: true,
    isActive: true
  },
  {
    id: 'plan-gold-16gb',
    serverType: 'gold',
    categoryName: 'Gold Server',
    ram: '16 GB',
    priceINR: 2199,
    priceUSD: 29,
    vCpu: '8 vCPU AMD EPYC 9654 Genoa (3.0 GHz)',
    nvme: '320 GB NVMe Gen4',
    bandwidth: '10 Gbps Dedicated Line',
    popular: false,
    isActive: true
  },

  // Diamond Servers (ONLY 16 GB and 32 GB)
  {
    id: 'plan-diamond-16gb',
    serverType: 'diamond',
    categoryName: 'Diamond Pro AMD',
    ram: '16 GB',
    priceINR: 2799,
    priceUSD: 37,
    vCpu: '8 vCPU AMD EPYC 9654 + Ryzen 9 Turbo (3.1 GHz)',
    nvme: '320 GB NVMe Gen4',
    bandwidth: '10 Gbps Dedicated Line',
    popular: true,
    isActive: true
  },
  {
    id: 'plan-diamond-32gb',
    serverType: 'diamond',
    categoryName: 'Diamond Pro AMD',
    ram: '32 GB',
    priceINR: 3199,
    priceUSD: 42,
    vCpu: '16 vCPU AMD EPYC 9654 Dual Cluster (3.1 GHz)',
    nvme: '640 GB NVMe Gen4',
    bandwidth: '10 Gbps Dedicated Line',
    popular: false,
    isActive: true
  }
];

export const DEFAULT_VPS_PRICING_TIERS: VpsPricingTier[] = [
  {
    ram: '4 GB',
    priceINR: 700,
    priceUSD: 10,
    vCpu: '2 vCPU AMD EPYC',
    nvme: '80 GB NVMe Gen4',
    bandwidth: '10 Gbps Unmetered',
    popular: false
  },
  {
    ram: '8 GB',
    priceINR: 1399,
    priceUSD: 19,
    vCpu: '4 vCPU AMD EPYC',
    nvme: '160 GB NVMe Gen4',
    bandwidth: '10 Gbps Unmetered',
    popular: true
  },
  {
    ram: '16 GB',
    priceINR: 1799,
    priceUSD: 24,
    vCpu: '8 vCPU AMD Ryzen 9',
    nvme: '320 GB NVMe Gen4',
    bandwidth: '10 Gbps Unmetered',
    popular: false
  },
  {
    ram: '32 GB',
    priceINR: 2500,
    priceUSD: 34,
    vCpu: '16 vCPU AMD Ryzen 9 PRO',
    nvme: '640 GB NVMe Gen4',
    bandwidth: '10 Gbps Unmetered',
    popular: false
  }
];

export function getServerTypeFromItem(item: VpsInventoryItem): ServerTypeKey {
  const cat = (item.category || '').toLowerCase();
  const label = (item.serverLabel || '').toLowerCase();
  const ip = (item.ipRange || '').toLowerCase();
  
  if (cat.includes('diamond') || label.includes('diamond') || ip.includes('diamond')) {
    return 'diamond';
  }
  if (cat.includes('gold') || label.includes('gold') || ip.includes('gold')) {
    return 'gold';
  }
  return 'normal';
}

export const INITIAL_INVENTORY_SEED: VpsInventoryItem[] = [
  {
    _id: 'inv-103-54-26',
    serverId: 'SRV-103-54-26',
    ipRange: '103.54.26',
    serverLabel: 'Mumbai Ultra-Low Latency Node 103.54.26',
    availableStock: 202,
    status: 'active',
    category: 'High-Speed Subnet',
    planType: '8GB',
    location: 'Mumbai Tier-4 (CtrlS)',
    cpu: 'AMD EPYC 7763 (3.8 GHz Turbo)',
    ram: '8 GB',
    storage: '160 GB NVMe Gen4',
    bandwidth: '10 Gbps Unmetered',
    isActive: true
  },
  {
    _id: 'inv-103-186-44',
    serverId: 'SRV-103-186-44',
    ipRange: '103.186.44',
    serverLabel: 'Mumbai High-Throughput Node 103.186.44',
    availableStock: 494,
    status: 'active',
    category: 'High-Speed Subnet',
    planType: '8GB',
    location: 'Mumbai Tier-4 (Equinix)',
    cpu: 'AMD EPYC 7763 (3.8 GHz Turbo)',
    ram: '8 GB',
    storage: '160 GB NVMe Gen4',
    bandwidth: '10 Gbps Unmetered',
    isActive: true
  },
  {
    _id: 'inv-103-227',
    serverId: 'SRV-103-227',
    ipRange: '103.227',
    serverLabel: 'Equinix Bypass Subnet 103.227',
    availableStock: 244,
    status: 'active',
    category: 'High-Speed Subnet',
    planType: '8GB',
    location: 'Mumbai Tier-4 (Equinix)',
    cpu: 'AMD Ryzen 9 7950X',
    ram: '8 GB',
    storage: '160 GB NVMe Gen4',
    bandwidth: '10 Gbps Unmetered',
    isActive: true
  },
  {
    _id: 'inv-103-85-118',
    serverId: 'SRV-103-85-118',
    ipRange: '103.85.118',
    serverLabel: 'Delhi-NCR Zero-Lag Node 103.85.118',
    availableStock: 486,
    status: 'active',
    category: 'High-Speed Subnet',
    planType: '8GB',
    location: 'Delhi-NCR Equinix DC',
    cpu: 'AMD EPYC 7763',
    ram: '8 GB',
    storage: '160 GB NVMe Gen4',
    bandwidth: '10 Gbps Unmetered',
    isActive: true
  },
  {
    _id: 'inv-103-82-73',
    serverId: 'SRV-103-82-73',
    ipRange: '103.82.73',
    serverLabel: 'Direct Gateway Subnet 103.82.73',
    availableStock: 10,
    status: 'active',
    category: 'High-Speed Subnet',
    planType: '8GB',
    location: 'Mumbai Tier-4 (CtrlS)',
    cpu: 'Intel Xeon Platinum 8380',
    ram: '8 GB',
    storage: '160 GB NVMe Gen4',
    bandwidth: '10 Gbps Unmetered',
    isActive: true
  },
  {
    _id: 'inv-103-182-44',
    serverId: 'SRV-103-182-44',
    ipRange: '103.182.44',
    serverLabel: 'Mumbai Low-Ping Direct Node 103.182.44',
    availableStock: 476,
    status: 'active',
    category: 'High-Speed Subnet',
    planType: '8GB',
    location: 'Mumbai Tier-4 (CtrlS)',
    cpu: 'AMD EPYC 7763',
    ram: '8 GB',
    storage: '160 GB NVMe Gen4',
    bandwidth: '10 Gbps Unmetered',
    isActive: true
  },
  {
    _id: 'inv-103-189-147',
    serverId: 'SRV-103-189-147',
    ipRange: '103.189.147',
    serverLabel: 'Express Route Subnet 103.189.147',
    availableStock: 229,
    status: 'active',
    category: 'High-Speed Subnet',
    planType: '8GB',
    location: 'Noida DC3 Datahub',
    cpu: 'AMD EPYC 7763',
    ram: '8 GB',
    storage: '160 GB NVMe Gen4',
    bandwidth: '10 Gbps Unmetered',
    isActive: true
  },
  {
    _id: 'inv-103-82-7x-gold',
    serverId: 'SRV-103-82-7X-GOLD',
    ipRange: '103.82.7x AMD GOLD',
    serverLabel: '103.82.7x AMD GOLD Dedicated Node',
    availableStock: 90,
    status: 'active',
    category: 'Gold Server',
    planType: '16GB',
    location: 'Mumbai Tier-4 (CtrlS)',
    cpu: 'AMD Ryzen 9 7950X (5.7 GHz Boost)',
    ram: '16 GB',
    storage: '320 GB NVMe Gen4',
    bandwidth: '10 Gbps Dedicated Line',
    isActive: true
  },
  {
    _id: 'inv-103-109-18x-gold',
    serverId: 'SRV-103-109-18X-GOLD',
    ipRange: '103.109.18x GOLD SERVER',
    serverLabel: '103.109.18x GOLD SERVER Enterprise Node',
    availableStock: 30,
    status: 'active',
    category: 'Gold Server',
    planType: '16GB',
    location: 'Mumbai Tier-4 (Equinix)',
    cpu: 'AMD EPYC 9654 Genoa 96-Core',
    ram: '16 GB',
    storage: '320 GB NVMe Gen4',
    bandwidth: '10 Gbps Dedicated Line',
    isActive: true
  },
  {
    _id: 'inv-103-195',
    serverId: 'SRV-103-195',
    ipRange: '103.195',
    serverLabel: 'Bangalore Fast Route 103.195',
    availableStock: 236,
    status: 'active',
    category: 'High-Speed Subnet',
    planType: '8GB',
    location: 'Bangalore Netmagic DC',
    cpu: 'AMD EPYC 7763',
    ram: '8 GB',
    storage: '160 GB NVMe Gen4',
    bandwidth: '10 Gbps Unmetered',
    isActive: true
  },
  {
    _id: 'inv-103-93-17x',
    serverId: 'SRV-103-93-17X',
    ipRange: '103.93.17x',
    serverLabel: 'Ultra Turbo Pool 103.93.17x',
    availableStock: 471,
    status: 'active',
    category: 'High-Speed Subnet',
    planType: '8GB',
    location: 'Mumbai Tier-4 (CtrlS)',
    cpu: 'AMD EPYC 7763',
    ram: '8 GB',
    storage: '160 GB NVMe Gen4',
    bandwidth: '10 Gbps Unmetered',
    isActive: true
  },
  {
    _id: 'inv-103-54-gold',
    serverId: 'SRV-103-54-GOLD',
    ipRange: '103.54 GOLD SERVER',
    serverLabel: '103.54 GOLD SERVER Master Node',
    availableStock: 499,
    status: 'active',
    category: 'Gold Server',
    planType: '16GB',
    location: 'Mumbai Tier-4 (CtrlS)',
    cpu: 'AMD Ryzen 9 7950X (Liquid Cooled)',
    ram: '16 GB',
    storage: '320 GB NVMe Gen4',
    bandwidth: '10 Gbps Dedicated Line',
    isActive: true
  },
  {
    _id: 'inv-103-148',
    serverId: 'SRV-103-148',
    ipRange: '103.148',
    serverLabel: 'Mumbai High-Speed Subnet 103.148',
    availableStock: 131,
    status: 'active',
    category: 'High-Speed Subnet',
    planType: '8GB',
    location: 'Mumbai Tier-4 (Equinix)',
    cpu: 'AMD EPYC 7763',
    ram: '8 GB',
    storage: '160 GB NVMe Gen4',
    bandwidth: '10 Gbps Unmetered',
    isActive: true
  },
  {
    _id: 'inv-103-87-gold',
    serverId: 'SRV-103-87-GOLD',
    ipRange: '103.87 GOLD SERVER',
    serverLabel: '103.87 GOLD SERVER Fast-Forward Node',
    availableStock: 459,
    status: 'active',
    category: 'Gold Server',
    planType: '16GB',
    location: 'Mumbai Tier-4 (CtrlS)',
    cpu: 'AMD EPYC 9654 Genoa',
    ram: '16 GB',
    storage: '320 GB NVMe Gen4',
    bandwidth: '10 Gbps Dedicated Line',
    isActive: true
  },
  {
    _id: 'inv-103-103-gold',
    serverId: 'SRV-103-103-GOLD',
    ipRange: '103.103 GOLD SERVER',
    serverLabel: '103.103 GOLD SERVER Low-Jitter Node',
    availableStock: 239,
    status: 'active',
    category: 'Gold Server',
    planType: '16GB',
    location: 'Mumbai Tier-4 (CtrlS)',
    cpu: 'AMD Ryzen 9 7950X',
    ram: '16 GB',
    storage: '320 GB NVMe Gen4',
    bandwidth: '10 Gbps Dedicated Line',
    isActive: true
  },
  {
    _id: 'inv-103-225',
    serverId: 'SRV-103-225',
    ipRange: '103.225',
    serverLabel: 'Delhi-NCR Clean Subnet 103.225',
    availableStock: 50,
    status: 'active',
    category: 'High-Speed Subnet',
    planType: '8GB',
    location: 'Delhi-NCR Equinix DC',
    cpu: 'Intel Xeon Gold 6348',
    ram: '8 GB',
    storage: '160 GB NVMe Gen4',
    bandwidth: '10 Gbps Unmetered',
    isActive: true
  },
  {
    _id: 'inv-103-101',
    serverId: 'SRV-103-101',
    ipRange: '103.101',
    serverLabel: 'Mumbai Zero-Loss Node 103.101',
    availableStock: 108,
    status: 'active',
    category: 'High-Speed Subnet',
    planType: '8GB',
    location: 'Mumbai Tier-4 (CtrlS)',
    cpu: 'AMD EPYC 7763',
    ram: '8 GB',
    storage: '160 GB NVMe Gen4',
    bandwidth: '10 Gbps Unmetered',
    isActive: true
  },
  {
    _id: 'inv-103-204-170',
    serverId: 'SRV-103-204-170',
    ipRange: '103.204.170',
    serverLabel: 'Exclusive VIP Subnet 103.204.170',
    availableStock: 7,
    status: 'active',
    category: 'High-Speed Subnet',
    planType: '8GB',
    location: 'Mumbai Tier-4 (CtrlS)',
    cpu: 'AMD Ryzen 9 7950X (5.7 GHz)',
    ram: '8 GB',
    storage: '160 GB NVMe Gen4',
    bandwidth: '10 Gbps Unmetered',
    isActive: true
  },
  {
    _id: 'inv-103-47-x',
    serverId: 'SRV-103-47-X',
    ipRange: '103.47.x',
    serverLabel: 'Direct ISP Fiber Subnet 103.47.x',
    availableStock: 181,
    status: 'active',
    category: 'High-Speed Subnet',
    planType: '8GB',
    location: 'Noida DC3 Datahub',
    cpu: 'AMD EPYC 7763',
    ram: '8 GB',
    storage: '160 GB NVMe Gen4',
    bandwidth: '10 Gbps Unmetered',
    isActive: true
  },
  {
    _id: 'inv-103-184-diamond',
    serverId: 'SRV-103-184-DIAMOND',
    ipRange: '103.184 DIAMOND PRO AMD',
    serverLabel: '103.184 DIAMOND PRO AMD Flagship',
    availableStock: 488,
    status: 'active',
    category: 'Diamond Pro AMD',
    planType: '32GB',
    location: 'Mumbai Tier-4 (CtrlS Direct Core)',
    cpu: 'AMD EPYC 9654 + Ryzen 9 Turbo Dual Cluster',
    ram: '32 GB',
    storage: '640 GB NVMe Gen4',
    bandwidth: '10 Gbps Dedicated Line',
    isActive: true
  },
  {
    _id: 'inv-43-225-74',
    serverId: 'SRV-43-225-74',
    ipRange: '43.225.74',
    serverLabel: 'Asia Express Subnet 43.225.74',
    availableStock: 230,
    status: 'active',
    category: 'High-Speed Subnet',
    planType: '8GB',
    location: 'Mumbai Tier-4 (Equinix)',
    cpu: 'Intel Xeon Platinum 8380',
    ram: '8 GB',
    storage: '160 GB NVMe Gen4',
    bandwidth: '10 Gbps Unmetered',
    isActive: true
  },
  {
    _id: 'inv-43-240-4',
    serverId: 'SRV-43-240-4',
    ipRange: '43.240.4',
    serverLabel: 'CtrlS Low-Latency Subnet 43.240.4',
    availableStock: 123,
    status: 'active',
    category: 'High-Speed Subnet',
    planType: '8GB',
    location: 'Mumbai Tier-4 (CtrlS)',
    cpu: 'AMD EPYC 7763',
    ram: '8 GB',
    storage: '160 GB NVMe Gen4',
    bandwidth: '10 Gbps Unmetered',
    isActive: true
  },
  {
    _id: 'inv-103-93-213',
    serverId: 'SRV-103-93-213',
    ipRange: '103.93.213',
    serverLabel: 'Mumbai Turbo Fiber 103.93.213',
    availableStock: 229,
    status: 'active',
    category: 'High-Speed Subnet',
    planType: '8GB',
    location: 'Mumbai Tier-4 (CtrlS)',
    cpu: 'AMD EPYC 7763',
    ram: '8 GB',
    storage: '160 GB NVMe Gen4',
    bandwidth: '10 Gbps Unmetered',
    isActive: true
  },
  {
    _id: 'inv-103-181-91',
    serverId: 'SRV-103-181-91',
    ipRange: '103.181.91',
    serverLabel: 'Direct Datacenter Node 103.181.91',
    availableStock: 259,
    status: 'active',
    category: 'High-Speed Subnet',
    planType: '8GB',
    location: 'Mumbai Tier-4 (Equinix)',
    cpu: 'AMD EPYC 7763',
    ram: '8 GB',
    storage: '160 GB NVMe Gen4',
    bandwidth: '10 Gbps Unmetered',
    isActive: true
  }
];

const MONGO_COLLECTION_KEY = 'tsm_mongodb_inventory';
const MONGO_PRICING_KEY = 'tsm_mongodb_vps_pricing';
const MONGO_CATEGORY_PLANS_KEY = 'tsm_mongodb_category_plans';
const MONGO_SERVER_CATEGORIES_KEY = 'tsm_mongodb_server_categories';

export class MongoInventoryDatabase {
  private collectionName = 'inventory';

  // Load collection from storage or seed defaults
  public getInventory(): VpsInventoryItem[] {
    try {
      const saved = localStorage.getItem(MONGO_COLLECTION_KEY);
      if (saved) {
        const parsed: VpsInventoryItem[] = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) {
          return parsed;
        }
      }
    } catch (e) {
      console.warn('Error reading MongoDB inventory cache, re-initializing defaults', e);
    }
    
    // Seed initial inventory
    this.saveInventory(INITIAL_INVENTORY_SEED);
    return INITIAL_INVENTORY_SEED;
  }

  public saveInventory(items: VpsInventoryItem[]): void {
    try {
      localStorage.setItem(MONGO_COLLECTION_KEY, JSON.stringify(items));
    } catch (e) {
      console.error('Failed to save to MongoDB inventory storage', e);
    }
  }

  public findOne(query: { serverId?: string; ipRange?: string; _id?: string }): VpsInventoryItem | undefined {
    const items = this.getInventory();
    return items.find(item => {
      if (query._id && item._id === query._id) return true;
      if (query.serverId && item.serverId === query.serverId) return true;
      if (query.ipRange && item.ipRange.toLowerCase() === query.ipRange.toLowerCase()) return true;
      return false;
    });
  }

  public insertOne(item: Omit<VpsInventoryItem, '_id'> & { _id?: string }): VpsInventoryItem {
    const items = this.getInventory();
    const newItem: VpsInventoryItem = {
      ...item,
      _id: item._id || `inv-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    items.unshift(newItem);
    this.saveInventory(items);
    return newItem;
  }

  public updateOne(idOrServerId: string, updates: Partial<VpsInventoryItem>): VpsInventoryItem | null {
    const items = this.getInventory();
    const index = items.findIndex(i => i._id === idOrServerId || i.serverId === idOrServerId);
    if (index === -1) return null;

    const updated = {
      ...items[index],
      ...updates,
      updatedAt: new Date().toISOString()
    };
    
    // Auto sync status if stock changed
    if (typeof updated.availableStock === 'number') {
      if (updated.availableStock <= 0) {
        updated.status = 'out_of_stock';
      } else if (updated.status === 'out_of_stock') {
        updated.status = 'active';
      }
    }

    items[index] = updated;
    this.saveInventory(items);
    return updated;
  }

  public deleteOne(idOrServerId: string): boolean {
    const items = this.getInventory();
    const filtered = items.filter(i => i._id !== idOrServerId && i.serverId !== idOrServerId);
    if (filtered.length !== items.length) {
      this.saveInventory(filtered);
      return true;
    }
    return false;
  }

  public decrementStock(idOrServerId: string, qty: number = 1): { success: boolean; remainingStock: number; item?: VpsInventoryItem } {
    const items = this.getInventory();
    const index = items.findIndex(i => i._id === idOrServerId || i.serverId === idOrServerId || i.ipRange === idOrServerId);
    if (index === -1) return { success: false, remainingStock: 0 };

    const item = items[index];
    if (item.availableStock < qty) {
      return { success: false, remainingStock: item.availableStock, item };
    }

    item.availableStock -= qty;
    if (item.availableStock <= 0) {
      item.availableStock = 0;
      item.status = 'out_of_stock';
    }
    item.updatedAt = new Date().toISOString();
    items[index] = item;
    this.saveInventory(items);
    return { success: true, remainingStock: item.availableStock, item };
  }

  public incrementStock(idOrServerId: string, qty: number = 1): { success: boolean; newStock: number; item?: VpsInventoryItem } {
    const items = this.getInventory();
    const index = items.findIndex(i => i._id === idOrServerId || i.serverId === idOrServerId || i.ipRange === idOrServerId);
    if (index === -1) return { success: false, newStock: 0 };

    const item = items[index];
    item.availableStock += qty;
    if (item.availableStock > 0 && item.status === 'out_of_stock') {
      item.status = 'active';
    }
    item.updatedAt = new Date().toISOString();
    items[index] = item;
    this.saveInventory(items);
    return { success: true, newStock: item.availableStock, item };
  }

  public bulkImport(rawInput: string): { importedCount: number; errors: string[] } {
    const lines = rawInput.split('\n').map(l => l.trim()).filter(Boolean);
    const errors: string[] = [];
    let count = 0;

    const currentItems = this.getInventory();

    for (const line of lines) {
      try {
        let ipPart = '';
        let stockPart = 50;

        if (line.includes('- Stock') || line.includes('- stock') || line.includes('Stock') || line.includes('stock')) {
          const parts = line.split(/[-–—]/);
          if (parts.length >= 2) {
            ipPart = parts[0].trim();
            const stockMatch = parts[1].match(/\d+/);
            if (stockMatch) {
              stockPart = parseInt(stockMatch[0], 10);
            }
          } else {
            const match = line.match(/(.*?)\s*[-–—]?\s*[Ss]tock\s*(\d+)/);
            if (match) {
              ipPart = match[1].trim();
              stockPart = parseInt(match[2], 10);
            }
          }
        } else if (line.includes(',') || line.includes('\t')) {
          const split = line.split(/[,\t]/);
          ipPart = split[0].trim();
          if (split[1]) {
            const num = parseInt(split[1].trim(), 10);
            if (!isNaN(num)) stockPart = num;
          }
        } else {
          ipPart = line.trim();
        }

        if (!ipPart) continue;

        const existingIdx = currentItems.findIndex(i => i.ipRange.toLowerCase() === ipPart.toLowerCase());
        const isGold = ipPart.toUpperCase().includes('GOLD');
        const isDiamond = ipPart.toUpperCase().includes('DIAMOND');
        const category = isDiamond ? 'Diamond Pro AMD' : isGold ? 'Gold Server' : 'High-Speed Subnet';

        if (existingIdx >= 0) {
          currentItems[existingIdx].availableStock = stockPart;
          currentItems[existingIdx].status = stockPart > 0 ? 'active' : 'out_of_stock';
          currentItems[existingIdx].updatedAt = new Date().toISOString();
        } else {
          const cleanId = ipPart.toLowerCase().replace(/[^a-z0-9]/g, '-');
          currentItems.unshift({
            _id: `inv-${cleanId}-${Date.now()}`,
            serverId: `SRV-${cleanId.toUpperCase()}`,
            ipRange: ipPart,
            serverLabel: `${ipPart} High-Speed Node`,
            availableStock: stockPart,
            status: stockPart > 0 ? 'active' : 'out_of_stock',
            category,
            planType: isDiamond ? '32GB' : isGold ? '16GB' : '8GB',
            location: 'Mumbai Tier-4 (CtrlS)',
            cpu: isDiamond ? 'AMD EPYC 9654 + Ryzen 9 Dual' : isGold ? 'AMD Ryzen 9 7950X' : 'AMD EPYC 7763',
            ram: isDiamond ? '32 GB' : isGold ? '16 GB' : '8 GB',
            storage: isDiamond ? '640 GB NVMe' : isGold ? '320 GB NVMe' : '160 GB NVMe',
            bandwidth: '10 Gbps Unmetered',
            isActive: true,
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString()
          });
        }
        count++;
      } catch (err: any) {
        errors.push(`Failed to parse line "${line}": ${err?.message || 'Unknown error'}`);
      }
    }

    this.saveInventory(currentItems);
    return { importedCount: count, errors };
  }

  // =========================================================================
  // CATEGORY PLANS (MongoDB Dynamic Pricing Collection)
  // =========================================================================
  public getCategoryPlans(): VpsCategoryPlan[] {
    try {
      const saved = localStorage.getItem(MONGO_CATEGORY_PLANS_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch (e) {
      console.warn('Error reading category plans from MongoDB cache', e);
    }
    this.saveCategoryPlans(DEFAULT_CATEGORY_PLANS);
    return DEFAULT_CATEGORY_PLANS;
  }

  public saveCategoryPlans(plans: VpsCategoryPlan[]): void {
    try {
      localStorage.setItem(MONGO_CATEGORY_PLANS_KEY, JSON.stringify(plans));
    } catch (e) {
      console.error('Failed to save category plans to storage', e);
    }
  }

  public updateCategoryPlan(id: string, updates: Partial<VpsCategoryPlan>): VpsCategoryPlan | null {
    const plans = this.getCategoryPlans();
    const index = plans.findIndex(p => p.id === id);
    if (index === -1) return null;

    const updated: VpsCategoryPlan = {
      ...plans[index],
      ...updates
    };
    if (typeof updates.priceINR === 'number' && typeof updates.priceUSD !== 'number') {
      updated.priceUSD = Math.max(1, Math.round(updates.priceINR / 75));
    }

    plans[index] = updated;
    this.saveCategoryPlans(plans);
    return updated;
  }

  public addCategoryPlan(plan: Omit<VpsCategoryPlan, 'id'> & { id?: string }): VpsCategoryPlan {
    const plans = this.getCategoryPlans();
    const newPlan: VpsCategoryPlan = {
      ...plan,
      id: plan.id || `plan-${plan.serverType}-${plan.ram.replace(/\s+/g, '').toLowerCase()}-${Date.now()}`
    };
    plans.push(newPlan);
    this.saveCategoryPlans(plans);
    return newPlan;
  }

  public deleteCategoryPlan(id: string): boolean {
    const plans = this.getCategoryPlans();
    const filtered = plans.filter(p => p.id !== id);
    if (filtered.length !== plans.length) {
      this.saveCategoryPlans(filtered);
      return true;
    }
    return false;
  }

  public toggleCategoryPlanActive(id: string): VpsCategoryPlan | null {
    const plans = this.getCategoryPlans();
    const index = plans.findIndex(p => p.id === id);
    if (index === -1) return null;
    plans[index].isActive = !plans[index].isActive;
    this.saveCategoryPlans(plans);
    return plans[index];
  }

  // =========================================================================
  // SERVER CATEGORIES (MongoDB Server Categories Collection)
  // =========================================================================
  public getServerCategories(): VpsServerCategoryMeta[] {
    try {
      const saved = localStorage.getItem(MONGO_SERVER_CATEGORIES_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch (e) {
      console.warn('Error reading server categories from storage', e);
    }
    this.saveServerCategories(DEFAULT_SERVER_CATEGORIES);
    return DEFAULT_SERVER_CATEGORIES;
  }

  public saveServerCategories(cats: VpsServerCategoryMeta[]): void {
    try {
      localStorage.setItem(MONGO_SERVER_CATEGORIES_KEY, JSON.stringify(cats));
    } catch (e) {
      console.error('Failed to save server categories to storage', e);
    }
  }

  public updateServerCategory(id: string, updates: Partial<VpsServerCategoryMeta>): VpsServerCategoryMeta | null {
    const cats = this.getServerCategories();
    const index = cats.findIndex(c => c.id === id || c.serverType === id);
    if (index === -1) return null;
    const updated = {
      ...cats[index],
      ...updates
    };
    cats[index] = updated;
    this.saveServerCategories(cats);
    return updated;
  }

  // =========================================================================
  // Helper Queries for Frontend Dynamic Resolution
  // =========================================================================
  public getPlansForServerType(serverType: ServerTypeKey): VpsCategoryPlan[] {
    const plans = this.getCategoryPlans();
    return plans.filter(p => p.serverType === serverType && p.isActive);
  }

  public getStartingPriceForServerType(serverType: ServerTypeKey): number {
    const plans = this.getPlansForServerType(serverType);
    if (plans.length === 0) return serverType === 'diamond' ? 2799 : serverType === 'gold' ? 1500 : 700;
    return Math.min(...plans.map(p => p.priceINR));
  }

  // Legacy Pricing Tiers helper
  public getPricingTiers(): VpsPricingTier[] {
    try {
      const saved = localStorage.getItem(MONGO_PRICING_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch (e) {
      console.warn('Error reading pricing tiers from storage', e);
    }
    return DEFAULT_VPS_PRICING_TIERS;
  }

  public savePricingTiers(tiers: VpsPricingTier[]): void {
    try {
      localStorage.setItem(MONGO_PRICING_KEY, JSON.stringify(tiers));
    } catch (e) {
      console.error('Failed to save pricing tiers to storage', e);
    }
  }

  public resetToDefaults(): void {
    this.saveInventory(INITIAL_INVENTORY_SEED);
    this.saveCategoryPlans(DEFAULT_CATEGORY_PLANS);
    this.saveServerCategories(DEFAULT_SERVER_CATEGORIES);
    this.savePricingTiers(DEFAULT_VPS_PRICING_TIERS);
  }
}

export const inventoryDb = new MongoInventoryDatabase();
