import React, { useEffect } from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Navbar } from './components/layout/Navbar';
import { Footer } from './components/layout/Footer';
import { TelegramWidget } from './components/common/TelegramWidget';
import { CheckoutModal } from './components/common/CheckoutModal';
import { InvoiceModal } from './components/common/InvoiceModal';
import { DemoRequestModal } from './components/common/DemoRequestModal';
import { ServerConsoleModal } from './components/common/ServerConsoleModal';
import { AuthModal } from './components/common/AuthModal';
import { ToastContainer } from './components/common/ToastContainer';

// Page Views
import { HomePage } from './components/pages/HomePage';
import { TatkalSoftwarePage } from './components/pages/TatkalSoftwarePage';
import { VpsHostingPage } from './components/pages/VpsHostingPage';
import { IpServicesPage } from './components/pages/IpServicesPage';
import { AboutUsPage } from './components/pages/AboutUsPage';
import { ContactPage } from './components/pages/ContactPage';
import { OrderTrackingPage } from './components/pages/OrderTrackingPage';
import { CustomerDashboard } from './components/pages/CustomerDashboard';
import { AdminDashboard } from './components/pages/AdminDashboard';
import { ResellerDashboard } from './components/pages/ResellerDashboard';

const MainContent: React.FC = () => {
  const { currentPage } = useApp();

  // Scroll to top whenever the page changes
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'instant' });
  }, [currentPage]);

  const renderPage = () => {
    switch (currentPage) {
      case 'home':
        return <HomePage />;
      case 'tatkal-software':
        return <TatkalSoftwarePage />;
      case 'vps-hosting':
        return <VpsHostingPage />;
      case 'ip-services':
        return <IpServicesPage />;
      case 'about-us':
        return <AboutUsPage />;
      case 'contact':
        return <ContactPage />;
      case 'order-tracking':
        return <OrderTrackingPage />;
      case 'dashboard':
        return <CustomerDashboard />;
      case 'admin':
        return <AdminDashboard />;
      case 'reseller':
        return <ResellerDashboard />;
      default:
        return <HomePage />;
    }
  };

  return (
    <div className="min-h-screen bg-[#050811] text-slate-100 flex flex-col selection:bg-blue-600 selection:text-white">
      <Navbar />
      
      <main className="flex-1">
        {renderPage()}
      </main>

      <Footer />

      {/* Global Modals and Overlays */}
      <CheckoutModal />
      <InvoiceModal />
      <DemoRequestModal />
      <ServerConsoleModal />
      <AuthModal />
      <TelegramWidget />
      <ToastContainer />
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <MainContent />
    </AppProvider>
  );
}
