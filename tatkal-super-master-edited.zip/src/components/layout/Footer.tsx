import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { 
  Zap, 
  ShieldCheck, 
  Lock, 
  CreditCard, 
  Send, 
  MessageSquare, 
  Server, 
  Globe, 
  Cpu, 
  HelpCircle,
  CheckCircle2,
  FileText
} from 'lucide-react';
import { PageView } from '../../types';

export const Footer: React.FC<{ onOpenSitemap?: () => void }> = ({ onOpenSitemap }) => {
  const { setCurrentPage, addToast } = useApp();
  const [newsletterEmail, setNewsletterEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (newsletterEmail && newsletterEmail.includes('@')) {
      setSubscribed(true);
      addToast('success', 'Subscribed!', 'You will receive low-latency node updates and exclusive Tatkal software discount coupons.');
      setNewsletterEmail('');
    }
  };

  const navigateTo = (page: PageView) => {
    setCurrentPage(page);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="relative bg-[#03060d] border-t border-slate-800/80 text-slate-400 text-sm overflow-hidden">
      {/* Glow highlight */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-3/4 h-[1px] bg-gradient-to-r from-transparent via-blue-500/50 to-transparent" />

      {/* Main Footer Container */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-16 pb-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-10">
          
          {/* Column 1: Brand Info */}
          <div className="lg:col-span-2 space-y-4">
            <div 
              onClick={() => navigateTo('home')} 
              className="flex items-center space-x-3 cursor-pointer group select-none"
            >
              <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-blue-600 to-cyan-400 p-[2px] shadow-lg shadow-blue-500/20">
                <div className="w-full h-full bg-[#070b16] rounded-[10px] flex items-center justify-center">
                  <Zap className="w-5 h-5 text-cyan-400" />
                </div>
              </div>
              <div>
                <span className="text-xl font-extrabold tracking-tight text-white">TATKAL </span>
                <span className="text-xl font-extrabold tracking-tight text-blue-500">SUPER MASTER</span>
              </div>
            </div>

            <p className="text-xs sm:text-sm text-slate-400 leading-relaxed max-w-sm">
              India's #1 premium automation software platform, low-latency Mumbai Windows VPS hosting, 
              residential clean IP proxies, and ultra-high-speed RDP dedicated infrastructure.
            </p>

            <div className="flex flex-wrap gap-2 pt-1">
              <span className="inline-flex items-center space-x-1 px-2.5 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs font-semibold">
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>99.99% Network SLA</span>
              </span>
              <span className="inline-flex items-center space-x-1 px-2.5 py-1 rounded-full bg-blue-500/10 border border-blue-500/20 text-blue-400 text-xs font-semibold">
                <ShieldCheck className="w-3.5 h-3.5" />
                <span>Instant &lt;60s Delivery</span>
              </span>
            </div>

            {/* Direct Social / Support Channels */}
            <div className="pt-3 space-y-2">
              <p className="text-xs font-bold text-white uppercase tracking-wider">Fast Support Desks</p>
              <div className="flex items-center space-x-3">
                <a 
                  href="https://t.me/tatkalsupermaster919876543210?text=Hi%20Tatkal%20Super%20Master%2C%20I%20want%20to%20inquire%20about%20Tatkal%20Software%20and%20VPS" 
                  target="_blank" 
                  rel="noreferrer"
                  className="flex items-center space-x-1.5 px-3 py-1.5 rounded-lg bg-emerald-600/20 border border-emerald-500/30 text-emerald-300 hover:bg-emerald-600/30 text-xs font-semibold transition-all"
                >
                  <MessageSquare className="w-4 h-4 text-emerald-400" />
                  <span>Telegram Support</span>
                </a>
                <a 
                  href="https://t.me/tatkalsupermastertatkalsupermaster" 
                  target="_blank" 
                  rel="noreferrer"
                  className="flex items-center space-x-1.5 px-3 py-1.5 rounded-lg bg-cyan-600/20 border border-cyan-500/30 text-cyan-300 hover:bg-cyan-600/30 text-xs font-semibold transition-all"
                >
                  <Send className="w-4 h-4 text-cyan-400" />
                  <span>Telegram Channel</span>
                </a>
              </div>
            </div>
          </div>

          {/* Column 2: Solutions & Software */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-white">Solutions & Software</h4>
            <ul className="space-y-2 text-xs">
              <li>
                <button onClick={() => navigateTo('tatkal-software')} className="hover:text-blue-400 transition-colors">
                  Tatkal Super Master PRO
                </button>
              </li>
              <li>
                <button onClick={() => navigateTo('tatkal-software')} className="hover:text-blue-400 transition-colors">
                  Tatkal Lite Starter Edition
                </button>
              </li>
              <li>
                <button onClick={() => navigateTo('tatkal-software')} className="hover:text-blue-400 transition-colors">
                  Enterprise Agency Suite
                </button>
              </li>
              <li>
                <button onClick={() => navigateTo('tatkal-software')} className="hover:text-blue-400 transition-colors">
                  Auto Captcha Solver Engine
                </button>
              </li>
              <li>
                <button onClick={() => navigateTo('tatkal-software')} className="hover:text-blue-400 transition-colors">
                  Master List Fast Sync
                </button>
              </li>
            </ul>
          </div>

          {/* Column 3: VPS & Cloud Hosting */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-white">VPS & IP Infrastructure</h4>
            <ul className="space-y-2 text-xs">
              <li>
                <button onClick={() => navigateTo('vps-hosting')} className="hover:text-blue-400 transition-colors">
                  Windows VPS (Mumbai Equinix)
                </button>
              </li>
              <li>
                <button onClick={() => navigateTo('vps-hosting')} className="hover:text-blue-400 transition-colors">
                  Linux Cloud Automation Nodes
                </button>
              </li>
              <li>
                <button onClick={() => navigateTo('ip-services')} className="hover:text-blue-400 transition-colors">
                  Residential Clean IPs (Jio/Airtel)
                </button>
              </li>
              <li>
                <button onClick={() => navigateTo('ip-services')} className="hover:text-blue-400 transition-colors">
                  Static Dedicated IPv4
                </button>
              </li>
              <li>
                <button onClick={() => navigateTo('ip-services')} className="hover:text-blue-400 transition-colors">
                  Datacenter 10Gbps Proxies
                </button>
              </li>
              <li>
                <button onClick={() => navigateTo('vps-hosting')} className="hover:text-blue-400 transition-colors">
                  Bare-Metal Dedicated Servers
                </button>
              </li>
            </ul>
          </div>

          {/* Column 4: Quick Links & Tools */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-white">Client Hub & Tools</h4>
            <ul className="space-y-2 text-xs">
              <li>
                <button onClick={() => navigateTo('order-tracking')} className="hover:text-blue-400 transition-colors">
                  Track Order Status
                </button>
              </li>
              <li>
                <button onClick={() => navigateTo('dashboard')} className="hover:text-blue-400 transition-colors">
                  Client Dashboard & Licenses
                </button>
              </li>
              <li>
                <button onClick={() => navigateTo('about-us')} className="hover:text-blue-400 transition-colors">
                  About Our Infrastructure
                </button>
              </li>
              <li>
                <button onClick={() => navigateTo('contact')} className="hover:text-blue-400 transition-colors">
                  Help Center & FAQs
                </button>
              </li>
              <li>
                <button onClick={() => navigateTo('admin')} className="hover:text-amber-400 text-slate-500 transition-colors">
                  Admin Control Panel (Demo)
                </button>
              </li>
            </ul>

            {/* Newsletter */}
            <div className="pt-2">
              <p className="text-xs text-slate-300 font-semibold mb-1.5">Get Coupon Updates</p>
              <form onSubmit={handleSubscribe} className="flex items-center space-x-1">
                <input
                  type="email"
                  value={newsletterEmail}
                  onChange={(e) => setNewsletterEmail(e.target.value)}
                  placeholder="Enter email..."
                  className="w-full bg-slate-900 border border-slate-800 rounded px-2.5 py-1.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-blue-500"
                />
                <button
                  type="submit"
                  className="bg-blue-600 hover:bg-blue-500 text-white px-2.5 py-1.5 rounded text-xs font-bold transition-all"
                >
                  Join
                </button>
              </form>
            </div>
          </div>
        </div>

        {/* Accepted Payment Badges Bar */}
        <div className="mt-12 pt-8 border-t border-slate-800/80 flex flex-wrap items-center justify-between gap-4">
          <div className="flex flex-wrap items-center gap-3 text-xs text-slate-400">
            <span className="font-semibold text-slate-300 flex items-center space-x-1">
              <Lock className="w-3.5 h-3.5 text-emerald-400" />
              <span>100% Secure Instant Payments:</span>
            </span>
            <div className="flex items-center space-x-2 bg-slate-900/90 border border-slate-800 px-3 py-1 rounded-md text-xs font-mono text-slate-300">
              <span className="text-blue-400 font-bold">UPI</span>
              <span>•</span>
              <span className="text-emerald-400 font-bold">Google Pay</span>
              <span>•</span>
              <span className="text-indigo-400 font-bold">PhonePe</span>
              <span>•</span>
              <span className="text-cyan-400 font-bold">Paytm</span>
              <span>•</span>
              <span className="text-purple-400 font-bold">Cards & NetBanking</span>
            </div>
          </div>

          <div className="flex items-center space-x-4 text-xs text-slate-500">
            <span>256-Bit SSL Encrypted</span>
            <span>•</span>
            <span>Razorpay Verified Merchant</span>
          </div>
        </div>

        {/* Bottom Copyright */}
        <div className="mt-6 pt-6 border-t border-slate-800/40 flex flex-col sm:flex-row items-center justify-between text-xs text-slate-500 gap-3">
          <p>© {new Date().getFullYear()} TATKAL SUPER MASTER. All Rights Reserved. Not affiliated with IRCTC or Indian Railways.</p>
          <div className="flex items-center space-x-4">
            <button onClick={() => navigateTo('about-us')} className="hover:text-slate-300 transition-colors">Privacy Policy</button>
            <button onClick={() => navigateTo('about-us')} className="hover:text-slate-300 transition-colors">Terms of Service</button>
            <button onClick={() => navigateTo('about-us')} className="hover:text-slate-300 transition-colors">Refund SLA</button>
          </div>
        </div>
      </div>
    </footer>
  );
};
