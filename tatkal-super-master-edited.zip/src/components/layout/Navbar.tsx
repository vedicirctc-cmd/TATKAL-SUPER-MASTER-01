import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { 
  Server, 
  ShieldCheck, 
  Globe, 
  Zap, 
  User as UserIcon, 
  Menu, 
  X, 
  ChevronDown, 
  Sparkles, 
  Search, 
  Sliders, 
  LogOut, 
  LayoutDashboard, 
  ShieldAlert,
  FileText
} from 'lucide-react';
import { PageView } from '../../types';

export const Navbar: React.FC = () => {
  const { 
    currentPage, 
    setCurrentPage, 
    currency, 
    setCurrency, 
    user, 
    logout, 
    setIsAuthModalOpen, 
    setAuthModalMode,
    switchRole,
    setTrackOrderNumber
  } = useApp();

  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [userDropdownOpen, setUserDropdownOpen] = useState(false);
  const [quickTrackInput, setQuickTrackInput] = useState('');

  const navItems: { label: string; page: PageView; icon?: React.ReactNode; badge?: string }[] = [
    { label: 'Home', page: 'home' },
    { label: 'Tatkal Software', page: 'tatkal-software', badge: 'v4.8 Turbo' },
    { label: 'VPS Hosting', page: 'vps-hosting', badge: '10Gbps' },
    { label: 'IP Services', page: 'ip-services', badge: 'Clean ISP' },
    { label: 'Reseller B2B', page: 'reseller', badge: 'Wholesale' },
    { label: 'Track Order', page: 'order-tracking' },
    { label: 'Contact', page: 'contact' },
  ];

  const handleNavClick = (page: PageView) => {
    setCurrentPage(page);
    setMobileMenuOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleQuickTrack = (e: React.FormEvent) => {
    e.preventDefault();
    if (quickTrackInput.trim()) {
      setTrackOrderNumber(quickTrackInput.trim());
      setCurrentPage('order-tracking');
      setQuickTrackInput('');
    }
  };

  return (
    <header className="sticky top-0 z-50 w-full backdrop-blur-xl bg-[#050811]/90 border-b border-blue-900/20 transition-all">
      {/* Top Banner Alert Bar */}
      <div className="bg-gradient-to-r from-blue-950/80 via-slate-900/90 to-blue-950/80 border-b border-blue-500/10 text-xs py-1.5 px-4">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center space-x-2 text-slate-300">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
            </span>
            <span className="font-semibold text-emerald-400">LIVE STATUS:</span>
            <span className="hidden sm:inline text-slate-300">
              Mumbai Equinix MB2 & CtrlS 10Gbps Nodes Active — IRCTC Gateway Latency: <strong className="text-white font-mono">1.4ms</strong>
            </span>
            <span className="sm:hidden text-slate-300">
              Mumbai Nodes Live (<strong className="text-white">1.4ms</strong>)
            </span>
          </div>

          <div className="flex items-center space-x-4 text-slate-400">
            <div className="flex items-center space-x-1 hover:text-white transition-colors cursor-pointer" onClick={() => handleNavClick('contact')}>
              <span className="text-emerald-400 text-[11px] font-bold">⚡ 24/7 Telegram & Telegram Support</span>
            </div>
            <div className="hidden md:flex items-center space-x-1 text-slate-400 border-l border-slate-700 pl-3">
              <span>Auto-Activation:</span>
              <span className="text-blue-400 font-medium">Instant &lt;60s</span>
            </div>
          </div>
        </div>
      </div>

      {/* Main Navigation Bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          {/* Logo */}
          <div 
            id="nav-brand-logo"
            onClick={() => handleNavClick('home')} 
            className="flex items-center space-x-3 cursor-pointer group select-none"
          >
            <div className="relative w-11 h-11 rounded-xl bg-gradient-to-tr from-blue-600 via-indigo-600 to-cyan-400 p-[2px] shadow-lg shadow-blue-500/20 group-hover:shadow-blue-500/40 transition-all duration-300">
              <div className="w-full h-full bg-[#070b16] rounded-[10px] flex items-center justify-center">
                <Zap className="w-6 h-6 text-cyan-400 group-hover:scale-110 transition-transform duration-300" />
              </div>
            </div>
            <div className="flex flex-col">
              <div className="flex items-center space-x-1.5">
                <span className="text-xl sm:text-2xl font-extrabold tracking-tight bg-gradient-to-r from-white via-slate-100 to-blue-300 bg-clip-text text-transparent">
                  TATKAL
                </span>
                <span className="text-xl sm:text-2xl font-extrabold tracking-tight text-blue-500">
                  SUPER MASTER
                </span>
              </div>
              <span className="text-[10px] font-medium tracking-wider uppercase text-slate-400 group-hover:text-blue-400 transition-colors">
                Professional VPS & IP Solutions
              </span>
            </div>
          </div>

          {/* Desktop Nav Links */}
          <nav className="hidden lg:flex items-center space-x-1 xl:space-x-2">
            {navItems.map((item) => {
              const isActive = currentPage === item.page;
              return (
                <button
                  key={item.page}
                  id={`nav-link-${item.page}`}
                  onClick={() => handleNavClick(item.page)}
                  className={`relative px-3.5 py-2 rounded-lg text-sm font-medium transition-all duration-200 flex items-center space-x-1.5 ${
                    isActive 
                      ? 'text-white bg-blue-600/15 border border-blue-500/30 shadow-[0_0_15px_rgba(59,130,246,0.15)]' 
                      : 'text-slate-300 hover:text-white hover:bg-slate-800/40'
                  }`}
                >
                  <span>{item.label}</span>
                  {item.badge && (
                    <span className={`text-[10px] px-1.5 py-0.5 rounded font-mono font-semibold ${
                      item.badge.includes('Turbo') || item.badge.includes('10Gbps')
                        ? 'bg-blue-500/20 text-blue-400 border border-blue-500/30'
                        : 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                    }`}>
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </nav>

          {/* Right Action Section */}
          <div className="hidden sm:flex items-center space-x-3">
            {/* Currency Selector */}
            <div className="flex items-center bg-slate-900/80 border border-slate-800 rounded-lg p-0.5 text-xs font-semibold">
              <button
                id="currency-inr-btn"
                onClick={() => setCurrency('INR')}
                className={`px-2.5 py-1 rounded-md transition-all ${
                  currency === 'INR' ? 'bg-blue-600 text-white shadow-sm' : 'text-slate-400 hover:text-white'
                }`}
              >
                ₹ INR
              </button>
              <button
                id="currency-usd-btn"
                onClick={() => setCurrency('USD')}
                className={`px-2.5 py-1 rounded-md transition-all ${
                  currency === 'USD' ? 'bg-blue-600 text-white shadow-sm' : 'text-slate-400 hover:text-white'
                }`}
              >
                $ USD
              </button>
            </div>

            {/* Auth / Account Controls */}
            {user ? (
              <div className="relative">
                <button
                  id="user-profile-menu-btn"
                  onClick={() => setUserDropdownOpen(!userDropdownOpen)}
                  className="flex items-center space-x-2.5 px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-800 hover:border-blue-500/40 transition-all text-sm"
                >
                  <img
                    src={user.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80'}
                    alt={user.name}
                    className="w-7 h-7 rounded-full object-cover ring-1 ring-blue-500/50"
                  />
                  <div className="text-left hidden md:block">
                    <div className="text-xs font-bold text-white leading-tight flex items-center space-x-1">
                      <span>{user.name}</span>
                      {user.role === 'admin' && (
                        <span className="text-[9px] bg-red-500/20 text-red-400 border border-red-500/30 px-1 rounded">ADMIN</span>
                      )}
                    </div>
                    <div className="text-[10px] text-slate-400 font-mono">₹{user.walletBalance} Balance</div>
                  </div>
                  <ChevronDown className="w-4 h-4 text-slate-400" />
                </button>

                {userDropdownOpen && (
                  <div 
                    id="user-dropdown-menu"
                    className="absolute right-0 mt-2 w-64 rounded-xl bg-[#0b1120] border border-slate-800 shadow-2xl p-2 z-50 divide-y divide-slate-800/80 animate-in fade-in zoom-in-95 duration-150"
                    onMouseLeave={() => setUserDropdownOpen(false)}
                  >
                    <div className="px-3 py-2">
                      <p className="text-xs font-medium text-slate-400">Signed in as</p>
                      <p className="text-sm font-bold text-white truncate">{user.email}</p>
                      <div className="mt-1.5 flex items-center justify-between bg-slate-900/90 rounded-md p-1.5 border border-slate-800 text-xs">
                        <span className="text-slate-400">Wallet Credits</span>
                        <span className="font-mono font-bold text-emerald-400">₹{user.walletBalance}</span>
                      </div>
                    </div>

                    <div className="py-1">
                      <button
                        id="dropdown-dashboard-link"
                        onClick={() => {
                          handleNavClick('dashboard');
                          setUserDropdownOpen(false);
                        }}
                        className="w-full flex items-center space-x-2.5 px-3 py-2 text-xs font-medium text-slate-300 hover:text-white hover:bg-slate-800/70 rounded-lg transition-colors"
                      >
                        <LayoutDashboard className="w-4 h-4 text-blue-400" />
                        <span>Client Dashboard</span>
                      </button>

                      <button
                        id="dropdown-reseller-link"
                        onClick={() => {
                          handleNavClick('reseller');
                          setUserDropdownOpen(false);
                        }}
                        className="w-full flex items-center space-x-2.5 px-3 py-2 text-xs font-medium text-slate-300 hover:text-white hover:bg-slate-800/70 rounded-lg transition-colors"
                      >
                        <Sparkles className="w-4 h-4 text-amber-400" />
                        <span>Reseller Wholesale Portal</span>
                      </button>

                      <button
                        id="dropdown-orders-link"
                        onClick={() => {
                          handleNavClick('order-tracking');
                          setUserDropdownOpen(false);
                        }}
                        className="w-full flex items-center space-x-2.5 px-3 py-2 text-xs font-medium text-slate-300 hover:text-white hover:bg-slate-800/70 rounded-lg transition-colors"
                      >
                        <FileText className="w-4 h-4 text-cyan-400" />
                        <span>Track Orders & Invoices</span>
                      </button>

                      <button
                        id="dropdown-admin-link"
                        onClick={() => {
                          switchRole('admin');
                          setUserDropdownOpen(false);
                        }}
                        className="w-full flex items-center space-x-2.5 px-3 py-2 text-xs font-medium text-slate-300 hover:text-white hover:bg-slate-800/70 rounded-lg transition-colors"
                      >
                        <ShieldAlert className="w-4 h-4 text-amber-400" />
                        <span>Admin Management Panel</span>
                      </button>
                    </div>

                    <div className="pt-1">
                      <button
                        id="dropdown-logout-btn"
                        onClick={() => {
                          logout();
                          setUserDropdownOpen(false);
                        }}
                        className="w-full flex items-center space-x-2.5 px-3 py-2 text-xs font-medium text-red-400 hover:bg-red-500/10 rounded-lg transition-colors"
                      >
                        <LogOut className="w-4 h-4 text-red-400" />
                        <span>Sign Out</span>
                      </button>
                    </div>
                  </div>
                )}
              </div>
            ) : (
              <div className="flex items-center space-x-2">
                <button
                  id="nav-login-btn"
                  onClick={() => {
                    setAuthModalMode('login');
                    setIsAuthModalOpen(true);
                  }}
                  className="px-3.5 py-2 text-sm font-medium text-slate-200 hover:text-white hover:bg-slate-800/60 rounded-lg transition-all"
                >
                  Sign In
                </button>
                <button
                  id="nav-register-btn"
                  onClick={() => {
                    setAuthModalMode('register');
                    setIsAuthModalOpen(true);
                  }}
                  className="px-4 py-2 text-sm font-semibold text-white bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 rounded-lg shadow-lg shadow-blue-600/25 hover:shadow-blue-600/40 transition-all active:scale-95 flex items-center space-x-1.5"
                >
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>Register</span>
                </button>
              </div>
            )}

            {/* Quick CTA to Dashboard or Tatkal Software */}
            <button
              id="nav-cta-portal-btn"
              onClick={() => handleNavClick(user ? 'dashboard' : 'tatkal-software')}
              className="hidden xl:flex items-center space-x-1.5 px-3.5 py-2 rounded-lg bg-blue-500/10 border border-blue-500/30 text-blue-400 hover:bg-blue-500/20 text-xs font-bold transition-all"
            >
              <Server className="w-3.5 h-3.5" />
              <span>{user ? 'My Services' : 'Get Started'}</span>
            </button>
          </div>

          {/* Mobile Menu Button */}
          <div className="flex items-center space-x-2 lg:hidden">
            <button
              id="mobile-currency-btn"
              onClick={() => setCurrency(currency === 'INR' ? 'USD' : 'INR')}
              className="px-2 py-1 bg-slate-900 border border-slate-800 rounded text-xs font-bold text-slate-300"
            >
              {currency === 'INR' ? '₹' : '$'}
            </button>
            <button
              id="mobile-menu-toggle-btn"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 rounded-lg bg-slate-900 border border-slate-800 text-slate-300 hover:text-white"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu Drawer */}
      {mobileMenuOpen && (
        <div id="mobile-nav-drawer" className="lg:hidden border-t border-slate-800 bg-[#070b16] px-4 pt-3 pb-6 space-y-3 animate-in slide-in-from-top-4 duration-200">
          <div className="grid grid-cols-2 gap-2 pb-2 border-b border-slate-800">
            {navItems.map((item) => (
              <button
                key={item.page}
                onClick={() => handleNavClick(item.page)}
                className={`flex items-center justify-between p-2.5 rounded-lg text-xs font-medium text-left ${
                  currentPage === item.page
                    ? 'bg-blue-600 text-white font-bold'
                    : 'bg-slate-900/60 text-slate-300 hover:bg-slate-800'
                }`}
              >
                <span>{item.label}</span>
                {item.badge && (
                  <span className="text-[9px] px-1 py-0.5 rounded bg-black/40 text-blue-300 font-mono">
                    {item.badge}
                  </span>
                )}
              </button>
            ))}
          </div>

          {/* User / Auth on Mobile */}
          {user ? (
            <div className="space-y-2 pt-1">
              <div className="flex items-center justify-between p-3 rounded-lg bg-slate-900 border border-slate-800">
                <div className="flex items-center space-x-2">
                  <img src={user.avatar} className="w-8 h-8 rounded-full ring-1 ring-blue-500" alt="avatar" />
                  <div>
                    <div className="text-xs font-bold text-white">{user.name}</div>
                    <div className="text-[10px] text-slate-400">{user.email}</div>
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-[10px] text-slate-400">Wallet</div>
                  <div className="text-xs font-bold text-emerald-400">₹{user.walletBalance}</div>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={() => handleNavClick('dashboard')}
                  className="w-full py-2 px-3 bg-blue-600/20 border border-blue-500/30 text-blue-400 rounded-lg text-xs font-bold flex items-center justify-center space-x-1"
                >
                  <LayoutDashboard className="w-3.5 h-3.5" />
                  <span>Dashboard</span>
                </button>
                <button
                  onClick={() => handleNavClick('admin')}
                  className="w-full py-2 px-3 bg-amber-500/20 border border-amber-500/30 text-amber-400 rounded-lg text-xs font-bold flex items-center justify-center space-x-1"
                >
                  <ShieldAlert className="w-3.5 h-3.5" />
                  <span>Admin Panel</span>
                </button>
              </div>

              <button
                onClick={() => {
                  logout();
                  setMobileMenuOpen(false);
                }}
                className="w-full py-2 bg-red-500/10 text-red-400 rounded-lg text-xs font-bold border border-red-500/20"
              >
                Sign Out
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-2 gap-2 pt-1">
              <button
                onClick={() => {
                  setAuthModalMode('login');
                  setIsAuthModalOpen(true);
                  setMobileMenuOpen(false);
                }}
                className="w-full py-2.5 bg-slate-900 text-slate-200 border border-slate-800 rounded-lg text-xs font-bold"
              >
                Sign In
              </button>
              <button
                onClick={() => {
                  setAuthModalMode('register');
                  setIsAuthModalOpen(true);
                  setMobileMenuOpen(false);
                }}
                className="w-full py-2.5 bg-blue-600 text-white rounded-lg text-xs font-bold"
              >
                Register Free
              </button>
            </div>
          )}
        </div>
      )}
    </header>
  );
};
