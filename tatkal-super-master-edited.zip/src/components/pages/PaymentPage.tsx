import React, { useState, useEffect, useRef } from 'react';
import { useApp } from '../../context/AppContext';
import { 
  QrCode, 
  Copy, 
  Check, 
  UploadCloud, 
  ShieldCheck, 
  Zap, 
  Clock, 
  ArrowRight, 
  AlertCircle, 
  FileText, 
  CheckCircle2, 
  Lock, 
  Smartphone, 
  Info,
  Server,
  Download,
  Image as ImageIcon,
  ExternalLink,
  MessageCircle,
  Eye,
  RefreshCw
} from 'lucide-react';
import { PlanItem, Order } from '../../types';

export const PaymentPage: React.FC = () => {
  const { 
    user, 
    orders, 
    products, 
    categoryPlans,
    selectedPlanForCheckout, 
    setCurrentPage, 
    addToast,
    submitPaymentVerification,
    paymentVerifications,
    openCheckout
  } = useApp();

  const officialUpiId = 'abhishekrajbha@ybl';
  const telegramUrl = 'https://t.me/tatkalsupermastertatkalsupermaster';

  // Selection & Form State
  const [selectedOrderId, setSelectedOrderId] = useState<string>('');
  const [customAmount, setCustomAmount] = useState<number>(999);
  const [customerName, setCustomerName] = useState(user?.name || '');
  const [customerEmail, setCustomerEmail] = useState(user?.email || '');
  const [customerPhone, setCustomerPhone] = useState(user?.phone || '');
  const [planName, setPlanName] = useState('Tatkal Super Master PRO');
  const [utrNumber, setUtrNumber] = useState('');
  const [screenshotData, setScreenshotData] = useState<string | null>(null);
  const [screenshotFileName, setScreenshotFileName] = useState('');
  const [copiedUpi, setCopiedUpi] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submittedVerificationId, setSubmittedVerificationId] = useState<string | null>(null);
  const [dragOver, setDragOver] = useState(false);

  const fileInputRef = useRef<HTMLInputElement>(null);

  // If there's an active pending order or selected plan
  useEffect(() => {
    const pendingOrders = orders.filter(o => o.paymentStatus === 'pending' || o.paymentStatus === 'pending_verification' || o.paymentStatus === 'rejected');
    if (pendingOrders.length > 0 && !selectedOrderId) {
      const latest = pendingOrders[0];
      setSelectedOrderId(latest.id);
      setCustomAmount(latest.total);
      setCustomerName(latest.customerName);
      setCustomerEmail(latest.customerEmail);
      setCustomerPhone(latest.customerPhone);
      setPlanName(latest.items.map(i => i.planName).join(', '));
      if (latest.utrNumber) setUtrNumber(latest.utrNumber);
    } else if (selectedPlanForCheckout) {
      setCustomAmount(selectedPlanForCheckout.priceINR);
      setPlanName(selectedPlanForCheckout.name);
    }
  }, [orders, selectedPlanForCheckout]);

  const handleOrderSelect = (orderId: string) => {
    setSelectedOrderId(orderId);
    if (orderId === 'custom') {
      setPlanName('Custom VPS / Tatkal Software Service');
      setCustomAmount(999);
    } else {
      const ord = orders.find(o => o.id === orderId);
      if (ord) {
        setCustomAmount(ord.total);
        setCustomerName(ord.customerName);
        setCustomerEmail(ord.customerEmail);
        setCustomerPhone(ord.customerPhone);
        setPlanName(ord.items.map(i => i.planName).join(', '));
        if (ord.utrNumber) setUtrNumber(ord.utrNumber);
        if (ord.paymentScreenshot) setScreenshotData(ord.paymentScreenshot);
      }
    }
  };

  const handleCopyUpi = () => {
    navigator.clipboard.writeText(officialUpiId);
    setCopiedUpi(true);
    addToast('success', 'UPI ID Copied!', `${officialUpiId} copied to clipboard.`);
    setTimeout(() => setCopiedUpi(false), 3000);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      processFile(file);
    }
  };

  const processFile = (file: File) => {
    if (!file.type.startsWith('image/')) {
      addToast('error', 'Invalid File', 'Please upload a valid image (PNG, JPG, JPEG, WEBP).');
      return;
    }

    if (file.size > 8 * 1024 * 1024) {
      addToast('error', 'File Too Large', 'Maximum screenshot size is 8MB.');
      return;
    }

    setScreenshotFileName(file.name);
    const reader = new FileReader();
    reader.onload = () => {
      setScreenshotData(reader.result as string);
      addToast('info', 'Screenshot Attached', 'Payment receipt image loaded. Ready to submit.');
    };
    reader.readAsDataURL(file);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      processFile(e.dataTransfer.files[0]);
    }
  };

  const handleSubmitVerification = (e: React.FormEvent) => {
    e.preventDefault();

    if (!utrNumber.trim()) {
      addToast('error', 'UTR Required', 'Please enter your 12-digit UPI Reference / UTR Number.');
      return;
    }

    if (utrNumber.trim().length < 6) {
      addToast('error', 'Invalid UTR', 'Please enter a valid UPI Transaction / UTR number.');
      return;
    }

    if (!screenshotData) {
      addToast('error', 'Screenshot Required', 'Please upload your UPI payment success screenshot for verification.');
      return;
    }

    setIsSubmitting(true);

    try {
      const verification = submitPaymentVerification({
        orderId: selectedOrderId !== 'custom' ? selectedOrderId : undefined,
        customerName: customerName || (user ? user.name : 'Customer'),
        customerEmail: customerEmail || (user ? user.email : 'customer@tatkalsupermaster.com'),
        customerPhone: customerPhone || '+91 98765 00000',
        planName: planName,
        amount: customAmount,
        upiId: officialUpiId,
        utrNumber: utrNumber.trim(),
        screenshotUrl: screenshotData
      });

      setSubmittedVerificationId(verification.id);
      setIsSubmitting(false);
      addToast('success', 'Verification Submitted!', 'Payment submitted! Admin will verify and activate your VPS / software within 2-5 minutes.');
    } catch (err: any) {
      setIsSubmitting(false);
      addToast('error', 'Submission Failed', err.message || 'Could not submit payment verification.');
    }
  };

  // Generate UPI QR Pay URL
  const upiPayUrl = `upi://pay?pa=${officialUpiId}&pn=TATKAL%20SUPER%20MASTER&am=${customAmount}&cu=INR&tn=TSM_Order_${encodeURIComponent(planName.substring(0, 15))}`;
  const qrCodeDisplayUrl = `https://api.qrserver.com/v1/create-qr-code/?size=320x320&data=${encodeURIComponent(upiPayUrl)}&color=000000&bgcolor=ffffff&margin=2`;

  const pendingCustomerOrders = orders.filter(o => 
    (!user || o.customerEmail === user.email) && 
    (o.paymentStatus === 'pending' || o.paymentStatus === 'pending_verification' || o.paymentStatus === 'rejected')
  );

  return (
    <div className="min-h-screen bg-[#050811] text-slate-100 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-6xl mx-auto space-y-10">
        
        {/* Header Banner */}
        <div className="text-center space-y-3">
          <div className="inline-flex items-center space-x-2 px-3.5 py-1.5 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs font-bold font-mono">
            <ShieldCheck className="w-4 h-4" />
            <span>Official UPI Gateway &amp; Instant Manual Verification</span>
          </div>
          <h1 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
            Official UPI Payment Desk
          </h1>
          <p className="text-sm text-slate-400 max-w-2xl mx-auto">
            Scan the official QR code, pay via any UPI App (GPay, PhonePe, Paytm, BHIM, Cred), upload the screenshot, and get automated VPS provisioning in 2–5 minutes.
          </p>
        </div>

        {/* Successful Submission View */}
        {submittedVerificationId ? (
          <div className="bg-slate-900/90 border border-emerald-500/40 rounded-3xl p-8 sm:p-12 text-center space-y-6 shadow-2xl max-w-2xl mx-auto">
            <div className="w-20 h-20 bg-emerald-500/20 border border-emerald-500/40 rounded-full flex items-center justify-center mx-auto text-emerald-400">
              <CheckCircle2 className="w-10 h-10" />
            </div>

            <div className="space-y-2">
              <h2 className="text-2xl font-bold text-white">Payment Proof Submitted Successfully!</h2>
              <p className="text-sm text-slate-300">
                Your payment verification request <strong className="text-cyan-300 font-mono">#{submittedVerificationId}</strong> has been logged.
              </p>
            </div>

            <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 text-left space-y-2 font-mono text-xs">
              <div className="flex justify-between py-1 border-b border-slate-800">
                <span className="text-slate-400">Paid Amount:</span>
                <span className="text-emerald-400 font-bold text-sm">₹{customAmount.toLocaleString('en-IN')}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-800">
                <span className="text-slate-400">Target UPI ID:</span>
                <span className="text-white font-bold">{officialUpiId}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-800">
                <span className="text-slate-400">Submitted UTR / Ref ID:</span>
                <span className="text-cyan-300 font-bold">{utrNumber}</span>
              </div>
              <div className="flex justify-between py-1">
                <span className="text-slate-400">Current Status:</span>
                <span className="px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30 text-[11px] font-bold">
                  Pending Admin Verification ⏳
                </span>
              </div>
            </div>

            <div className="p-4 rounded-xl bg-blue-950/30 border border-blue-500/30 text-xs text-blue-200 flex items-start space-x-3 text-left">
              <Info className="w-5 h-5 text-cyan-400 shrink-0 mt-0.5" />
              <p>
                Our automated NOC team is reviewing your UTR on the banking terminal. Once approved, your VPS IP credentials, license key, and invoice will appear instantly in your <strong>Customer Dashboard</strong>.
              </p>
            </div>

            <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-2">
              <button
                onClick={() => setCurrentPage('dashboard')}
                className="w-full sm:w-auto px-6 py-3 bg-gradient-to-r from-blue-600 to-cyan-500 hover:from-blue-500 hover:to-cyan-400 text-white rounded-xl text-xs font-bold transition-all shadow-lg shadow-blue-950 flex items-center justify-center space-x-2"
              >
                <span>View in Customer Dashboard</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <a
                href={telegramUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full sm:w-auto px-6 py-3 bg-gradient-to-r from-[#0088cc] to-[#229ED9] hover:brightness-110 text-white rounded-xl text-xs font-bold transition-all shadow-lg shadow-cyan-950 flex items-center justify-center space-x-2"
              >
                <svg className="w-4 h-4 fill-white" viewBox="0 0 24 24">
                  <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm4.64 6.8c-.15 1.58-.8 5.42-1.13 7.19-.14.75-.42 1-.68 1.03-.58.05-1.02-.38-1.58-.75-.88-.58-1.38-.94-2.23-1.5-.99-.65-.35-1.01.22-1.59.15-.15 2.71-2.48 2.76-2.69.01-.03.01-.14-.07-.19-.08-.05-.19-.02-.27 0-.12.03-1.99 1.27-5.62 3.72-.53.36-1.01.54-1.44.53-.47-.01-1.38-.27-2.06-.49-.83-.27-1.49-.42-1.43-.88.03-.24.38-.49 1.03-.75 4.04-1.76 6.74-2.92 8.09-3.49 3.85-1.6 4.65-1.88 5.17-1.89.11 0 .37.03.54.17.14.12.18.28.2.45-.02.07-.02.21-.04.34z"/>
                </svg>
                <span>Notify Telegram Support (@tatkalsupermaster)</span>
              </a>

              <button
                onClick={() => {
                  setSubmittedVerificationId(null);
                  setScreenshotData(null);
                  setUtrNumber('');
                }}
                className="w-full sm:w-auto px-4 py-3 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-bold transition-all"
              >
                Submit Another Payment
              </button>
            </div>
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
            
            {/* Left Column: Official QR Code & UPI Details (5 cols) */}
            <div className="lg:col-span-5 space-y-6">
              
              {/* Official QR Code Card */}
              <div className="p-6 rounded-3xl bg-gradient-to-b from-slate-900 via-slate-900 to-slate-950 border border-cyan-500/30 shadow-2xl relative overflow-hidden text-center space-y-5">
                <div className="absolute top-0 inset-x-0 h-1 bg-gradient-to-r from-emerald-500 via-cyan-500 to-blue-500"></div>

                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <QrCode className="w-5 h-5 text-cyan-400" />
                    <span className="text-xs font-black uppercase tracking-wider text-white">Official Payment QR</span>
                  </div>
                  <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 flex items-center space-x-1">
                    <ShieldCheck className="w-3 h-3" />
                    <span>Secure Payment</span>
                  </span>
                </div>

                {/* QR Display Frame */}
                <div className="p-4 bg-white rounded-2xl shadow-inner inline-block mx-auto max-w-[260px] border-4 border-slate-800/80">
                  <img 
                    src={qrCodeDisplayUrl} 
                    alt="Official Tatkal Super Master Payment QR Code" 
                    className="w-full h-auto object-contain rounded-lg"
                  />
                  <div className="pt-2 text-center">
                    <p className="text-[10px] font-black tracking-widest text-slate-900 uppercase">
                      Scan &amp; Pay via Any UPI App
                    </p>
                  </div>
                </div>

                {/* Amount Display */}
                <div className="p-3 rounded-2xl bg-slate-950 border border-slate-800 space-y-1">
                  <span className="text-[11px] text-slate-400 uppercase font-bold">Payable Amount:</span>
                  <div className="flex items-baseline justify-center space-x-1">
                    <span className="text-lg font-bold text-slate-400">₹</span>
                    <span className="text-3xl font-black text-white font-mono">{customAmount.toLocaleString('en-IN')}</span>
                    <span className="text-xs text-slate-400 font-mono">INR</span>
                  </div>
                  <p className="text-[10px] text-cyan-300 truncate font-mono">
                    {planName}
                  </p>
                </div>

                {/* Official UPI ID Box with Copy Button */}
                <div className="p-3.5 rounded-2xl bg-gradient-to-r from-blue-950/40 via-cyan-950/30 to-blue-950/40 border border-cyan-500/30 space-y-2">
                  <div className="flex items-center justify-between text-[11px]">
                    <span className="text-slate-400 font-bold uppercase">Official UPI ID:</span>
                    <span className="text-[10px] text-emerald-400 font-mono flex items-center space-x-1">
                      <Zap className="w-2.5 h-2.5" />
                      <span>Verified Merchant</span>
                    </span>
                  </div>
                  <div className="flex items-center justify-between bg-slate-950 p-2.5 rounded-xl border border-slate-800">
                    <span className="text-sm font-black font-mono text-cyan-300 select-all">
                      {officialUpiId}
                    </span>
                    <button
                      type="button"
                      onClick={handleCopyUpi}
                      className={`px-3 py-1.5 rounded-lg text-xs font-bold flex items-center space-x-1.5 transition-all shadow-md ${
                        copiedUpi 
                          ? 'bg-emerald-600 text-white' 
                          : 'bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white shadow-cyan-950'
                      }`}
                    >
                      {copiedUpi ? (
                        <>
                          <Check className="w-3.5 h-3.5" />
                          <span>Copied!</span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-3.5 h-3.5" />
                          <span>Copy UPI</span>
                        </>
                      )}
                    </button>
                  </div>
                </div>

                {/* Accepted Payment Apps Badges */}
                <div className="pt-2 border-t border-slate-800/80 space-y-2">
                  <span className="text-[10px] text-slate-400 uppercase font-mono font-bold tracking-wider">
                    Accepted UPI Apps
                  </span>
                  <div className="flex flex-wrap items-center justify-center gap-1.5">
                    {['Google Pay', 'PhonePe', 'Paytm', 'BHIM UPI', 'Cred', 'Amazon Pay', 'Any Bank App'].map((app) => (
                      <span key={app} className="px-2 py-0.5 rounded-md bg-slate-950 border border-slate-800 text-[10px] font-bold text-slate-300 font-mono">
                        {app}
                      </span>
                    ))}
                  </div>
                </div>

              </div>

              {/* Telegram Support Callout */}
              <div className="p-4 rounded-2xl bg-gradient-to-r from-slate-900 via-[#0088cc]/10 to-slate-900 border border-[#229ED9]/30 flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 rounded-xl bg-[#229ED9]/20 border border-[#229ED9]/40 flex items-center justify-center text-[#229ED9]">
                    <svg className="w-5 h-5 fill-current" viewBox="0 0 24 24">
                      <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm4.64 6.8c-.15 1.58-.8 5.42-1.13 7.19-.14.75-.42 1-.68 1.03-.58.05-1.02-.38-1.58-.75-.88-.58-1.38-.94-2.23-1.5-.99-.65-.35-1.01.22-1.59.15-.15 2.71-2.48 2.76-2.69.01-.03.01-.14-.07-.19-.08-.05-.19-.02-.27 0-.12.03-1.99 1.27-5.62 3.72-.53.36-1.01.54-1.44.53-.47-.01-1.38-.27-2.06-.49-.83-.27-1.49-.42-1.43-.88.03-.24.38-.49 1.03-.75 4.04-1.76 6.74-2.92 8.09-3.49 3.85-1.6 4.65-1.88 5.17-1.89.11 0 .37.03.54.17.14.12.18.28.2.45-.02.07-.02.21-.04.34z"/>
                    </svg>
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-white">Need Fast Verification?</h4>
                    <p className="text-[11px] text-slate-400">Ping our Senior NOC Engineer on Telegram</p>
                  </div>
                </div>
                <a
                  href={telegramUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-3 py-1.5 bg-[#229ED9] hover:bg-[#0088cc] text-white rounded-lg text-xs font-bold transition-all shadow-md shadow-cyan-950 flex items-center space-x-1"
                >
                  <span>@tatkalsupermaster</span>
                  <ExternalLink className="w-3 h-3" />
                </a>
              </div>

            </div>

            {/* Right Column: Step-by-Step Payment Instructions & Verification Form (7 cols) */}
            <div className="lg:col-span-7 space-y-6">
              
              {/* Step-by-Step Instructions */}
              <div className="p-6 rounded-3xl bg-slate-900/90 border border-slate-800 shadow-xl space-y-4">
                <div className="flex items-center space-x-2">
                  <FileText className="w-5 h-5 text-amber-400" />
                  <h3 className="text-base font-bold text-white">4-Step Manual Verification Process</h3>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                  <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800/80 space-y-1">
                    <div className="flex items-center space-x-2 text-cyan-400 font-bold font-mono">
                      <span className="w-5 h-5 rounded-full bg-cyan-500/20 border border-cyan-500/30 flex items-center justify-center text-[10px]">1</span>
                      <span>Scan QR or Copy UPI</span>
                    </div>
                    <p className="text-slate-400 text-[11px] pl-7">
                      Open GPay, PhonePe, Paytm, or BHIM. Scan QR or transfer to <strong className="text-slate-200">{officialUpiId}</strong>.
                    </p>
                  </div>

                  <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800/80 space-y-1">
                    <div className="flex items-center space-x-2 text-cyan-400 font-bold font-mono">
                      <span className="w-5 h-5 rounded-full bg-cyan-500/20 border border-cyan-500/30 flex items-center justify-center text-[10px]">2</span>
                      <span>Pay Exact Amount</span>
                    </div>
                    <p className="text-slate-400 text-[11px] pl-7">
                      Pay <strong className="text-emerald-400">₹{customAmount}</strong> for your selected plan without changing the figure.
                    </p>
                  </div>

                  <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800/80 space-y-1">
                    <div className="flex items-center space-x-2 text-cyan-400 font-bold font-mono">
                      <span className="w-5 h-5 rounded-full bg-cyan-500/20 border border-cyan-500/30 flex items-center justify-center text-[10px]">3</span>
                      <span>Note 12-Digit UTR</span>
                    </div>
                    <p className="text-slate-400 text-[11px] pl-7">
                      Copy the 12-digit UPI Reference Number / Transaction ID and take a screenshot.
                    </p>
                  </div>

                  <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800/80 space-y-1">
                    <div className="flex items-center space-x-2 text-cyan-400 font-bold font-mono">
                      <span className="w-5 h-5 rounded-full bg-cyan-500/20 border border-cyan-500/30 flex items-center justify-center text-[10px]">4</span>
                      <span>Instant VPS Delivery</span>
                    </div>
                    <p className="text-slate-400 text-[11px] pl-7">
                      Upload screenshot below. Admin verifies &amp; auto-deploys IP &amp; root password in 2–5 mins.
                    </p>
                  </div>
                </div>
              </div>

              {/* Upload Proof & Verification Submission Form */}
              <form onSubmit={handleSubmitVerification} className="p-6 sm:p-8 rounded-3xl bg-slate-900/90 border border-cyan-500/30 shadow-2xl space-y-5">
                
                <div className="flex items-center justify-between border-b border-slate-800 pb-4">
                  <div className="space-y-0.5">
                    <h3 className="text-base font-black text-white flex items-center space-x-2">
                      <UploadCloud className="w-5 h-5 text-cyan-400" />
                      <span>Submit Payment Verification Details</span>
                    </h3>
                    <p className="text-xs text-slate-400">Fill in transaction details to verify your payment</p>
                  </div>
                  <span className="text-[10px] font-mono text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20">
                    NOC Live
                  </span>
                </div>

                {/* Pending Order Selector or Custom Payment */}
                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">
                    Select Target Order / Service *
                  </label>
                  <select
                    value={selectedOrderId}
                    onChange={(e) => handleOrderSelect(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-xs text-white focus:border-cyan-500 focus:outline-none"
                  >
                    {pendingCustomerOrders.length > 0 ? (
                      pendingCustomerOrders.map((ord) => (
                        <option key={ord.id} value={ord.id}>
                          Order #{ord.orderNumber} — ₹{ord.total} ({ord.items.map(i => i.planName).join(', ')}) [{ord.paymentStatus.toUpperCase()}]
                        </option>
                      ))
                    ) : (
                      <option value="">No pending orders found — Creating New Manual Payment</option>
                    )}
                    <option value="custom">+ New Custom Payment / Wallet Topup / Renewal</option>
                  </select>
                </div>

                {/* Plan Name & Amount Details */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-bold text-slate-300 mb-1">Plan / Service Name *</label>
                    <input
                      type="text"
                      required
                      value={planName}
                      onChange={(e) => setPlanName(e.target.value)}
                      placeholder="e.g. Diamond Pro AMD 16GB"
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-xs text-white"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-300 mb-1">Paid Amount (INR ₹) *</label>
                    <input
                      type="number"
                      required
                      min="100"
                      value={customAmount}
                      onChange={(e) => setCustomAmount(Number(e.target.value))}
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-xs text-emerald-400 font-mono font-bold"
                    />
                  </div>
                </div>

                {/* Customer Contact Details */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div>
                    <label className="block text-xs font-bold text-slate-300 mb-1">Your Full Name *</label>
                    <input
                      type="text"
                      required
                      value={customerName}
                      onChange={(e) => setCustomerName(e.target.value)}
                      placeholder="Rahul Verma"
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-xs text-white"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-300 mb-1">Email (For Credentials) *</label>
                    <input
                      type="email"
                      required
                      value={customerEmail}
                      onChange={(e) => setCustomerEmail(e.target.value)}
                      placeholder="rahul@example.com"
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-xs text-white"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-300 mb-1">Phone / Telegram ID *</label>
                    <input
                      type="text"
                      required
                      value={customerPhone}
                      onChange={(e) => setCustomerPhone(e.target.value)}
                      placeholder="@telegram_handle or phone"
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-xs text-white"
                    />
                  </div>
                </div>

                {/* 12-Digit UTR / Transaction ID Input */}
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="block text-xs font-bold text-slate-300">
                      12-Digit UPI Reference / UTR Number *
                    </label>
                    <span className="text-[10px] text-cyan-400 font-mono">Found in GPay/PhonePe receipt</span>
                  </div>
                  <input
                    type="text"
                    required
                    value={utrNumber}
                    onChange={(e) => setUtrNumber(e.target.value)}
                    placeholder="e.g. 423589214782 or UPI Ref ID"
                    className="w-full bg-slate-950 border border-cyan-500/40 rounded-xl p-3 text-sm text-cyan-300 font-mono font-bold tracking-wider focus:border-cyan-400 focus:ring-1 focus:ring-cyan-400 focus:outline-none"
                  />
                </div>

                {/* Drag-and-Drop Screenshot Uploader */}
                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">
                    Upload Payment Success Screenshot *
                  </label>
                  
                  <input 
                    type="file" 
                    ref={fileInputRef} 
                    onChange={handleFileChange} 
                    accept="image/*" 
                    className="hidden" 
                  />

                  {screenshotData ? (
                    <div className="p-4 rounded-2xl bg-slate-950 border border-emerald-500/40 space-y-3">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-2 text-xs text-emerald-400 font-bold">
                          <CheckCircle2 className="w-4 h-4" />
                          <span>Screenshot Attached: {screenshotFileName || 'Payment_Proof.png'}</span>
                        </div>
                        <button
                          type="button"
                          onClick={() => fileInputRef.current?.click()}
                          className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold transition-colors"
                        >
                          Change Image
                        </button>
                      </div>

                      {/* Image Thumbnail Preview */}
                      <div className="max-h-48 overflow-hidden rounded-xl border border-slate-800 bg-black flex items-center justify-center">
                        <img 
                          src={screenshotData} 
                          alt="Uploaded payment proof" 
                          className="max-h-48 object-contain"
                        />
                      </div>
                    </div>
                  ) : (
                    <div
                      onDragOver={(e) => { e.preventDefault(); setDragOver(true); }}
                      onDragLeave={() => setDragOver(false)}
                      onDrop={handleDrop}
                      onClick={() => fileInputRef.current?.click()}
                      className={`p-6 border-2 border-dashed rounded-2xl text-center cursor-pointer transition-all ${
                        dragOver 
                          ? 'border-cyan-400 bg-cyan-950/20' 
                          : 'border-slate-800 hover:border-cyan-500/50 bg-slate-950/60 hover:bg-slate-950'
                      }`}
                    >
                      <div className="w-12 h-12 rounded-full bg-cyan-500/10 border border-cyan-500/20 flex items-center justify-center mx-auto text-cyan-400 mb-2">
                        <UploadCloud className="w-6 h-6" />
                      </div>
                      <p className="text-xs font-bold text-white">
                        Click to browse or drag &amp; drop payment screenshot here
                      </p>
                      <p className="text-[11px] text-slate-400 mt-0.5">
                        Supports JPG, PNG, WEBP, HEIC up to 8MB
                      </p>
                    </div>
                  )}
                </div>

                {/* Submit Verification Action Button */}
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full py-3.5 bg-gradient-to-r from-emerald-600 via-teal-600 to-cyan-600 hover:from-emerald-500 hover:to-cyan-500 text-white rounded-xl font-bold text-sm shadow-xl shadow-emerald-950/60 hover:scale-[1.01] active:scale-[0.99] transition-all flex items-center justify-center space-x-2 disabled:opacity-50"
                >
                  {isSubmitting ? (
                    <>
                      <RefreshCw className="w-4 h-4 animate-spin" />
                      <span>Logging Verification to NOC...</span>
                    </>
                  ) : (
                    <>
                      <ShieldCheck className="w-5 h-5" />
                      <span>Submit Payment Proof for Instant Activation (₹{customAmount})</span>
                    </>
                  )}
                </button>

                <p className="text-center text-[11px] text-slate-400">
                  🔒 All payments are 100% manually verified on banking records. Live 24/7 support available on Telegram at <strong className="text-cyan-300">@tatkalsupermaster</strong>.
                </p>

              </form>

            </div>

          </div>
        )}

      </div>
    </div>
  );
};
