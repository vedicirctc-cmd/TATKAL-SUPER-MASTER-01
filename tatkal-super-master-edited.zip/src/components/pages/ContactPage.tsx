import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { 
  MessageSquare, 
  Send, 
  Phone, 
  Mail, 
  MapPin, 
  Clock, 
  ShieldCheck, 
  CheckCircle2, 
  Sparkles,
  Headphones
} from 'lucide-react';

export const ContactPage: React.FC = () => {
  const { addToast } = useApp();
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [subject, setSubject] = useState('Tatkal Software License Support');
  const [message, setMessage] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setTimeout(() => {
      setIsSubmitting(false);
      setIsSuccess(true);
      addToast({
        title: 'Message Dispatched Successfully',
        message: 'A Senior Technical Support Engineer will contact you shortly on Telegram.',
        type: 'success'
      });
      setName('');
      setEmail('');
      setPhone('');
      setMessage('');
    }, 1000);
  };

  return (
    <div className="min-h-screen bg-[#050811] text-slate-100 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-16">
        
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto space-y-3">
          <div className="inline-flex items-center space-x-2 px-3.5 py-1.5 rounded-full bg-blue-500/10 border border-blue-500/30 text-blue-400 text-xs font-bold uppercase tracking-wider">
            <Headphones className="w-3.5 h-3.5 text-cyan-400" />
            <span>24/7 Dedicated Technical Desk</span>
          </div>

          <h1 className="text-3xl sm:text-5xl font-black text-white tracking-tight leading-tight">
            Contact <span className="bg-gradient-to-r from-blue-400 to-cyan-300 bg-clip-text text-transparent">TATKAL SUPER MASTER</span>
          </h1>

          <p className="text-slate-300 text-sm sm:text-base leading-relaxed">
            Need urgent assistance before the 10:00 AM booking window, custom VPS provisioning, or bulk agency license discounts? Our automation engineers are available around the clock.
          </p>
        </div>

        {/* Quick Instant Channels */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <a
            href="https://t.me/tatkalsupermaster919876543210?text=Hello%20Tatkal%20Super%20Master%20Support"
            target="_blank"
            rel="noreferrer"
            className="p-6 rounded-2xl bg-gradient-to-br from-[#0a2318] to-[#07130e] border border-emerald-500/40 hover:border-emerald-400 transition-all group flex flex-col justify-between space-y-4 shadow-xl"
          >
            <div className="space-y-3">
              <div className="w-12 h-12 rounded-xl bg-emerald-500/20 flex items-center justify-center text-emerald-400">
                <MessageSquare className="w-6 h-6" />
              </div>
              <h3 className="text-base font-bold text-white group-hover:text-emerald-300">Telegram Instant Support</h3>
              <p className="text-xs text-slate-300">Direct 1-on-1 assistance for setup, software updates, and rapid license keys.</p>
            </div>
            <div className="flex items-center justify-between text-xs font-bold text-emerald-400 pt-2 border-t border-emerald-500/20">
              <span>+91 98765 43210</span>
              <span className="text-[10px] bg-emerald-500/20 px-2 py-0.5 rounded">&lt; 2 Min Reply</span>
            </div>
          </a>

          <a
            href="https://t.me/tatkalsupermasterTatkalSuperMasterOfficial"
            target="_blank"
            rel="noreferrer"
            className="p-6 rounded-2xl bg-gradient-to-br from-[#0c1f38] to-[#07101e] border border-blue-500/40 hover:border-blue-400 transition-all group flex flex-col justify-between space-y-4 shadow-xl"
          >
            <div className="space-y-3">
              <div className="w-12 h-12 rounded-xl bg-blue-500/20 flex items-center justify-center text-blue-400">
                <Send className="w-6 h-6" />
              </div>
              <h3 className="text-base font-bold text-white group-hover:text-cyan-300">Telegram VIP Channel & Bot</h3>
              <p className="text-xs text-slate-300">Live IRCTC gateway status alerts, daily morning speed updates, and coupon drops.</p>
            </div>
            <div className="flex items-center justify-between text-xs font-bold text-cyan-400 pt-2 border-t border-blue-500/20">
              <span>@TatkalSuperMasterOfficial</span>
              <span className="text-[10px] bg-blue-500/20 px-2 py-0.5 rounded">24,000+ Members</span>
            </div>
          </a>

          <div className="p-6 rounded-2xl bg-gradient-to-br from-[#1b142f] to-[#0d0918] border border-purple-500/40 flex flex-col justify-between space-y-4 shadow-xl">
            <div className="space-y-3">
              <div className="w-12 h-12 rounded-xl bg-purple-500/20 flex items-center justify-center text-purple-400">
                <Clock className="w-6 h-6" />
              </div>
              <h3 className="text-base font-bold text-white">Tatkal Rush Hotline Desk</h3>
              <p className="text-xs text-slate-300">Dedicated morning live shift starting every day at 09:30 AM for emergency checkups.</p>
            </div>
            <div className="flex items-center justify-between text-xs font-bold text-purple-300 pt-2 border-t border-purple-500/20">
              <span>09:30 AM - 11:30 AM Daily</span>
              <span className="text-[10px] bg-purple-500/20 px-2 py-0.5 rounded">Priority Line</span>
            </div>
          </div>
        </div>

        {/* Contact Form & Office Info */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          
          {/* Form */}
          <div className="lg:col-span-7 bg-slate-900/60 border border-slate-800 rounded-2xl p-6 sm:p-8 space-y-6">
            <div className="space-y-1">
              <h2 className="text-xl font-bold text-white">Send Us a Direct Support Message</h2>
              <p className="text-xs text-slate-400">Fill out this quick form and our support desk will respond via Telegram or Email.</p>
            </div>

            {isSuccess && (
              <div className="p-4 bg-emerald-500/10 border border-emerald-500/30 rounded-xl text-xs text-emerald-400 flex items-center space-x-2">
                <CheckCircle2 className="w-4 h-4 shrink-0" />
                <span>Thank you! Your message has been received. Our team will contact you shortly.</span>
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-4 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-slate-400 mb-1">Your Full Name *</label>
                  <input
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="Ankit Kumar"
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-white focus:outline-none focus:border-blue-500"
                  />
                </div>

                <div>
                  <label className="block text-slate-400 mb-1">Telegram Mobile Number *</label>
                  <input
                    type="tel"
                    required
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="+91 98765 43210"
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-white focus:outline-none focus:border-blue-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-slate-400 mb-1">Email Address *</label>
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="ankit.travels@gmail.com"
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-white focus:outline-none focus:border-blue-500"
                  />
                </div>

                <div>
                  <label className="block text-slate-400 mb-1">Inquiry Topic</label>
                  <select
                    value={subject}
                    onChange={(e) => setSubject(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-white focus:outline-none focus:border-blue-500"
                  >
                    <option value="Tatkal Software License Support">Tatkal Software License Support</option>
                    <option value="Windows VPS Latency & Setup">Windows VPS Latency & Setup</option>
                    <option value="Residential Clean IP Allocation">Residential Clean IP Allocation</option>
                    <option value="Agency Bulk Licensing">Agency Bulk Licensing (10+ Users)</option>
                    <option value="Billing & Invoicing Query">Billing & Invoicing Query</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-slate-400 mb-1">Message & Requirements *</label>
                <textarea
                  rows={4}
                  required
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  placeholder="Explain your queries or current setup in detail..."
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-white focus:outline-none focus:border-blue-500"
                />
              </div>

              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full py-3 bg-gradient-to-r from-blue-600 to-cyan-500 hover:from-blue-500 hover:to-cyan-400 text-white rounded-xl font-bold shadow-lg shadow-blue-900/40 transition-all flex items-center justify-center space-x-2"
              >
                <Send className="w-4 h-4" />
                <span>{isSubmitting ? 'Sending Request...' : 'Send Message to Support'}</span>
              </button>
            </form>
          </div>

          {/* Office & Datacenter Info */}
          <div className="lg:col-span-5 space-y-6">
            <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-6 sm:p-8 space-y-6 text-xs text-slate-300">
              <h3 className="text-base font-bold text-white">Office & Infrastructure Hub</h3>

              <div className="space-y-4">
                <div className="flex items-start space-x-3">
                  <MapPin className="w-5 h-5 text-blue-400 shrink-0 mt-0.5" />
                  <div>
                    <span className="font-bold text-white block">Corporate Operations Hub</span>
                    <p className="text-slate-400">Level 8, Equinox Tech Park, Bandra-Kurla Complex (BKC), Mumbai, MH 400051, India</p>
                  </div>
                </div>

                <div className="flex items-start space-x-3">
                  <Mail className="w-5 h-5 text-cyan-400 shrink-0 mt-0.5" />
                  <div>
                    <span className="font-bold text-white block">Support & Sales Inquiries</span>
                    <p className="text-slate-400">support@tatkalsupermaster.com</p>
                    <p className="text-slate-400">billing@tatkalsupermaster.com</p>
                  </div>
                </div>

                <div className="flex items-start space-x-3">
                  <Clock className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
                  <div>
                    <span className="font-bold text-white block">Active Support Shift</span>
                    <p className="text-slate-400">24 Hours x 7 Days x 365 Days Uninterrupted</p>
                  </div>
                </div>
              </div>

              <div className="pt-4 border-t border-slate-800 flex items-center space-x-2 text-[11px] text-slate-400">
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
                <span>All tickets acknowledged within 5 minutes guaranteed.</span>
              </div>
            </div>
          </div>

        </div>

      </div>
    </div>
  );
};
