import React from 'react';
import { COMPANY_STATS } from '../../data/mockData';
import { 
  Zap, 
  ShieldCheck, 
  Globe, 
  Server, 
  Target, 
  Eye, 
  Award, 
  CheckCircle2, 
  Users,
  Activity
} from 'lucide-react';
import { useApp } from '../../context/AppContext';

export const AboutUsPage: React.FC = () => {
  const { setCurrentPage } = useApp();

  return (
    <div className="min-h-screen bg-[#050811] text-slate-100 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-16">
        
        {/* Hero Section */}
        <div className="text-center max-w-3xl mx-auto space-y-4">
          <div className="inline-flex items-center space-x-2 px-3.5 py-1.5 rounded-full bg-blue-500/10 border border-blue-500/30 text-blue-400 text-xs font-bold uppercase tracking-wider">
            <Award className="w-3.5 h-3.5 text-cyan-400" />
            <span>Pioneering High-Performance Railway Automation</span>
          </div>

          <h1 className="text-3xl sm:text-5xl font-black text-white tracking-tight leading-tight">
            About <span className="bg-gradient-to-r from-blue-400 to-cyan-300 bg-clip-text text-transparent">TATKAL SUPER MASTER</span>
          </h1>

          <p className="text-slate-300 text-sm sm:text-base leading-relaxed">
            Founded by high-frequency network engineers and automation architects in 2021, TATKAL SUPER MASTER delivers enterprise-grade infrastructure to eliminate latency bottlenecks for travel operators and power users across India.
          </p>
        </div>

        {/* Mission & Vision Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div className="p-8 rounded-2xl bg-gradient-to-b from-[#0d162c] to-[#070b16] border border-blue-500/30 space-y-4 shadow-xl">
            <div className="w-12 h-12 rounded-xl bg-blue-600/20 border border-blue-500/30 flex items-center justify-center text-cyan-400">
              <Target className="w-6 h-6" />
            </div>
            <h2 className="text-xl font-bold text-white">Our Mission</h2>
            <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
              To democratize access to carrier-grade, ultra-low latency infrastructure and intelligent automation tools, ensuring that legitimate travelers and authorized travel professionals can secure confirmed train tickets seamlessly during peak rush hours without technical hurdles.
            </p>
          </div>

          <div className="p-8 rounded-2xl bg-gradient-to-b from-[#0e1d2c] to-[#070b16] border border-cyan-500/30 space-y-4 shadow-xl">
            <div className="w-12 h-12 rounded-xl bg-cyan-600/20 border border-cyan-500/30 flex items-center justify-center text-cyan-400">
              <Eye className="w-6 h-6" />
            </div>
            <h2 className="text-xl font-bold text-white">Our Vision</h2>
            <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
              To remain India’s premier low-latency cloud hosting and network proxy provider, continually advancing AI neural captcha resolution, automated payment tunneling, and direct fiber interconnects to deliver 99.999% reliability.
            </p>
          </div>
        </div>

        {/* Experience & Key Milestones */}
        <div className="p-8 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-8">
          <div className="text-center max-w-2xl mx-auto space-y-2">
            <h2 className="text-2xl font-extrabold text-white">5+ Years of Proven Excellence</h2>
            <p className="text-xs sm:text-sm text-slate-400">
              From our first Mumbai server node to managing over 8,200+ concurrent active VPS nodes and 150,000+ residential clean IPs nationwide.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            <div className="p-4 bg-slate-900 rounded-xl border border-slate-800 space-y-1 text-center">
              <span className="text-2xl font-black text-cyan-400 font-mono">14,500+</span>
              <p className="text-xs font-bold text-white">Active Agency Clients</p>
              <p className="text-[11px] text-slate-400">Trusted by operators in 28 Indian states</p>
            </div>

            <div className="p-4 bg-slate-900 rounded-xl border border-slate-800 space-y-1 text-center">
              <span className="text-2xl font-black text-emerald-400 font-mono">45,000+</span>
              <p className="text-xs font-bold text-white">Daily Confirmed Tickets</p>
              <p className="text-[11px] text-slate-400">Processed across 10:00 & 11:00 AM slots</p>
            </div>

            <div className="p-4 bg-slate-900 rounded-xl border border-slate-800 space-y-1 text-center">
              <span className="text-2xl font-black text-blue-400 font-mono">&lt; 1.8 ms</span>
              <p className="text-xs font-bold text-white">Average IRCTC Latency</p>
              <p className="text-[11px] text-slate-400">Measured from our Mumbai CtrlS racks</p>
            </div>

            <div className="p-4 bg-slate-900 rounded-xl border border-slate-800 space-y-1 text-center">
              <span className="text-2xl font-black text-purple-400 font-mono">99.99%</span>
              <p className="text-xs font-bold text-white">Network SLA Uptime</p>
              <p className="text-[11px] text-slate-400">With dual redundant fiber carriers</p>
            </div>
          </div>
        </div>

        {/* Security & Infrastructure Integrity */}
        <div className="p-8 rounded-2xl bg-gradient-to-r from-blue-950/40 via-slate-900 to-indigo-950/40 border border-blue-500/20 grid grid-cols-1 md:grid-cols-3 gap-6 text-xs text-slate-300">
          <div className="space-y-2">
            <h3 className="text-sm font-bold text-white flex items-center space-x-1.5">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span>Zero-Knowledge Architecture</span>
            </h3>
            <p className="text-slate-400 leading-relaxed">
              We never store your master passenger credentials or payment passwords on our servers. All sensitive data is encrypted client-side using AES-256 keys.
            </p>
          </div>

          <div className="space-y-2">
            <h3 className="text-sm font-bold text-white flex items-center space-x-1.5">
              <Server className="w-4 h-4 text-blue-400" />
              <span>Tier-4 Certified Datacenters</span>
            </h3>
            <p className="text-slate-400 leading-relaxed">
              Hosted in ISO 27001 & SOC-2 compliant facilities with 2N electrical redundancy, biometric physical security, and redundant diesel power generation.
            </p>
          </div>

          <div className="space-y-2">
            <h3 className="text-sm font-bold text-white flex items-center space-x-1.5">
              <Activity className="w-4 h-4 text-cyan-400" />
              <span>24/7 Proactive Monitoring</span>
            </h3>
            <p className="text-slate-400 leading-relaxed">
              Our Network Operations Center (NOC) monitors route latency and packet loss 24/7 to automatically re-route traffic via optimal BGP paths.
            </p>
          </div>
        </div>

        {/* CTA to get started */}
        <div className="text-center space-y-4">
          <h3 className="text-2xl font-extrabold text-white">Experience the TATKAL SUPER MASTER Advantage</h3>
          <p className="text-xs text-slate-400">Deploy your first Windows VPS or activate your Tatkal software license in under 60 seconds.</p>
          <button
            onClick={() => {
              setCurrentPage('tatkal-software');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            className="px-8 py-3.5 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white text-xs font-bold rounded-xl shadow-lg shadow-blue-900/40"
          >
            Explore All Solutions
          </button>
        </div>

      </div>
    </div>
  );
};
