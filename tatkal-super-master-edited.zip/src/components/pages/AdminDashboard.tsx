import React, { useState, useMemo } from 'react';
import { useApp } from '../../context/AppContext';
import { 
  ShieldAlert, 
  DollarSign, 
  Server, 
  Users, 
  Key, 
  Activity, 
  TrendingUp, 
  CheckCircle2, 
  Tag, 
  Plus, 
  Search,
  Eye,
  FileText,
  Package,
  AlertTriangle,
  CreditCard,
  MessageSquare,
  Trash2,
  Edit3,
  Check,
  X,
  Zap,
  Globe,
  Lock,
  Download,
  Send,
  RefreshCw,
  Sliders,
  Filter,
  Database,
  UploadCloud,
  Layers,
  Cpu,
  HardDrive,
  Flame,
  ArrowUpDown,
  RotateCcw,
  SlidersHorizontal,
  ToggleLeft,
  ToggleRight,
  Crown,
  Award,
  Sparkles,
  ExternalLink
} from 'lucide-react';
import { 
  PlanItem, 
  ServiceCategory, 
  SupportTicket, 
  DigitalDeliveryType, 
  VpsInventoryItem, 
  VpsPricingTier,
  VpsCategoryPlan,
  VpsServerCategoryMeta,
  ServerTypeKey
} from '../../types';

export const AdminDashboard: React.FC = () => {
  const { 
    // Inventory (MongoDB)
    inventory,
    vpsPricingTiers,
    categoryPlans,
    serverCategories,
    addInventoryItem,
    updateInventoryItem,
    deleteInventoryItem,
    updateInventoryStock,
    toggleInventoryActive,
    bulkImportInventory,
    updateVpsPricingTier,
    updateCategoryPlan,
    addCategoryPlan,
    deleteCategoryPlan,
    toggleCategoryPlanActive,
    updateServerCategory,
    resetInventoryToDefaults,

    // Products
    products, 
    addProduct, 
    updateProduct, 
    deleteProduct, 
    updateProductStock,

    // Orders & Tracking
    orders, 
    payments,
    tickets,
    replyTicket,
    updateTicketStatus,
    coupons,
    addCoupon,
    deleteCoupon,
    formatPrice, 
    addToast, 
    setSelectedOrderForInvoice 
  } = useApp();

  const [activeTab, setActiveTab] = useState<'inventory' | 'vps-pricing' | 'products' | 'orders' | 'payments' | 'tickets' | 'coupons' | 'overview'>('inventory');
  
  // =====================================
  // INVENTORY TAB STATE
  // =====================================
  const [invSearchQuery, setInvSearchQuery] = useState('');
  const [invCategoryFilter, setInvCategoryFilter] = useState('all');
  const [invStockFilter, setInvStockFilter] = useState<'all' | 'high' | 'medium' | 'low' | 'zero'>('all');
  
  // Modals for inventory
  const [isAddInvModalOpen, setIsAddInvModalOpen] = useState(false);
  const [editingInvItem, setEditingInvItem] = useState<VpsInventoryItem | null>(null);
  const [isBulkImportModalOpen, setIsBulkImportModalOpen] = useState(false);
  const [isPricingModalOpen, setIsPricingModalOpen] = useState(false);

  // Inventory form state
  const [invServerId, setInvServerId] = useState('');
  const [invIpRange, setInvIpRange] = useState('');
  const [invServerLabel, setInvServerLabel] = useState('');
  const [invAvailableStock, setInvAvailableStock] = useState(100);
  const [invCategory, setInvCategory] = useState('High-Speed Subnet');
  const [invPlanType, setInvPlanType] = useState('linux-vps');
  const [invLocation, setInvLocation] = useState('Mumbai CtrlS Datacenter');
  const [invCpu, setInvCpu] = useState('AMD EPYC 7763 64-Core');
  const [invRam, setInvRam] = useState('8 GB DDR4 ECC (Selectable)');
  const [invStorage, setInvStorage] = useState('160 GB NVMe Gen4');
  const [invBandwidth, setInvBandwidth] = useState('10 Gbps Unmetered Port');
  const [invIsActive, setInvIsActive] = useState(true);

  // =====================================
  // DYNAMIC CATEGORY PLANS & PRICING STATE
  // =====================================
  const [editingCategoryPlan, setEditingCategoryPlan] = useState<VpsCategoryPlan | null>(null);
  const [isAddPlanModalOpen, setIsAddPlanModalOpen] = useState(false);
  const [planServerType, setPlanServerType] = useState<ServerTypeKey>('normal');
  const [planCategoryName, setPlanCategoryName] = useState('Normal');
  const [planRam, setPlanRam] = useState('8 GB');
  const [planPriceINR, setPlanPriceINR] = useState(1399);
  const [planPriceUSD, setPlanPriceUSD] = useState(19);
  const [planCpu, setPlanCpu] = useState('4 vCPU AMD EPYC');
  const [planNvme, setPlanNvme] = useState('160 GB NVMe Gen4');
  const [planBandwidth, setPlanBandwidth] = useState('10 Gbps Unmetered');
  const [planPopular, setPlanPopular] = useState(false);
  const [planIsActive, setPlanIsActive] = useState(true);

  // Category Metadata Editing State
  const [editingCategoryMeta, setEditingCategoryMeta] = useState<VpsServerCategoryMeta | null>(null);
  const [isCategoryMetaModalOpen, setIsCategoryMetaModalOpen] = useState(false);
  const [metaDisplayName, setMetaDisplayName] = useState('');
  const [metaBadge, setMetaBadge] = useState('');
  const [metaDescription, setMetaDescription] = useState('');
  const [metaClockSpeed, setMetaClockSpeed] = useState('');
  const [metaPremiumColor, setMetaPremiumColor] = useState<'gold' | 'diamond' | 'blue'>('blue');

  // Bulk import form state
  const [bulkImportText, setBulkImportText] = useState(
`103.54.26 - Stock 202
103.186.44 - Stock 494
103.227 - Stock 244
103.85.118 - Stock 486
103.82.73 - Stock 10
103.182.44 - Stock 476
103.189.147 - Stock 229
103.82.7x AMD GOLD - Stock 90
103.109.18x GOLD SERVER - Stock 30
103.195 - Stock 236
103.93.17x - Stock 471
103.54 GOLD SERVER - Stock 499
103.148 - Stock 131
103.87 GOLD SERVER - Stock 459
103.103 GOLD SERVER - Stock 239
103.225 - Stock 50
103.101 - Stock 108
103.204.170 - Stock 7
103.47.x - Stock 223
103.241.139 - Stock 144
103.168.x - Stock 478
103.81.106 - Stock 245
103.184 DIAMOND PRO AMD - Stock 488
103.240.179 - Stock 451`
  );

  // VPS Pricing Editor state (local copy for modal)
  const [localPricingTiers, setLocalPricingTiers] = useState<VpsPricingTier[]>(vpsPricingTiers);

  // =====================================
  // PRODUCT STATE
  // =====================================
  const [productCategoryFilter, setProductCategoryFilter] = useState<string>('all');
  const [isAddProductModalOpen, setIsAddProductModalOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<PlanItem | null>(null);

  // New product form
  const [prodName, setProdName] = useState('');
  const [prodCategory, setProdCategory] = useState<ServiceCategory>('tatkal-software');
  const [prodTagline, setProdTagline] = useState('');
  const [prodPriceINR, setProdPriceINR] = useState(999);
  const [prodPriceUSD, setProdPriceUSD] = useState(16);
  const [prodStock, setProdStock] = useState(50);
  const [prodMinStockAlert, setProdMinStockAlert] = useState(5);
  const [prodDeliveryType, setProdDeliveryType] = useState<DigitalDeliveryType>('software_license');
  const [prodDownloadUrl, setProdDownloadUrl] = useState('https://downloads.tatkalsupermaster.com/v4.8/TSM_Pro_Setup.exe');
  const [prodLocation, setProdLocation] = useState('Mumbai CtrlS Datacenter');
  const [prodActivationTime, setProdActivationTime] = useState('Instant (< 60s)');
  const [prodNotes, setProdNotes] = useState('Auto-delivers license key and download link instantly.');

  // Order search
  const [orderSearchQuery, setOrderSearchQuery] = useState('');

  // Payment filter
  const [gatewayFilter, setGatewayFilter] = useState<string>('all');

  // Ticket reply
  const [selectedTicket, setSelectedTicket] = useState<SupportTicket | null>(null);
  const [adminReplyText, setAdminReplyText] = useState('');

  // Coupon form
  const [newCouponCode, setNewCouponCode] = useState('');
  const [newCouponDiscount, setNewCouponDiscount] = useState('20');
  const [newCouponMaxDisc, setNewCouponMaxDisc] = useState('500');

  // =====================================
  // AGGREGATE CALCULATIONS
  // =====================================
  const totalRevenue = orders.reduce((sum, o) => sum + o.total, 0) + 1428500;
  
  const totalInvStock = useMemo(() => {
    return inventory.reduce((acc, item) => acc + (item.isActive ? item.availableStock : 0), 0);
  }, [inventory]);

  const invLowStockNodes = useMemo(() => {
    return inventory.filter(i => i.isActive && i.availableStock > 0 && i.availableStock < 20).length;
  }, [inventory]);

  const invOutOfStockNodes = useMemo(() => {
    return inventory.filter(i => i.isActive && i.availableStock <= 0).length;
  }, [inventory]);

  const totalCatalogStock = products.reduce((sum, p) => sum + (p.stockQuantity || 0), 0);

  // Filtered inventory
  const filteredInventory = useMemo(() => {
    return inventory.filter(item => {
      if (invSearchQuery.trim()) {
        const q = invSearchQuery.toLowerCase();
        const mIp = item.ipRange.toLowerCase().includes(q);
        const mLbl = item.serverLabel.toLowerCase().includes(q);
        const mLoc = item.location.toLowerCase().includes(q);
        if (!mIp && !mLbl && !mLoc) return false;
      }

      if (invCategoryFilter !== 'all') {
        if (!item.category.toLowerCase().includes(invCategoryFilter.toLowerCase())) return false;
      }

      if (invStockFilter === 'high' && item.availableStock < 100) return false;
      if (invStockFilter === 'medium' && (item.availableStock < 20 || item.availableStock >= 100)) return false;
      if (invStockFilter === 'low' && (item.availableStock >= 20 || item.availableStock <= 0)) return false;
      if (invStockFilter === 'zero' && item.availableStock > 0) return false;

      return true;
    });
  }, [inventory, invSearchQuery, invCategoryFilter, invStockFilter]);

  // Handlers for Inventory
  const handleOpenAddInvModal = () => {
    setEditingInvItem(null);
    setInvServerId(`srv-node-${Math.floor(100 + Math.random() * 900)}`);
    setInvIpRange('103.145.88');
    setInvServerLabel('103.145.88 Ultra Node');
    setInvAvailableStock(150);
    setInvCategory('High-Speed Subnet');
    setInvPlanType('linux-vps');
    setInvLocation('Mumbai CtrlS Datacenter');
    setInvCpu('AMD EPYC 7763 64-Core');
    setInvRam('8 GB DDR4 ECC (Selectable)');
    setInvStorage('160 GB NVMe Gen4');
    setInvBandwidth('10 Gbps Unmetered Port');
    setInvIsActive(true);
    setIsAddInvModalOpen(true);
  };

  const handleEditInvItem = (item: VpsInventoryItem) => {
    setEditingInvItem(item);
    setInvServerId(item.serverId);
    setInvIpRange(item.ipRange);
    setInvServerLabel(item.serverLabel);
    setInvAvailableStock(item.availableStock);
    setInvCategory(item.category);
    setInvPlanType(item.planType);
    setInvLocation(item.location);
    setInvCpu(item.cpu);
    setInvRam(item.ram);
    setInvStorage(item.storage);
    setInvBandwidth(item.bandwidth);
    setInvIsActive(item.isActive);
    setIsAddInvModalOpen(true);
  };

  const handleSaveInvItem = (e: React.FormEvent) => {
    e.preventDefault();
    if (!invIpRange || !invServerLabel) {
      addToast('error', 'Required Fields', 'IP Range and Server Label are required.');
      return;
    }

    if (editingInvItem) {
      updateInventoryItem(editingInvItem._id || editingInvItem.serverId, {
        serverId: invServerId,
        ipRange: invIpRange,
        serverLabel: invServerLabel,
        availableStock: Number(invAvailableStock),
        status: Number(invAvailableStock) > 0 ? 'available' : 'out_of_stock',
        category: invCategory,
        planType: invPlanType,
        location: invLocation,
        cpu: invCpu,
        ram: invRam,
        storage: invStorage,
        bandwidth: invBandwidth,
        isActive: invIsActive
      });
    } else {
      addInventoryItem({
        serverId: invServerId || `srv-node-${Math.floor(100 + Math.random() * 900)}`,
        ipRange: invIpRange,
        serverLabel: invServerLabel,
        availableStock: Number(invAvailableStock),
        status: Number(invAvailableStock) > 0 ? 'available' : 'out_of_stock',
        category: invCategory,
        planType: invPlanType,
        location: invLocation,
        cpu: invCpu,
        ram: invRam,
        storage: invStorage,
        bandwidth: invBandwidth,
        isActive: invIsActive
      });
    }
    setIsAddInvModalOpen(false);
  };

  const handleBulkImportSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!bulkImportText.trim()) {
      addToast('error', 'Empty Input', 'Please paste stock data lines.');
      return;
    }
    const result = bulkImportInventory(bulkImportText);
    if (result.importedCount > 0) {
      setIsBulkImportModalOpen(false);
    }
  };

  const handleOpenPricingModal = () => {
    setLocalPricingTiers([...vpsPricingTiers]);
    setIsPricingModalOpen(true);
  };

  const handleSavePricingTiers = (e: React.FormEvent) => {
    e.preventDefault();
    localPricingTiers.forEach(t => {
      updateVpsPricingTier(t.ram, t.priceINR);
    });
    setIsPricingModalOpen(false);
    addToast('success', 'Pricing Updated', 'Linux VPS pricing tiers updated across marketplace.');
  };

  // =====================================
  // DYNAMIC CATEGORY PLANS & METADATA HANDLERS
  // =====================================
  const handleOpenAddPlanModal = (targetType: ServerTypeKey = 'normal') => {
    setEditingCategoryPlan(null);
    setPlanServerType(targetType);
    const catName = targetType === 'gold' ? 'Gold Server' : targetType === 'diamond' ? 'Diamond Pro AMD' : 'Normal';
    setPlanCategoryName(catName);
    setPlanRam(targetType === 'diamond' ? '16 GB' : targetType === 'gold' ? '8 GB' : '8 GB');
    setPlanPriceINR(targetType === 'diamond' ? 2799 : targetType === 'gold' ? 1500 : 1399);
    setPlanPriceUSD(targetType === 'diamond' ? 37 : targetType === 'gold' ? 20 : 19);
    setPlanCpu(targetType === 'diamond' ? '8 vCPU AMD EPYC 9654 + Ryzen 9 (3.1 GHz)' : targetType === 'gold' ? '4 vCPU AMD Ryzen 9 7950X (3.0 GHz)' : '4 vCPU AMD EPYC');
    setPlanNvme('160 GB NVMe Gen4');
    setPlanBandwidth(targetType === 'normal' ? '10 Gbps Unmetered' : '10 Gbps Dedicated Line');
    setPlanPopular(false);
    setPlanIsActive(true);
    setIsAddPlanModalOpen(true);
  };

  const handleOpenEditPlanModal = (plan: VpsCategoryPlan) => {
    setEditingCategoryPlan(plan);
    setPlanServerType(plan.serverType);
    setPlanCategoryName(plan.categoryName);
    setPlanRam(plan.ram);
    setPlanPriceINR(plan.priceINR);
    setPlanPriceUSD(plan.priceUSD);
    setPlanCpu(plan.vCpu);
    setPlanNvme(plan.nvme);
    setPlanBandwidth(plan.bandwidth);
    setPlanPopular(Boolean(plan.popular));
    setPlanIsActive(plan.isActive);
    setIsAddPlanModalOpen(true);
  };

  const handleSaveCategoryPlan = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingCategoryPlan) {
      updateCategoryPlan(editingCategoryPlan.id, {
        serverType: planServerType,
        categoryName: planCategoryName,
        ram: planRam,
        priceINR: Number(planPriceINR),
        priceUSD: Number(planPriceUSD),
        vCpu: planCpu,
        nvme: planNvme,
        bandwidth: planBandwidth,
        popular: planPopular,
        isActive: planIsActive
      });
      addToast('success', 'Plan Updated', `${planCategoryName} ${planRam} plan saved.`);
    } else {
      addCategoryPlan({
        serverType: planServerType,
        categoryName: planCategoryName,
        ram: planRam,
        priceINR: Number(planPriceINR),
        priceUSD: Number(planPriceUSD),
        vCpu: planCpu,
        nvme: planNvme,
        bandwidth: planBandwidth,
        popular: planPopular,
        isActive: planIsActive
      });
      addToast('success', 'Plan Added', `New ${planCategoryName} ${planRam} plan added to MongoDB.`);
    }
    setIsAddPlanModalOpen(false);
  };

  const handleOpenEditCategoryMeta = (cat: VpsServerCategoryMeta) => {
    setEditingCategoryMeta(cat);
    setMetaDisplayName(cat.displayName);
    setMetaBadge(cat.badge);
    setMetaDescription(cat.description);
    setMetaClockSpeed(cat.clockSpeed || '');
    setMetaPremiumColor(cat.premiumColor);
    setIsCategoryMetaModalOpen(true);
  };

  const handleSaveCategoryMeta = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingCategoryMeta) return;
    updateServerCategory(editingCategoryMeta.serverType, {
      displayName: metaDisplayName,
      badge: metaBadge,
      description: metaDescription,
      clockSpeed: metaClockSpeed,
      premiumColor: metaPremiumColor
    });
    setIsCategoryMetaModalOpen(false);
    addToast('success', 'Category Updated', `${metaDisplayName} metadata & badge saved.`);
  };

  // Product Catalog Handlers
  const handleSaveProduct = (e: React.FormEvent) => {
    e.preventDefault();
    if (!prodName) {
      addToast('error', 'Error', 'Product name is required.');
      return;
    }

    if (editingProduct) {
      updateProduct(editingProduct.id, {
        name: prodName,
        category: prodCategory,
        tagline: prodTagline,
        priceINR: Number(prodPriceINR),
        priceUSD: Number(prodPriceUSD),
        stockQuantity: Number(prodStock),
        minStockAlert: Number(prodMinStockAlert),
        digitalDeliveryType: prodDeliveryType,
        downloadUrl: prodDownloadUrl,
        location: prodLocation,
        activationTime: prodActivationTime,
        deliveryNotes: prodNotes
      });
      setEditingProduct(null);
    } else {
      addProduct({
        name: prodName,
        category: prodCategory,
        tagline: prodTagline || 'Enterprise grade tatkal automation solution',
        priceINR: Number(prodPriceINR),
        priceUSD: Number(prodPriceUSD),
        stockQuantity: Number(prodStock),
        minStockAlert: Number(prodMinStockAlert),
        digitalDeliveryType: prodDeliveryType,
        downloadUrl: prodDownloadUrl,
        location: prodLocation,
        activationTime: prodActivationTime,
        deliveryNotes: prodNotes,
        period: '/month'
      });
    }

    setIsAddProductModalOpen(false);
    resetProductForm();
  };

  const resetProductForm = () => {
    setProdName('');
    setProdCategory('tatkal-software');
    setProdTagline('');
    setProdPriceINR(999);
    setProdPriceUSD(16);
    setProdStock(50);
    setProdMinStockAlert(5);
    setProdDeliveryType('software_license');
    setProdDownloadUrl('https://downloads.tatkalsupermaster.com/v4.8/TSM_Pro_Setup.exe');
    setProdLocation('Mumbai CtrlS Datacenter');
    setProdActivationTime('Instant (< 60s)');
    setProdNotes('Auto-delivers license key and download link instantly.');
    setEditingProduct(null);
  };

  const handleEditClick = (p: PlanItem) => {
    setEditingProduct(p);
    setProdName(p.name);
    setProdCategory(p.category);
    setProdTagline(p.tagline);
    setProdPriceINR(p.priceINR);
    setProdPriceUSD(p.priceUSD);
    setProdStock(p.stockQuantity);
    setProdMinStockAlert(p.minStockAlert || 5);
    setProdDeliveryType(p.digitalDeliveryType || 'software_license');
    setProdDownloadUrl(p.downloadUrl || '');
    setProdLocation(p.location || 'Mumbai CtrlS Datacenter');
    setProdActivationTime(p.activationTime || 'Instant (< 60s)');
    setProdNotes(p.deliveryNotes || '');
    setIsAddProductModalOpen(true);
  };

  const handleAdminReplyTicket = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedTicket || !adminReplyText.trim()) return;
    replyTicket(selectedTicket.id, adminReplyText, 'admin');
    setAdminReplyText('');
  };

  const handleCreateCoupon = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCouponCode) return;
    addCoupon({
      code: newCouponCode.toUpperCase(),
      discountPercentage: Number(newCouponDiscount),
      maxDiscountINR: Number(newCouponMaxDisc),
      isActive: true,
      description: `${newCouponDiscount}% platform promotional discount`,
      usesCount: 0
    });
    setNewCouponCode('');
  };

  const filteredProducts = productCategoryFilter === 'all'
    ? products
    : products.filter(p => p.category === productCategoryFilter);

  const filteredOrders = orders.filter(o => 
    o.orderNumber.toLowerCase().includes(orderSearchQuery.toLowerCase()) ||
    o.customerName.toLowerCase().includes(orderSearchQuery.toLowerCase()) ||
    o.customerEmail.toLowerCase().includes(orderSearchQuery.toLowerCase())
  );

  const filteredPayments = gatewayFilter === 'all'
    ? payments
    : payments.filter(p => p.gateway === gatewayFilter);

  return (
    <div id="admin-dashboard-page" className="min-h-screen bg-[#050811] text-slate-100 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        
        {/* Admin Header */}
        <div className="rounded-3xl bg-gradient-to-r from-amber-950/80 via-[#0d162d] to-indigo-950/70 border border-amber-500/40 p-6 sm:p-8 flex flex-col lg:flex-row lg:items-center justify-between gap-6 shadow-2xl">
          <div className="space-y-2">
            <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-amber-500/20 border border-amber-500/30 text-amber-300 text-xs font-bold font-mono">
              <ShieldAlert className="w-3.5 h-3.5 text-amber-400" />
              <span>SUPER ADMIN COMMAND CENTER</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-black text-white">Stock Management &amp; VPS Marketplace Controls</h1>
            <p className="text-xs text-slate-300 max-w-2xl leading-relaxed">
              Manage MongoDB inventory collections, live subnet stock levels, automated Razorpay delivery workflows, Linux pricing tiers, and support queues.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2.5">
            <button
              onClick={handleOpenAddInvModal}
              className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold flex items-center space-x-1.5 shadow-lg shadow-emerald-950 transition-all"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>+ Add Subnet Node</span>
            </button>

            <button
              onClick={() => setIsBulkImportModalOpen(true)}
              className="px-3.5 py-2 bg-slate-800 hover:bg-slate-700 text-cyan-300 border border-slate-700 rounded-xl text-xs font-bold flex items-center space-x-1.5 transition-all"
            >
              <UploadCloud className="w-3.5 h-3.5" />
              <span>Bulk Import</span>
            </button>

            <button
              onClick={handleOpenPricingModal}
              className="px-3.5 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-bold flex items-center space-x-1.5 shadow-lg shadow-blue-950 transition-all"
            >
              <SlidersHorizontal className="w-3.5 h-3.5" />
              <span>VPS Prices</span>
            </button>
          </div>
        </div>

        {/* Analytics Summary Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-5">
          
          <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-2">
            <div className="flex items-center justify-between text-slate-400 text-xs font-medium">
              <span>MongoDB VPS Inventory</span>
              <Database className="w-4 h-4 text-emerald-400" />
            </div>
            <div className="text-2xl font-black text-white font-mono">
              {totalInvStock.toLocaleString('en-IN')} <span className="text-xs text-slate-400 font-sans font-normal">Instances</span>
            </div>
            <div className="flex items-center space-x-1 text-[11px] text-emerald-400 font-mono font-bold">
              <span>{inventory.length} Subnet Pools Active</span>
            </div>
          </div>

          <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-2">
            <div className="flex items-center justify-between text-slate-400 text-xs font-medium">
              <span>Low Stock Alerts</span>
              <Flame className="w-4 h-4 text-amber-400" />
            </div>
            <div className="text-2xl font-black text-amber-300 font-mono">
              {invLowStockNodes} <span className="text-xs text-slate-400 font-sans font-normal">Nodes (&lt;20 Left)</span>
            </div>
            <div className="text-[11px] text-slate-400 font-mono">
              {invOutOfStockNodes} Sold Out Nodes
            </div>
          </div>

          <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-2">
            <div className="flex items-center justify-between text-slate-400 text-xs font-medium">
              <span>Total Revenue Captured</span>
              <DollarSign className="w-4 h-4 text-emerald-400" />
            </div>
            <div className="text-2xl font-black text-white font-mono">
              {formatPrice(totalRevenue)}
            </div>
            <div className="flex items-center space-x-1 text-[11px] text-cyan-400 font-bold">
              <TrendingUp className="w-3 h-3" />
              <span>{orders.length} Verified Orders</span>
            </div>
          </div>

          <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-2">
            <div className="flex items-center justify-between text-slate-400 text-xs font-medium">
              <span>Support &amp; Payments</span>
              <MessageSquare className="w-4 h-4 text-purple-400" />
            </div>
            <div className="text-2xl font-black text-white font-mono">
              {tickets.length} <span className="text-xs text-slate-400 font-sans font-normal">Tickets</span>
            </div>
            <div className="text-[11px] text-purple-300 font-mono">
              {payments.length} Razorpay/UPI Ledgers
            </div>
          </div>

        </div>

        {/* Tab Navigation */}
        <div className="flex flex-wrap items-center gap-2 border-b border-slate-800 pb-3">
          <button
            onClick={() => setActiveTab('inventory')}
            className={`px-4 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center space-x-2 ${
              activeTab === 'inventory'
                ? 'bg-emerald-600 text-white shadow-md shadow-emerald-950'
                : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
            }`}
          >
            <Database className="w-3.5 h-3.5 text-emerald-300" />
            <span>VPS Subnet Inventory ({inventory.length} Nodes)</span>
          </button>

          <button
            onClick={() => setActiveTab('vps-pricing')}
            className={`px-4 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center space-x-2 ${
              activeTab === 'vps-pricing'
                ? 'bg-gradient-to-r from-amber-600 to-cyan-600 text-white shadow-md shadow-amber-950/40'
                : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
            }`}
          >
            <SlidersHorizontal className="w-3.5 h-3.5 text-amber-400" />
            <span>VPS Plans &amp; Dynamic Pricing</span>
          </button>

          <button
            onClick={() => setActiveTab('products')}
            className={`px-4 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center space-x-2 ${
              activeTab === 'products'
                ? 'bg-blue-600 text-white shadow-md shadow-blue-950'
                : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
            }`}
          >
            <Package className="w-3.5 h-3.5" />
            <span>Software &amp; Proxies ({products.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('orders')}
            className={`px-4 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center space-x-2 ${
              activeTab === 'orders'
                ? 'bg-blue-600 text-white shadow-md shadow-blue-950'
                : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
            }`}
          >
            <CheckCircle2 className="w-3.5 h-3.5" />
            <span>Orders ({orders.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('payments')}
            className={`px-4 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center space-x-2 ${
              activeTab === 'payments'
                ? 'bg-blue-600 text-white shadow-md shadow-blue-950'
                : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
            }`}
          >
            <CreditCard className="w-3.5 h-3.5" />
            <span>Payments Ledger ({payments.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('tickets')}
            className={`px-4 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center space-x-2 ${
              activeTab === 'tickets'
                ? 'bg-blue-600 text-white shadow-md shadow-blue-950'
                : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
            }`}
          >
            <MessageSquare className="w-3.5 h-3.5" />
            <span>Tickets ({tickets.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('coupons')}
            className={`px-4 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center space-x-2 ${
              activeTab === 'coupons'
                ? 'bg-blue-600 text-white shadow-md shadow-blue-950'
                : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
            }`}
          >
            <Tag className="w-3.5 h-3.5" />
            <span>Promo Coupons ({coupons.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('overview')}
            className={`px-4 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center space-x-2 ${
              activeTab === 'overview'
                ? 'bg-blue-600 text-white shadow-md shadow-blue-950'
                : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
            }`}
          >
            <Activity className="w-3.5 h-3.5" />
            <span>Cluster Health</span>
          </button>
        </div>

        {/* ========================================================================= */}
        {/* TAB 1: VPS SUBSET INVENTORY (MONGODB: collection('inventory'))             */}
        {/* ========================================================================= */}
        {activeTab === 'inventory' && (
          <div className="space-y-6">
            
            {/* Filter and Control Bar */}
            <div className="p-4 sm:p-5 rounded-2xl bg-slate-900/80 border border-slate-800 flex flex-col lg:flex-row lg:items-center justify-between gap-4">
              
              <div className="flex flex-wrap items-center gap-3">
                {/* Search */}
                <div className="relative w-full sm:w-64">
                  <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={invSearchQuery}
                    onChange={(e) => setInvSearchQuery(e.target.value)}
                    placeholder="Search IP or label..."
                    className="w-full pl-9 pr-3 py-1.5 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white focus:outline-none focus:border-emerald-500"
                  />
                </div>

                {/* Category Filter */}
                <div className="flex items-center space-x-1.5 text-xs">
                  <span className="text-slate-400 font-medium">Category:</span>
                  <select
                    value={invCategoryFilter}
                    onChange={(e) => setInvCategoryFilter(e.target.value)}
                    className="bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1 text-xs text-white focus:outline-none focus:border-emerald-500"
                  >
                    <option value="all">All Types ({inventory.length})</option>
                    <option value="Diamond">Diamond Pro AMD</option>
                    <option value="Gold">Gold Servers</option>
                    <option value="High-Speed">High-Speed Subnets</option>
                  </select>
                </div>

                {/* Stock Level Filter */}
                <div className="flex items-center space-x-1.5 text-xs">
                  <span className="text-slate-400 font-medium">Stock:</span>
                  <select
                    value={invStockFilter}
                    onChange={(e) => setInvStockFilter(e.target.value as any)}
                    className="bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1 text-xs text-white focus:outline-none focus:border-emerald-500"
                  >
                    <option value="all">All Stock Levels</option>
                    <option value="high">100+ High Stock</option>
                    <option value="medium">20-99 Medium</option>
                    <option value="low">&lt;20 Low Stock</option>
                    <option value="zero">0 Sold Out</option>
                  </select>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex flex-wrap items-center gap-2">
                <button
                  onClick={handleOpenAddInvModal}
                  className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-bold flex items-center space-x-1.5 transition-all shadow-md shadow-emerald-950/40"
                  title="Add a new server node / IP subnet to MongoDB inventory"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Add Subnet Node</span>
                </button>

                <button
                  onClick={() => setIsBulkImportModalOpen(true)}
                  className="px-3 py-1.5 bg-blue-600 hover:bg-blue-500 text-white rounded-lg text-xs font-bold flex items-center space-x-1.5 transition-all shadow-md shadow-blue-950/40"
                  title="Bulk import 24 subnets and stocks"
                >
                  <UploadCloud className="w-3.5 h-3.5" />
                  <span>Bulk Import</span>
                </button>

                <button
                  onClick={() => setActiveTab('vps-pricing')}
                  className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-cyan-300 border border-cyan-500/30 rounded-lg text-xs font-bold flex items-center space-x-1.5 transition-all"
                  title="Manage category pricing tiers"
                >
                  <SlidersHorizontal className="w-3.5 h-3.5" />
                  <span>Plans &amp; Pricing</span>
                </button>

                <button
                  onClick={resetInventoryToDefaults}
                  className="px-3 py-1.5 bg-slate-950 hover:bg-slate-800 border border-slate-800 text-slate-300 rounded-lg text-xs font-mono flex items-center space-x-1 transition-all"
                  title="Reset MongoDB inventory back to initial 24 seed subnets"
                >
                  <RotateCcw className="w-3.5 h-3.5 text-amber-400" />
                  <span>Reset 24 Stock</span>
                </button>
              </div>

            </div>

            {/* Inventory Table */}
            <div className="rounded-2xl bg-slate-900/80 border border-slate-800 overflow-hidden shadow-xl">
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs font-mono">
                  <thead className="bg-slate-950 text-slate-400 uppercase border-b border-slate-800">
                    <tr>
                      <th className="p-4">Server Node &amp; Subnet</th>
                      <th className="p-4">Category</th>
                      <th className="p-4">Stock Quantity</th>
                      <th className="p-4">Stock Status</th>
                      <th className="p-4">Hardware Specs</th>
                      <th className="p-4">Active</th>
                      <th className="p-4 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800">
                    {filteredInventory.map((item) => {
                      const isHigh = item.availableStock >= 100;
                      const isMed = item.availableStock >= 20 && item.availableStock < 100;
                      const isLow = item.availableStock > 0 && item.availableStock < 20;
                      const isOut = item.availableStock <= 0;

                      return (
                        <tr key={item._id || item.serverId} className="hover:bg-slate-800/40 transition-colors">
                          
                          {/* IP & Server Label */}
                          <td className="p-4">
                            <div className="flex items-baseline space-x-2">
                              <span className="font-bold text-white text-sm font-sans">{item.serverLabel}</span>
                            </div>
                            <div className="flex items-center space-x-2 mt-0.5">
                              <span className="text-[11px] font-mono text-cyan-400 bg-cyan-500/10 border border-cyan-500/20 px-1.5 py-0.5 rounded">
                                {item.ipRange}
                              </span>
                              <span className="text-[10px] text-slate-400 font-sans">
                                {item.location}
                              </span>
                            </div>
                          </td>

                          {/* Category */}
                          <td className="p-4">
                            <span className="px-2 py-0.5 rounded text-[10px] bg-slate-800 text-slate-200 uppercase font-sans font-bold">
                              {item.category}
                            </span>
                          </td>

                          {/* Editable Stock with Quick Adjustment Buttons */}
                          <td className="p-4">
                            <div className="flex items-center space-x-1.5">
                              <button
                                onClick={() => updateInventoryStock(item._id || item.serverId, Math.max(0, item.availableStock - 10))}
                                className="w-6 h-6 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 text-[10px] font-bold"
                                title="-10"
                              >
                                -10
                              </button>
                              <button
                                onClick={() => updateInventoryStock(item._id || item.serverId, Math.max(0, item.availableStock - 1))}
                                className="w-6 h-6 rounded bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs"
                                title="-1"
                              >
                                -
                              </button>
                              
                              <input
                                type="number"
                                min="0"
                                value={item.availableStock}
                                onChange={(e) => updateInventoryStock(item._id || item.serverId, Number(e.target.value))}
                                className="w-16 px-1.5 py-0.5 bg-black/60 border border-slate-700 rounded text-center text-white font-bold font-mono text-xs focus:outline-none focus:border-emerald-500"
                              />

                              <button
                                onClick={() => updateInventoryStock(item._id || item.serverId, item.availableStock + 1)}
                                className="w-6 h-6 rounded bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs"
                                title="+1"
                              >
                                +
                              </button>
                              <button
                                onClick={() => updateInventoryStock(item._id || item.serverId, item.availableStock + 50)}
                                className="w-7 h-6 rounded bg-slate-800 hover:bg-slate-700 text-emerald-400 text-[10px] font-bold"
                                title="+50"
                              >
                                +50
                              </button>
                            </div>
                          </td>

                          {/* Stock Status Badge */}
                          <td className="p-4">
                            {isOut ? (
                              <span className="px-2 py-0.5 rounded text-[10px] bg-rose-950 text-rose-300 border border-rose-800 font-bold uppercase">
                                0 Sold Out
                              </span>
                            ) : isLow ? (
                              <span className="px-2 py-0.5 rounded text-[10px] bg-rose-900/60 text-rose-200 border border-rose-500/50 font-bold uppercase animate-pulse">
                                Low ({item.availableStock})
                              </span>
                            ) : isMed ? (
                              <span className="px-2 py-0.5 rounded text-[10px] bg-amber-950/80 text-amber-300 border border-amber-500/30 font-bold uppercase">
                                Medium ({item.availableStock})
                              </span>
                            ) : (
                              <span className="px-2 py-0.5 rounded text-[10px] bg-emerald-950/80 text-emerald-300 border border-emerald-500/30 font-bold uppercase">
                                High ({item.availableStock})
                              </span>
                            )}
                          </td>

                          {/* Hardware Specs */}
                          <td className="p-4 text-slate-300 text-[11px]">
                            <div>{item.cpu}</div>
                            <div className="text-[10px] text-slate-400">{item.storage} • {item.bandwidth}</div>
                          </td>

                          {/* Enable / Disable Toggle */}
                          <td className="p-4">
                            <button
                              onClick={() => toggleInventoryActive(item._id || item.serverId)}
                              className={`px-2.5 py-1 rounded-full text-[10px] font-bold transition-all flex items-center space-x-1 ${
                                item.isActive 
                                  ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30' 
                                  : 'bg-slate-800 text-slate-400 border border-slate-700'
                              }`}
                            >
                              <span className={`w-1.5 h-1.5 rounded-full ${item.isActive ? 'bg-emerald-400' : 'bg-slate-500'}`} />
                              <span>{item.isActive ? 'Active' : 'Disabled'}</span>
                            </button>
                          </td>

                          {/* Actions */}
                          <td className="p-4 text-right">
                            <div className="flex items-center justify-end space-x-1.5">
                              <button
                                onClick={() => handleEditInvItem(item)}
                                className="p-1.5 rounded bg-slate-800 hover:bg-blue-600 text-slate-300 hover:text-white transition-colors"
                                title="Edit Subnet Specs"
                              >
                                <Edit3 className="w-3.5 h-3.5" />
                              </button>
                              <button
                                onClick={() => deleteInventoryItem(item._id || item.serverId)}
                                className="p-1.5 rounded bg-slate-800 hover:bg-red-600 text-slate-300 hover:text-white transition-colors"
                                title="Delete Subnet Node"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </td>

                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>

          </div>
        )}

        {/* ========================================================================= */}
        {/* TAB 1.5: VPS PLANS & DYNAMIC PRICING (CATEGORY-BASED PRICING MATRIX)     */}
        {/* ========================================================================= */}
        {activeTab === 'vps-pricing' && (
          <div className="space-y-8">
            
            {/* Top Overview & Action Bar */}
            <div className="p-5 rounded-2xl bg-gradient-to-r from-slate-900 via-blue-950/40 to-slate-900 border border-slate-800 flex flex-col md:flex-row md:items-center justify-between gap-4 shadow-xl">
              <div className="space-y-1">
                <div className="flex items-center space-x-2">
                  <SlidersHorizontal className="w-5 h-5 text-amber-400" />
                  <h2 className="text-base font-bold text-white tracking-wide">
                    Dynamic VPS Pricing &amp; Category Plans
                  </h2>
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-mono bg-emerald-500/10 text-emerald-300 border border-emerald-500/20">
                    MongoDB Real-Time Sync
                  </span>
                </div>
                <p className="text-xs text-slate-400">
                  Manage exact RAM tier prices, hardware specs, allowed plans, and marketing badges for Normal, Gold, and Diamond servers.
                </p>
              </div>

              <div className="flex flex-wrap items-center gap-2">
                <button
                  onClick={() => handleOpenAddPlanModal('normal')}
                  className="px-3.5 py-2 bg-gradient-to-r from-blue-600 to-cyan-500 hover:from-blue-500 hover:to-cyan-400 text-white rounded-xl text-xs font-bold flex items-center space-x-1.5 shadow-lg shadow-blue-950/50 transition-all"
                >
                  <Plus className="w-4 h-4" />
                  <span>Add New Plan</span>
                </button>
              </div>
            </div>

            {/* Server Categories List */}
            <div className="space-y-8">
              {serverCategories.map((category) => {
                const plansForCat = categoryPlans.filter(p => p.serverType === category.serverType);
                const isGold = category.serverType === 'gold';
                const isDiamond = category.serverType === 'diamond';
                const isNormal = category.serverType === 'normal';

                const borderTheme = isDiamond 
                  ? 'border-cyan-500/40 shadow-cyan-950/30' 
                  : isGold 
                  ? 'border-amber-500/40 shadow-amber-950/30' 
                  : 'border-blue-500/30 shadow-blue-950/20';

                const headerBg = isDiamond
                  ? 'from-cyan-950/80 via-blue-950/60 to-slate-900 border-cyan-500/30'
                  : isGold
                  ? 'from-amber-950/80 via-yellow-950/60 to-slate-900 border-amber-500/30'
                  : 'from-blue-950/80 via-indigo-950/60 to-slate-900 border-blue-500/30';

                const badgeBg = isDiamond
                  ? 'bg-gradient-to-r from-cyan-500 to-blue-500 text-slate-950 shadow-cyan-500/20'
                  : isGold
                  ? 'bg-gradient-to-r from-amber-400 to-yellow-500 text-slate-950 shadow-amber-500/20'
                  : 'bg-gradient-to-r from-blue-500 to-indigo-500 text-white shadow-blue-500/20';

                return (
                  <div key={category.id} className={`rounded-2xl bg-slate-900/90 border ${borderTheme} overflow-hidden shadow-2xl transition-all`}>
                    
                    {/* Category Header */}
                    <div className={`p-5 sm:p-6 bg-gradient-to-r ${headerBg} border-b flex flex-col md:flex-row md:items-center justify-between gap-4`}>
                      <div className="space-y-1.5">
                        <div className="flex flex-wrap items-center gap-2.5">
                          {isDiamond ? (
                            <Sparkles className="w-5 h-5 text-cyan-400" />
                          ) : isGold ? (
                            <Crown className="w-5 h-5 text-amber-400" />
                          ) : (
                            <Server className="w-5 h-5 text-blue-400" />
                          )}
                          <h3 className="text-lg font-black text-white tracking-wide">
                            {category.displayName}
                          </h3>
                          <span className={`px-2.5 py-0.5 rounded-md text-[11px] font-black uppercase tracking-wider ${badgeBg} shadow-sm`}>
                            {category.badge}
                          </span>
                        </div>
                        <p className="text-xs text-slate-300 max-w-2xl leading-relaxed">
                          {category.description}
                        </p>
                        <div className="flex flex-wrap items-center gap-2 pt-1">
                          <span className="text-[11px] text-slate-400 font-mono">
                            Allowed Customer RAM Tiers:
                          </span>
                          {category.allowedRams.map(ram => (
                            <span key={ram} className="px-2 py-0.5 rounded bg-black/50 border border-slate-700 text-cyan-300 text-[10px] font-mono font-bold">
                              {ram}
                            </span>
                          ))}
                        </div>
                      </div>

                      <div className="flex items-center space-x-2 shrink-0">
                        <button
                          onClick={() => handleOpenEditCategoryMeta(category)}
                          className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl text-xs font-bold flex items-center space-x-1.5 border border-slate-700 transition-all"
                          title="Edit Category Name, Badge & Clock Speed"
                        >
                          <Edit3 className="w-3.5 h-3.5" />
                          <span>Edit Category Info</span>
                        </button>
                        <button
                          onClick={() => handleOpenAddPlanModal(category.serverType)}
                          className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center space-x-1.5 transition-all text-white ${
                            isDiamond ? 'bg-cyan-600 hover:bg-cyan-500 shadow-lg shadow-cyan-950/50' : isGold ? 'bg-amber-600 hover:bg-amber-500 shadow-lg shadow-amber-950/50' : 'bg-blue-600 hover:bg-blue-500 shadow-lg shadow-blue-950/50'
                          }`}
                        >
                          <Plus className="w-3.5 h-3.5" />
                          <span>Add Plan</span>
                        </button>
                      </div>
                    </div>

                    {/* Category Plans Grid / Table */}
                    <div className="p-4 sm:p-6 space-y-4">
                      {plansForCat.length === 0 ? (
                        <div className="p-8 text-center bg-slate-950/50 rounded-xl border border-dashed border-slate-800">
                          <p className="text-xs text-slate-400">No active plans configured for this server category.</p>
                          <button
                            onClick={() => handleOpenAddPlanModal(category.serverType)}
                            className="mt-3 px-3 py-1.5 bg-blue-600 text-white rounded-lg text-xs font-bold"
                          >
                            + Create First Plan
                          </button>
                        </div>
                      ) : (
                        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-4">
                          {plansForCat.map((plan) => (
                            <div
                              key={plan.id}
                              className={`p-4 rounded-xl bg-slate-950 border transition-all relative flex flex-col justify-between ${
                                plan.isActive ? 'border-slate-800 hover:border-slate-700' : 'border-slate-800/40 opacity-60'
                              }`}
                            >
                              {/* Popular Tag */}
                              {plan.popular && (
                                <span className="absolute -top-2.5 right-3 px-2 py-0.5 bg-gradient-to-r from-amber-500 to-orange-500 text-black text-[9px] font-black uppercase rounded-full shadow-md">
                                  POPULAR CHOICE
                                </span>
                              )}

                              <div className="space-y-3">
                                {/* RAM & Server Type */}
                                <div className="flex items-center justify-between">
                                  <div className="flex items-baseline space-x-1.5">
                                    <span className="text-lg font-black text-white font-mono">{plan.ram}</span>
                                    <span className="text-[10px] text-slate-400 font-sans uppercase font-bold">RAM</span>
                                  </div>
                                  <button
                                    onClick={() => toggleCategoryPlanActive(plan.id)}
                                    className={`px-2 py-0.5 rounded-full text-[10px] font-bold transition-all ${
                                      plan.isActive
                                        ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                                        : 'bg-slate-800 text-slate-400 border border-slate-700'
                                    }`}
                                    title="Toggle plan availability in customer marketplace"
                                  >
                                    {plan.isActive ? 'Active' : 'Disabled'}
                                  </button>
                                </div>

                                {/* Price Box with Inline Edit */}
                                <div className="p-3 rounded-lg bg-slate-900/90 border border-slate-800 space-y-1.5">
                                  <div className="flex items-center justify-between">
                                    <span className="text-[10px] text-slate-400 font-bold uppercase">Monthly Price:</span>
                                    <span className="text-xs text-slate-400 font-mono">${plan.priceUSD} USD</span>
                                  </div>
                                  <div className="flex items-baseline space-x-1">
                                    <span className="text-xs font-bold text-slate-400">₹</span>
                                    <span className="text-2xl font-black text-white font-mono">
                                      {plan.priceINR.toLocaleString('en-IN')}
                                    </span>
                                    <span className="text-[11px] text-slate-400">/mo</span>
                                  </div>
                                </div>

                                {/* Specs List */}
                                <div className="space-y-1 text-xs text-slate-300 font-mono">
                                  <div className="flex items-center space-x-1.5 text-slate-300">
                                    <Cpu className="w-3.5 h-3.5 text-blue-400 shrink-0" />
                                    <span className="truncate text-[11px]">{plan.vCpu}</span>
                                  </div>
                                  <div className="flex items-center space-x-1.5 text-slate-300">
                                    <HardDrive className="w-3.5 h-3.5 text-purple-400 shrink-0" />
                                    <span className="truncate text-[11px]">{plan.nvme}</span>
                                  </div>
                                  <div className="flex items-center space-x-1.5 text-slate-300">
                                    <Zap className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                                    <span className="truncate text-[11px]">{plan.bandwidth}</span>
                                  </div>
                                </div>
                              </div>

                              {/* Card Action Footer */}
                              <div className="flex items-center justify-between pt-3 mt-3 border-t border-slate-800/80">
                                <button
                                  onClick={() => handleOpenEditPlanModal(plan)}
                                  className="px-2.5 py-1 bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-200 rounded-lg text-xs font-bold flex items-center space-x-1 transition-all"
                                >
                                  <Edit3 className="w-3 h-3 text-cyan-400" />
                                  <span>Edit Plan</span>
                                </button>
                                
                                <button
                                  onClick={() => deleteCategoryPlan(plan.id)}
                                  className="p-1 rounded bg-slate-900 hover:bg-rose-950 text-slate-400 hover:text-rose-300 transition-colors"
                                  title="Delete plan from category"
                                >
                                  <Trash2 className="w-3.5 h-3.5" />
                                </button>
                              </div>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>

                  </div>
                );
              })}
            </div>

          </div>
        )}

        {/* ========================================================================= */}
        {/* TAB 2: PRODUCTS & SOFTWARE CATALOG                                        */}
        {/* ========================================================================= */}
        {activeTab === 'products' && (
          <div className="space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-4 rounded-xl bg-slate-900/60 border border-slate-800">
              <div className="flex items-center space-x-2">
                <Filter className="w-4 h-4 text-slate-400" />
                <span className="text-xs font-bold text-slate-300">Category Filter:</span>
                <select
                  value={productCategoryFilter}
                  onChange={(e) => setProductCategoryFilter(e.target.value)}
                  className="bg-slate-950 border border-slate-800 rounded-lg px-3 py-1.5 text-xs text-white"
                >
                  <option value="all">All Categories ({products.length})</option>
                  <option value="tatkal-software">Tatkal Software</option>
                  <option value="windows-vps">Windows VPS</option>
                  <option value="linux-vps">Linux VPS</option>
                  <option value="residential-ip">Residential Clean IPs</option>
                  <option value="static-ip">Static Dedicated IPs</option>
                  <option value="datacenter-proxy">Datacenter Proxies</option>
                  <option value="rdp">RDP Services</option>
                </select>
              </div>

              <button
                onClick={() => { resetProductForm(); setIsAddProductModalOpen(true); }}
                className="px-3.5 py-1.5 bg-blue-600 hover:bg-blue-500 text-white rounded-lg text-xs font-bold flex items-center space-x-1.5"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Add Product</span>
              </button>
            </div>

            <div className="rounded-2xl bg-slate-900/80 border border-slate-800 overflow-hidden shadow-xl">
              <table className="w-full text-left text-xs font-mono">
                <thead className="bg-slate-950 text-slate-400 uppercase border-b border-slate-800">
                  <tr>
                    <th className="p-4">Product Name</th>
                    <th className="p-4">Category</th>
                    <th className="p-4">Price (INR)</th>
                    <th className="p-4">Stock Quantity</th>
                    <th className="p-4">Status</th>
                    <th className="p-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800">
                  {filteredProducts.map((p) => (
                    <tr key={p.id} className="hover:bg-slate-800/40">
                      <td className="p-4">
                        <span className="font-bold text-white block text-sm font-sans">{p.name}</span>
                        <span className="text-[10px] text-slate-400 font-sans">{p.tagline}</span>
                      </td>
                      <td className="p-4">
                        <span className="px-2 py-0.5 rounded text-[10px] bg-slate-800 text-cyan-300 uppercase">
                          {p.category}
                        </span>
                      </td>
                      <td className="p-4 text-white font-bold">
                        ₹{p.priceINR.toLocaleString('en-IN')}
                      </td>
                      <td className="p-4">
                        <div className="flex items-center space-x-2">
                          <button
                            onClick={() => updateProductStock(p.id, Math.max(0, p.stockQuantity - 1))}
                            className="w-6 h-6 rounded bg-slate-800 hover:bg-slate-700 text-white font-bold"
                          >
                            -
                          </button>
                          <span className="font-bold text-white px-2 py-0.5 bg-black/40 rounded border border-slate-700 min-w-[2.5rem] text-center">
                            {p.stockQuantity}
                          </span>
                          <button
                            onClick={() => updateProductStock(p.id, p.stockQuantity + 1)}
                            className="w-6 h-6 rounded bg-slate-800 hover:bg-slate-700 text-white font-bold"
                          >
                            +
                          </button>
                        </div>
                      </td>
                      <td className="p-4">
                        {p.stockQuantity <= 0 ? (
                          <span className="px-2 py-0.5 rounded text-[10px] bg-red-500/20 text-red-400 border border-red-500/30 font-bold uppercase">
                            Out of Stock
                          </span>
                        ) : (
                          <span className="px-2 py-0.5 rounded text-[10px] bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 font-bold uppercase">
                            In Stock ({p.stockQuantity})
                          </span>
                        )}
                      </td>
                      <td className="p-4 text-right">
                        <div className="flex items-center justify-end space-x-1.5">
                          <button
                            onClick={() => handleEditClick(p)}
                            className="p-1.5 rounded bg-slate-800 hover:bg-blue-600 text-slate-300 hover:text-white"
                          >
                            <Edit3 className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => deleteProduct(p.id)}
                            className="p-1.5 rounded bg-slate-800 hover:bg-red-600 text-slate-300 hover:text-white"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* ========================================================================= */}
        {/* TAB 3: ORDERS                                                             */}
        {/* ========================================================================= */}
        {activeTab === 'orders' && (
          <div className="space-y-4">
            <div className="flex items-center justify-between gap-4 p-4 rounded-xl bg-slate-900/60 border border-slate-800">
              <div className="relative w-full sm:w-80">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={orderSearchQuery}
                  onChange={(e) => setOrderSearchQuery(e.target.value)}
                  placeholder="Search by order ID, name, email..."
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-9 pr-4 py-2 text-xs text-white focus:outline-none focus:border-blue-500"
                />
              </div>
              <span className="text-xs text-slate-400 font-mono">Showing {filteredOrders.length} orders</span>
            </div>

            <div className="rounded-2xl bg-slate-900/80 border border-slate-800 overflow-hidden shadow-xl">
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs font-mono">
                  <thead className="bg-slate-950 text-slate-400 uppercase border-b border-slate-800">
                    <tr>
                      <th className="p-4">Order ID &amp; Date</th>
                      <th className="p-4">Customer</th>
                      <th className="p-4">Item &amp; Subnet</th>
                      <th className="p-4">Total Amount</th>
                      <th className="p-4">Provisioned IP / Key</th>
                      <th className="p-4">Status</th>
                      <th className="p-4 text-right">Invoice</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800">
                    {filteredOrders.map((ord) => (
                      <tr key={ord.id} className="hover:bg-slate-800/40">
                        <td className="p-4">
                          <span className="font-bold text-white block">{ord.orderNumber}</span>
                          <span className="text-[10px] text-slate-400">{ord.date}</span>
                        </td>
                        <td className="p-4 font-sans">
                          <span className="text-white block font-bold">{ord.customerName}</span>
                          <span className="text-[10px] text-slate-400 block">{ord.customerEmail}</span>
                          <span className="text-[10px] text-cyan-400">{ord.customerPhone}</span>
                        </td>
                        <td className="p-4">
                          <span className="text-cyan-300 font-bold block">{ord.items[0]?.planName}</span>
                          <span className="text-[10px] text-slate-400 uppercase">Paid via: {ord.paymentMethod} ({ord.transactionId})</span>
                        </td>
                        <td className="p-4 text-white font-bold">
                          {formatPrice(ord.total, ord.total / 85)}
                        </td>
                        <td className="p-4">
                          {ord.provisionedCredentials?.licenseKey && (
                            <span className="text-[10px] bg-slate-950 text-emerald-400 px-2 py-0.5 rounded block border border-slate-800 mb-1">
                              Key: {ord.provisionedCredentials.licenseKey}
                            </span>
                          )}
                          {ord.provisionedCredentials?.ip && (
                            <span className="text-[10px] bg-slate-950 text-cyan-300 px-2 py-0.5 rounded block border border-slate-800">
                              IP: {ord.provisionedCredentials.ip}:{ord.provisionedCredentials.port || 3389}
                            </span>
                          )}
                        </td>
                        <td className="p-4">
                          <span className="px-2.5 py-0.5 rounded text-[10px] bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 font-bold uppercase flex items-center space-x-1 w-fit">
                            <Check className="w-3 h-3" />
                            <span>{ord.fulfillmentStatus}</span>
                          </span>
                        </td>
                        <td className="p-4 text-right">
                          <button
                            onClick={() => setSelectedOrderForInvoice(ord)}
                            className="px-3 py-1.5 bg-slate-800 hover:bg-blue-600 text-white rounded-lg text-xs font-bold transition-all"
                          >
                            Invoice
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* ========================================================================= */}
        {/* TAB 4: PAYMENTS LEDGER                                                    */}
        {/* ========================================================================= */}
        {activeTab === 'payments' && (
          <div className="space-y-4">
            <div className="flex items-center justify-between p-4 rounded-xl bg-slate-900/60 border border-slate-800">
              <div className="flex items-center space-x-2 text-xs">
                <span className="font-bold text-slate-300">Gateway Filter:</span>
                <select
                  value={gatewayFilter}
                  onChange={(e) => setGatewayFilter(e.target.value)}
                  className="bg-slate-950 border border-slate-800 rounded-lg px-3 py-1.5 text-xs text-white"
                >
                  <option value="all">All Gateways ({payments.length})</option>
                  <option value="razorpay">Razorpay</option>
                  <option value="phonepe">PhonePe</option>
                  <option value="cashfree">Cashfree</option>
                  <option value="payu">PayU</option>
                  <option value="upi_qr">Direct UPI QR</option>
                  <option value="wallet">Prepaid Wallet</option>
                </select>
              </div>

              <span className="text-xs text-slate-400 font-mono">100% Real-Time Captured Transactions</span>
            </div>

            <div className="rounded-2xl bg-slate-900/80 border border-slate-800 overflow-hidden shadow-xl">
              <table className="w-full text-left text-xs font-mono">
                <thead className="bg-slate-950 text-slate-400 uppercase border-b border-slate-800">
                  <tr>
                    <th className="p-4">Payment Ref</th>
                    <th className="p-4">Order Ref</th>
                    <th className="p-4">Customer</th>
                    <th className="p-4">Gateway</th>
                    <th className="p-4">Txn ID</th>
                    <th className="p-4">Amount</th>
                    <th className="p-4">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800">
                  {filteredPayments.map((pay) => (
                    <tr key={pay.id} className="hover:bg-slate-800/40">
                      <td className="p-4 font-bold text-cyan-400">{pay.id}</td>
                      <td className="p-4 text-white">{pay.orderNumber}</td>
                      <td className="p-4 font-sans">
                        <span className="text-white block font-bold">{pay.customerName}</span>
                        <span className="text-[10px] text-slate-400">{pay.customerEmail}</span>
                      </td>
                      <td className="p-4">
                        <span className="px-2 py-0.5 rounded text-[10px] bg-slate-800 text-amber-300 uppercase font-bold">
                          {pay.gateway}
                        </span>
                      </td>
                      <td className="p-4 text-slate-300 select-all">{pay.gatewayTransactionId}</td>
                      <td className="p-4 text-white font-bold">
                        ₹{pay.amount.toLocaleString('en-IN')}
                      </td>
                      <td className="p-4">
                        <span className="px-2 py-0.5 rounded text-[10px] bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 font-bold uppercase">
                          {pay.status}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* ========================================================================= */}
        {/* TAB 5: SUPPORT TICKETS                                                    */}
        {/* ========================================================================= */}
        {activeTab === 'tickets' && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-1 space-y-3">
              <div className="p-4 bg-slate-900/80 border border-slate-800 rounded-2xl flex items-center justify-between">
                <span className="text-xs font-bold text-white uppercase tracking-wider">Tickets Queue</span>
                <span className="text-xs text-cyan-400 font-mono">{tickets.length} Total</span>
              </div>

              <div className="space-y-2.5 max-h-[600px] overflow-y-auto">
                {tickets.map((t) => (
                  <div
                    key={t.id}
                    onClick={() => setSelectedTicket(t)}
                    className={`p-4 rounded-xl border cursor-pointer transition-all ${
                      selectedTicket?.id === t.id
                        ? 'bg-blue-900/20 border-blue-500 shadow-lg shadow-blue-950'
                        : 'bg-slate-900/60 border-slate-800 hover:border-slate-700'
                    }`}
                  >
                    <div className="flex items-center justify-between text-xs mb-1.5">
                      <span className="font-mono font-bold text-white">{t.ticketNumber}</span>
                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                        t.status === 'open' ? 'bg-amber-500/20 text-amber-400' :
                        t.status === 'in_progress' ? 'bg-blue-500/20 text-blue-400' :
                        'bg-emerald-500/20 text-emerald-400'
                      }`}>
                        {t.status.replace('_', ' ')}
                      </span>
                    </div>
                    <h5 className="text-xs font-bold text-slate-200 line-clamp-1">{t.subject}</h5>
                    <div className="mt-2 flex items-center justify-between text-[11px] text-slate-400">
                      <span>{t.userName}</span>
                      <span className="font-mono text-[10px]">{t.updatedAt.split(' ')[0]}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="lg:col-span-2">
              {selectedTicket ? (
                <div className="p-6 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-4">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-800 gap-2">
                    <div>
                      <div className="flex items-center space-x-2">
                        <h3 className="text-base font-black text-white">{selectedTicket.subject}</h3>
                        <span className="text-xs font-mono text-cyan-400 font-bold">{selectedTicket.ticketNumber}</span>
                      </div>
                      <p className="text-xs text-slate-400 mt-1">
                        Client: <strong className="text-white">{selectedTicket.userName}</strong> ({selectedTicket.userEmail}) • Department: <strong className="text-cyan-300">{selectedTicket.department}</strong>
                      </p>
                    </div>

                    <div className="flex items-center space-x-2">
                      {selectedTicket.status !== 'resolved' && (
                        <button
                          onClick={() => updateTicketStatus(selectedTicket.id, 'resolved')}
                          className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-bold flex items-center space-x-1"
                        >
                          <Check className="w-3.5 h-3.5" />
                          <span>Mark Resolved</span>
                        </button>
                      )}
                    </div>
                  </div>

                  <div className="space-y-3 max-h-80 overflow-y-auto p-3 bg-black/40 rounded-xl border border-slate-800">
                    {selectedTicket.messages.map((m) => (
                      <div
                        key={m.id}
                        className={`p-3 rounded-xl max-w-[85%] text-xs space-y-1 ${
                          m.senderRole === 'admin' || m.senderRole === 'agent'
                            ? 'ml-auto bg-blue-900/40 border border-blue-500/30 text-slate-100'
                            : 'mr-auto bg-slate-800/80 border border-slate-700 text-slate-200'
                        }`}
                      >
                        <div className="flex items-center justify-between text-[10px] text-slate-400 border-b border-slate-700/50 pb-1">
                          <span className="font-bold text-white">{m.senderName} ({m.senderRole.toUpperCase()})</span>
                          <span className="font-mono">{m.timestamp}</span>
                        </div>
                        <p className="pt-1 whitespace-pre-wrap">{m.message}</p>
                      </div>
                    ))}
                  </div>

                  <form onSubmit={handleAdminReplyTicket} className="space-y-2 pt-2">
                    <label className="text-xs font-bold text-slate-300">Staff Response</label>
                    <textarea
                      rows={3}
                      value={adminReplyText}
                      onChange={(e) => setAdminReplyText(e.target.value)}
                      placeholder="Type official technical response to customer..."
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-xs text-white focus:outline-none focus:border-blue-500"
                    />
                    <div className="flex justify-end">
                      <button
                        type="submit"
                        className="px-5 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-bold flex items-center space-x-1.5 shadow-lg shadow-blue-900/40"
                      >
                        <Send className="w-3.5 h-3.5" />
                        <span>Send Response to Customer</span>
                      </button>
                    </div>
                  </form>
                </div>
              ) : (
                <div className="h-64 p-8 rounded-2xl bg-slate-900/40 border border-slate-800 flex flex-col items-center justify-center text-slate-400 text-xs">
                  <MessageSquare className="w-8 h-8 text-slate-600 mb-2" />
                  <span>Select a ticket on the left to view customer communication history.</span>
                </div>
              )}
            </div>
          </div>
        )}

        {/* ========================================================================= */}
        {/* TAB 6: PROMO COUPONS                                                      */}
        {/* ========================================================================= */}
        {activeTab === 'coupons' && (
          <div className="space-y-6">
            <div className="p-6 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-4">
              <h3 className="text-base font-bold text-white flex items-center space-x-2">
                <Tag className="w-4 h-4 text-cyan-400" />
                <span>Create New Discount Coupon</span>
              </h3>

              <form onSubmit={handleCreateCoupon} className="flex flex-col sm:flex-row gap-3 text-xs">
                <input
                  type="text"
                  required
                  value={newCouponCode}
                  onChange={(e) => setNewCouponCode(e.target.value)}
                  placeholder="Coupon Code (e.g. TSM50)"
                  className="w-full sm:w-1/3 bg-slate-950 border border-slate-800 rounded-xl px-4 py-2.5 text-white font-mono uppercase focus:outline-none focus:border-blue-500"
                />
                <input
                  type="number"
                  required
                  min="5"
                  max="90"
                  value={newCouponDiscount}
                  onChange={(e) => setNewCouponDiscount(e.target.value)}
                  placeholder="Discount %"
                  className="w-full sm:w-1/4 bg-slate-950 border border-slate-800 rounded-xl px-4 py-2.5 text-white font-mono focus:outline-none focus:border-blue-500"
                />
                <input
                  type="number"
                  min="100"
                  max="5000"
                  value={newCouponMaxDisc}
                  onChange={(e) => setNewCouponMaxDisc(e.target.value)}
                  placeholder="Max Cap INR"
                  className="w-full sm:w-1/4 bg-slate-950 border border-slate-800 rounded-xl px-4 py-2.5 text-white font-mono focus:outline-none focus:border-blue-500"
                />
                <button
                  type="submit"
                  className="px-6 py-2.5 bg-blue-600 hover:bg-blue-500 text-white rounded-xl font-bold shrink-0 shadow-lg shadow-blue-900/40"
                >
                  Publish Promo Code
                </button>
              </form>
            </div>

            <div className="rounded-2xl bg-slate-900/80 border border-slate-800 overflow-hidden shadow-xl">
              <table className="w-full text-left text-xs font-mono">
                <thead className="bg-slate-950 text-slate-400 uppercase border-b border-slate-800">
                  <tr>
                    <th className="p-4">Coupon Code</th>
                    <th className="p-4">Discount</th>
                    <th className="p-4">Max Cap INR</th>
                    <th className="p-4">Redemptions</th>
                    <th className="p-4 text-right">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800">
                  {coupons.map((c, idx) => (
                    <tr key={idx} className="hover:bg-slate-800/40">
                      <td className="p-4 font-bold text-cyan-300">{c.code}</td>
                      <td className="p-4 text-emerald-400 font-bold">{c.discountPercentage}% OFF</td>
                      <td className="p-4 text-slate-300">₹{c.maxDiscountINR || 500}</td>
                      <td className="p-4 text-slate-300">{c.usesCount || 0} Users</td>
                      <td className="p-4 text-right">
                        <button
                          onClick={() => deleteCoupon(c.code)}
                          className="p-1.5 bg-slate-800 hover:bg-red-600 text-slate-300 hover:text-white rounded transition-colors"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* ========================================================================= */}
        {/* TAB 7: CLUSTER HEALTH                                                     */}
        {/* ========================================================================= */}
        {activeTab === 'overview' && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="p-6 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-4">
              <h3 className="text-base font-bold text-white">Cluster Health &amp; IRCTC Peering Status</h3>
              <div className="space-y-3 font-mono text-xs">
                <div className="p-3 bg-black/40 rounded-xl border border-slate-800 flex justify-between items-center">
                  <div>
                    <span className="text-white font-bold block">Mumbai CtrlS Node MB1</span>
                    <span className="text-[10px] text-slate-400">BGP Path: NIXI-MB-OPTICAL</span>
                  </div>
                  <span className="text-emerald-400 font-bold">1.2ms (99.99% Up)</span>
                </div>
                <div className="p-3 bg-black/40 rounded-xl border border-slate-800 flex justify-between items-center">
                  <div>
                    <span className="text-white font-bold block">Mumbai Equinix MB2</span>
                    <span className="text-[10px] text-slate-400">BGP Path: TATA-TELECOM-DIRECT</span>
                  </div>
                  <span className="text-emerald-400 font-bold">1.4ms (99.99% Up)</span>
                </div>
                <div className="p-3 bg-black/40 rounded-xl border border-slate-800 flex justify-between items-center">
                  <div>
                    <span className="text-white font-bold block">Delhi NCR Node DL1</span>
                    <span className="text-[10px] text-slate-400">BGP Path: AIRTEL-CORE</span>
                  </div>
                  <span className="text-cyan-400 font-bold">8.4ms (100% Up)</span>
                </div>
              </div>
            </div>

            <div className="p-6 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-4">
              <h3 className="text-base font-bold text-white">Anti-Bot &amp; Captcha Engine Load</h3>
              <div className="space-y-4 text-xs font-mono">
                <div>
                  <div className="flex justify-between text-slate-300 mb-1">
                    <span>AI Captcha Inference Workers</span>
                    <span className="text-cyan-400 font-bold">48/64 Threads Active</span>
                  </div>
                  <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                    <div className="bg-cyan-500 h-full w-[75%]" />
                  </div>
                </div>

                <div>
                  <div className="flex justify-between text-slate-300 mb-1">
                    <span>Clean Residential IP Pool Availability</span>
                    <span className="text-emerald-400 font-bold">142,500 / 150,000 Pristine</span>
                  </div>
                  <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                    <div className="bg-emerald-500 h-full w-[95%]" />
                  </div>
                </div>

                <div>
                  <div className="flex justify-between text-slate-300 mb-1">
                    <span>Razorpay Webhook Dispatch Latency</span>
                    <span className="text-purple-400 font-bold">85 ms</span>
                  </div>
                  <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                    <div className="bg-purple-500 h-full w-[10%]" />
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* ========================================================================= */}
        {/* MODAL 1: ADD / EDIT SUBNET INVENTORY NODE (MongoDB)                       */}
        {/* ========================================================================= */}
        {isAddInvModalOpen && (
          <div className="fixed inset-0 z-50 overflow-y-auto bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
            <div className="relative w-full max-w-2xl bg-[#090e1a] border border-emerald-500/30 rounded-2xl shadow-2xl overflow-hidden my-6">
              <div className="bg-gradient-to-r from-emerald-950/90 to-slate-900 px-6 py-4 border-b border-emerald-500/20 flex items-center justify-between">
                <h3 className="text-base font-bold text-white flex items-center space-x-2">
                  <Database className="w-4 h-4 text-emerald-400" />
                  <span>{editingInvItem ? 'Edit VPS Inventory Node (MongoDB)' : 'Add New VPS Subnet Node to MongoDB'}</span>
                </h3>
                <button
                  onClick={() => setIsAddInvModalOpen(false)}
                  className="p-1 rounded text-slate-400 hover:text-white"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <form onSubmit={handleSaveInvItem} className="p-6 space-y-4 text-xs">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-slate-300 mb-1 font-bold">IP Range / Subnet Pool *</label>
                    <input
                      type="text"
                      required
                      value={invIpRange}
                      onChange={(e) => setInvIpRange(e.target.value)}
                      placeholder="e.g. 103.54.26 or 103.184 DIAMOND PRO AMD"
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-white font-mono"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-300 mb-1 font-bold">Server Label / Friendly Name *</label>
                    <input
                      type="text"
                      required
                      value={invServerLabel}
                      onChange={(e) => setInvServerLabel(e.target.value)}
                      placeholder="e.g. 103.54.26 High-Speed Node"
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-white"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-slate-300 mb-1 font-bold">Available Stock Quantity *</label>
                    <input
                      type="number"
                      required
                      min="0"
                      value={invAvailableStock}
                      onChange={(e) => setInvAvailableStock(Number(e.target.value))}
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-white font-mono font-bold"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-300 mb-1 font-bold">Category</label>
                    <select
                      value={invCategory}
                      onChange={(e) => setInvCategory(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-white"
                    >
                      <option value="High-Speed Subnet">High-Speed Subnet</option>
                      <option value="Gold Server">Gold Server</option>
                      <option value="Diamond Pro AMD">Diamond Pro AMD</option>
                      <option value="Dedicated Pool">Dedicated Pool</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-slate-300 mb-1 font-bold">Datacenter Location</label>
                    <select
                      value={invLocation}
                      onChange={(e) => setInvLocation(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-white"
                    >
                      <option value="Mumbai CtrlS Datacenter">Mumbai CtrlS Datacenter</option>
                      <option value="Mumbai Equinix Datacenter">Mumbai Equinix Datacenter</option>
                      <option value="Delhi-NCR Datacenter">Delhi-NCR Datacenter</option>
                      <option value="Bangalore Datacenter">Bangalore Datacenter</option>
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-slate-300 mb-1 font-bold">Processor (CPU)</label>
                    <input
                      type="text"
                      value={invCpu}
                      onChange={(e) => setInvCpu(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-white font-mono"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-300 mb-1 font-bold">Storage Drive</label>
                    <input
                      type="text"
                      value={invStorage}
                      onChange={(e) => setInvStorage(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-white font-mono"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-300 mb-1 font-bold">Port Bandwidth</label>
                    <input
                      type="text"
                      value={invBandwidth}
                      onChange={(e) => setInvBandwidth(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-white font-mono"
                    />
                  </div>
                </div>

                <div className="flex items-center space-x-2 pt-2">
                  <input
                    type="checkbox"
                    id="invActiveCheck"
                    checked={invIsActive}
                    onChange={(e) => setInvIsActive(e.target.checked)}
                    className="rounded bg-slate-950 border-slate-800 text-emerald-500 focus:ring-0"
                  />
                  <label htmlFor="invActiveCheck" className="text-slate-300 font-bold cursor-pointer">
                    Enable node on live customer marketplace
                  </label>
                </div>

                <div className="flex items-center justify-end space-x-3 pt-4 border-t border-slate-800">
                  <button
                    type="button"
                    onClick={() => setIsAddInvModalOpen(false)}
                    className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl font-bold"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-6 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl font-bold shadow-lg shadow-emerald-950"
                  >
                    {editingInvItem ? 'Save Subnet Changes' : 'Add to MongoDB'}
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        {/* ========================================================================= */}
        {/* MODAL 2: BULK IMPORT INVENTORY                                            */}
        {/* ========================================================================= */}
        {isBulkImportModalOpen && (
          <div className="fixed inset-0 z-50 overflow-y-auto bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
            <div className="relative w-full max-w-2xl bg-[#090e1a] border border-blue-500/30 rounded-2xl shadow-2xl overflow-hidden my-6">
              <div className="bg-gradient-to-r from-blue-950/90 to-slate-900 px-6 py-4 border-b border-blue-500/20 flex items-center justify-between">
                <h3 className="text-base font-bold text-white flex items-center space-x-2">
                  <UploadCloud className="w-4 h-4 text-cyan-400" />
                  <span>Bulk Import Subnet Stock into MongoDB</span>
                </h3>
                <button
                  onClick={() => setIsBulkImportModalOpen(false)}
                  className="p-1 rounded text-slate-400 hover:text-white"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <form onSubmit={handleBulkImportSubmit} className="p-6 space-y-4 text-xs">
                <div>
                  <label className="block text-slate-300 mb-1 font-bold">
                    Paste Multi-Line Subnet Stock Text (supports &quot;103.54.26 - Stock 202&quot; format):
                  </label>
                  <textarea
                    rows={12}
                    required
                    value={bulkImportText}
                    onChange={(e) => setBulkImportText(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-slate-200 font-mono text-xs focus:outline-none focus:border-blue-500 leading-relaxed"
                  />
                  <p className="text-[11px] text-slate-400 mt-1">
                    Accepts formatted lines like <code className="text-cyan-300 font-mono">103.54.26 - Stock 202</code>, CSV, or custom labels. Existing matching subnets will have their stock updated.
                  </p>
                </div>

                <div className="flex items-center justify-end space-x-3 pt-2">
                  <button
                    type="button"
                    onClick={() => setIsBulkImportModalOpen(false)}
                    className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl font-bold"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-6 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-xl font-bold shadow-lg shadow-blue-950 flex items-center space-x-1.5"
                  >
                    <Database className="w-3.5 h-3.5" />
                    <span>Run Bulk Import</span>
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        {/* ========================================================================= */}
        {/* MODAL 3: LINUX VPS PRICING MANAGER                                        */}
        {/* ========================================================================= */}
        {isPricingModalOpen && (
          <div className="fixed inset-0 z-50 overflow-y-auto bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
            <div className="relative w-full max-w-xl bg-[#090e1a] border border-blue-500/30 rounded-2xl shadow-2xl overflow-hidden my-6">
              <div className="bg-gradient-to-r from-blue-950/90 to-slate-900 px-6 py-4 border-b border-blue-500/20 flex items-center justify-between">
                <h3 className="text-base font-bold text-white flex items-center space-x-2">
                  <SlidersHorizontal className="w-4 h-4 text-cyan-400" />
                  <span>Update Linux VPS Pricing Tiers</span>
                </h3>
                <button
                  onClick={() => setIsPricingModalOpen(false)}
                  className="p-1 rounded text-slate-400 hover:text-white"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <form onSubmit={handleSavePricingTiers} className="p-6 space-y-4 text-xs">
                <p className="text-slate-300 text-xs">
                  Adjust monthly pricing for the 4 Linux VPS tiers. These prices apply automatically to all 24 inventory subnets in real time:
                </p>

                <div className="space-y-3">
                  {localPricingTiers.map((tier, idx) => (
                    <div key={tier.ram} className="p-3 bg-slate-950/80 border border-slate-800 rounded-xl flex items-center justify-between gap-4">
                      <div>
                        <span className="font-bold text-white text-sm block font-sans">{tier.ram} RAM Tier</span>
                        <span className="text-[11px] text-slate-400 font-mono">{tier.vCpu} • {tier.nvme}</span>
                      </div>

                      <div className="flex items-center space-x-2">
                        <span className="text-slate-400 font-bold">₹</span>
                        <input
                          type="number"
                          required
                          min="100"
                          value={tier.priceINR}
                          onChange={(e) => {
                            const val = Number(e.target.value);
                            setLocalPricingTiers(prev => prev.map((item, i) => i === idx ? { ...item, priceINR: val } : item));
                          }}
                          className="w-24 px-2 py-1.5 bg-black border border-slate-700 rounded-lg text-white font-mono font-bold text-sm focus:outline-none focus:border-blue-500"
                        />
                        <span className="text-[11px] text-slate-400">/mo</span>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="flex items-center justify-end space-x-3 pt-4 border-t border-slate-800">
                  <button
                    type="button"
                    onClick={() => setIsPricingModalOpen(false)}
                    className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl font-bold"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-6 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-xl font-bold shadow-lg shadow-blue-950"
                  >
                    Save All Pricing Tiers
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        {/* ========================================================================= */}
        {/* MODAL 3.5: ADD / EDIT VPS CATEGORY PLAN (DYNAMIC PRICING & HARDWARE)      */}
        {/* ========================================================================= */}
        {isAddPlanModalOpen && (
          <div className="fixed inset-0 z-50 overflow-y-auto bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
            <div className="relative w-full max-w-2xl bg-[#090e1a] border border-cyan-500/30 rounded-2xl shadow-2xl overflow-hidden my-6">
              <div className="bg-gradient-to-r from-slate-950 via-blue-950/80 to-slate-900 px-6 py-4 border-b border-cyan-500/20 flex items-center justify-between">
                <h3 className="text-base font-bold text-white flex items-center space-x-2">
                  <SlidersHorizontal className="w-4 h-4 text-amber-400" />
                  <span>{editingCategoryPlan ? `Edit ${editingCategoryPlan.categoryName} Plan` : 'Add New Category Plan'}</span>
                </h3>
                <button
                  onClick={() => setIsAddPlanModalOpen(false)}
                  className="p-1 rounded text-slate-400 hover:text-white"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <form onSubmit={handleSaveCategoryPlan} className="p-6 space-y-4 text-xs">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-slate-300 mb-1 font-bold">Target Server Category *</label>
                    <select
                      value={planServerType}
                      onChange={(e) => {
                        const val = e.target.value as ServerTypeKey;
                        setPlanServerType(val);
                        setPlanCategoryName(val === 'gold' ? 'Gold Server' : val === 'diamond' ? 'Diamond Pro AMD' : 'Normal');
                        if (val === 'diamond' && (planRam === '4 GB' || planRam === '8 GB')) {
                          setPlanRam('16 GB');
                        } else if (val === 'gold' && (planRam === '4 GB' || planRam === '32 GB')) {
                          setPlanRam('8 GB');
                        }
                      }}
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-white"
                    >
                      <option value="normal">Normal Server (Linux VPS)</option>
                      <option value="gold">Gold Server (3.0 GHz)</option>
                      <option value="diamond">Diamond Pro AMD (3.1 GHz)</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-slate-300 mb-1 font-bold">RAM Tier Allocation *</label>
                    <select
                      value={planRam}
                      onChange={(e) => setPlanRam(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-white font-mono font-bold"
                    >
                      {planServerType === 'gold' ? (
                        <>
                          <option value="8 GB">8 GB RAM Tier</option>
                          <option value="16 GB">16 GB RAM Tier</option>
                        </>
                      ) : planServerType === 'diamond' ? (
                        <>
                          <option value="16 GB">16 GB RAM Tier</option>
                          <option value="32 GB">32 GB RAM Tier</option>
                        </>
                      ) : (
                        <>
                          <option value="4 GB">4 GB RAM Tier</option>
                          <option value="8 GB">8 GB RAM Tier</option>
                          <option value="16 GB">16 GB RAM Tier</option>
                          <option value="32 GB">32 GB RAM Tier</option>
                        </>
                      )}
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-slate-300 mb-1 font-bold">Monthly Price (INR ₹) *</label>
                    <input
                      type="number"
                      required
                      min="100"
                      value={planPriceINR}
                      onChange={(e) => setPlanPriceINR(Number(e.target.value))}
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-white font-mono font-bold text-sm"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-300 mb-1 font-bold">Monthly Price (USD $) *</label>
                    <input
                      type="number"
                      required
                      min="1"
                      value={planPriceUSD}
                      onChange={(e) => setPlanPriceUSD(Number(e.target.value))}
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-white font-mono"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div>
                    <label className="block text-slate-300 mb-1 font-bold">vCPU Hardware</label>
                    <input
                      type="text"
                      required
                      value={planCpu}
                      onChange={(e) => setPlanCpu(e.target.value)}
                      placeholder="e.g. 4 vCPU AMD EPYC"
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-white font-mono text-xs"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-300 mb-1 font-bold">NVMe Storage</label>
                    <input
                      type="text"
                      required
                      value={planNvme}
                      onChange={(e) => setPlanNvme(e.target.value)}
                      placeholder="e.g. 160 GB NVMe Gen4"
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-white font-mono text-xs"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-300 mb-1 font-bold">Bandwidth</label>
                    <input
                      type="text"
                      required
                      value={planBandwidth}
                      onChange={(e) => setPlanBandwidth(e.target.value)}
                      placeholder="e.g. 10 Gbps Unmetered"
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-white font-mono text-xs"
                    />
                  </div>
                </div>

                <div className="flex flex-wrap items-center gap-6 pt-2">
                  <div className="flex items-center space-x-2">
                    <input
                      type="checkbox"
                      id="planActiveCheck"
                      checked={planIsActive}
                      onChange={(e) => setPlanIsActive(e.target.checked)}
                      className="rounded bg-slate-950 border-slate-800 text-emerald-500 focus:ring-0"
                    />
                    <label htmlFor="planActiveCheck" className="text-slate-300 font-bold cursor-pointer">
                      Plan is Active (Visible on Live Marketplace)
                    </label>
                  </div>

                  <div className="flex items-center space-x-2">
                    <input
                      type="checkbox"
                      id="planPopularCheck"
                      checked={planPopular}
                      onChange={(e) => setPlanPopular(e.target.checked)}
                      className="rounded bg-slate-950 border-slate-800 text-amber-500 focus:ring-0"
                    />
                    <label htmlFor="planPopularCheck" className="text-amber-300 font-bold cursor-pointer">
                      Mark as &quot;Popular Choice&quot; Badge
                    </label>
                  </div>
                </div>

                <div className="flex items-center justify-end space-x-3 pt-4 border-t border-slate-800">
                  <button
                    type="button"
                    onClick={() => setIsAddPlanModalOpen(false)}
                    className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl font-bold"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-6 py-2 bg-gradient-to-r from-blue-600 to-cyan-500 hover:from-blue-500 hover:to-cyan-400 text-white rounded-xl font-bold shadow-lg shadow-blue-950"
                  >
                    {editingCategoryPlan ? 'Update Plan' : 'Add to MongoDB'}
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        {/* ========================================================================= */}
        {/* MODAL 3.6: EDIT SERVER CATEGORY METADATA (BADGES & BRANDING)              */}
        {/* ========================================================================= */}
        {isCategoryMetaModalOpen && editingCategoryMeta && (
          <div className="fixed inset-0 z-50 overflow-y-auto bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
            <div className="relative w-full max-w-xl bg-[#090e1a] border border-amber-500/30 rounded-2xl shadow-2xl overflow-hidden my-6">
              <div className="bg-gradient-to-r from-slate-950 via-amber-950/60 to-slate-900 px-6 py-4 border-b border-amber-500/20 flex items-center justify-between">
                <h3 className="text-base font-bold text-white flex items-center space-x-2">
                  <Crown className="w-4 h-4 text-amber-400" />
                  <span>Edit {editingCategoryMeta.displayName} Metadata</span>
                </h3>
                <button
                  onClick={() => setIsCategoryMetaModalOpen(false)}
                  className="p-1 rounded text-slate-400 hover:text-white"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <form onSubmit={handleSaveCategoryMeta} className="p-6 space-y-4 text-xs">
                <div>
                  <label className="block text-slate-300 mb-1 font-bold">Category Display Title *</label>
                  <input
                    type="text"
                    required
                    value={metaDisplayName}
                    onChange={(e) => setMetaDisplayName(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-white font-bold"
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-slate-300 mb-1 font-bold">Marketing Badge Text *</label>
                    <input
                      type="text"
                      required
                      value={metaBadge}
                      onChange={(e) => setMetaBadge(e.target.value)}
                      placeholder="e.g. GOLD SERVER 3.0GHz"
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-white font-mono font-bold text-amber-300"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-300 mb-1 font-bold">CPU Clock Speed Benchmark</label>
                    <input
                      type="text"
                      value={metaClockSpeed}
                      onChange={(e) => setMetaClockSpeed(e.target.value)}
                      placeholder="e.g. 3.0 GHz"
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-white font-mono"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-slate-300 mb-1 font-bold">Category Description</label>
                  <textarea
                    rows={3}
                    value={metaDescription}
                    onChange={(e) => setMetaDescription(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-white"
                  />
                </div>

                <div>
                  <label className="block text-slate-300 mb-1 font-bold">Theme Style Color</label>
                  <select
                    value={metaPremiumColor}
                    onChange={(e) => setMetaPremiumColor(e.target.value as any)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-white"
                  >
                    <option value="blue">Standard Blue Gradient</option>
                    <option value="gold">Gold Premium Gradient</option>
                    <option value="diamond">Diamond Pro Cyan/Blue Gradient</option>
                  </select>
                </div>

                <div className="flex items-center justify-end space-x-3 pt-4 border-t border-slate-800">
                  <button
                    type="button"
                    onClick={() => setIsCategoryMetaModalOpen(false)}
                    className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl font-bold"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-6 py-2 bg-amber-600 hover:bg-amber-500 text-white rounded-xl font-bold shadow-lg shadow-amber-950"
                  >
                    Save Category Info
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        {/* ========================================================================= */}
        {/* MODAL 4: ADD / EDIT CATALOG PRODUCT                                       */}
        {/* ========================================================================= */}
        {isAddProductModalOpen && (
          <div className="fixed inset-0 z-50 overflow-y-auto bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
            <div className="relative w-full max-w-2xl bg-[#090e1a] border border-blue-500/30 rounded-2xl shadow-2xl overflow-hidden my-6">
              <div className="bg-gradient-to-r from-blue-900/90 to-slate-900 px-6 py-4 border-b border-blue-500/20 flex items-center justify-between">
                <h3 className="text-base font-bold text-white flex items-center space-x-2">
                  <Package className="w-4 h-4 text-cyan-400" />
                  <span>{editingProduct ? 'Edit Catalog Product' : 'Add New Product'}</span>
                </h3>
                <button
                  onClick={() => setIsAddProductModalOpen(false)}
                  className="p-1 rounded text-slate-400 hover:text-white"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <form onSubmit={handleSaveProduct} className="p-6 space-y-4 text-xs">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-slate-300 mb-1 font-bold">Product Name *</label>
                    <input
                      type="text"
                      required
                      value={prodName}
                      onChange={(e) => setProdName(e.target.value)}
                      placeholder="e.g. Tatkal Super Master Ultra"
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-white"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-300 mb-1 font-bold">Category *</label>
                    <select
                      value={prodCategory}
                      onChange={(e) => setProdCategory(e.target.value as any)}
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-white"
                    >
                      <option value="tatkal-software">Tatkal Software</option>
                      <option value="windows-vps">Windows VPS</option>
                      <option value="linux-vps">Linux VPS</option>
                      <option value="residential-ip">Residential Clean IPs</option>
                      <option value="static-ip">Static Dedicated IP</option>
                      <option value="datacenter-proxy">Datacenter Proxies</option>
                      <option value="rdp">RDP Service</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-slate-300 mb-1 font-bold">Tagline / Short Pitch</label>
                  <input
                    type="text"
                    value={prodTagline}
                    onChange={(e) => setProdTagline(e.target.value)}
                    placeholder="e.g. High-speed multi-account booking script with sub-second form fill"
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-white"
                  />
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  <div>
                    <label className="block text-slate-300 mb-1 font-bold">Price (INR) *</label>
                    <input
                      type="number"
                      required
                      value={prodPriceINR}
                      onChange={(e) => setProdPriceINR(Number(e.target.value))}
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-white font-mono"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-300 mb-1 font-bold">Price (USD)</label>
                    <input
                      type="number"
                      value={prodPriceUSD}
                      onChange={(e) => setProdPriceUSD(Number(e.target.value))}
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-white font-mono"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-300 mb-1 font-bold">Stock Quantity *</label>
                    <input
                      type="number"
                      required
                      value={prodStock}
                      onChange={(e) => setProdStock(Number(e.target.value))}
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-white font-mono font-bold"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-300 mb-1 font-bold">Min Stock Alert</label>
                    <input
                      type="number"
                      value={prodMinStockAlert}
                      onChange={(e) => setProdMinStockAlert(Number(e.target.value))}
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-white font-mono"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-slate-300 mb-1 font-bold">Digital Delivery Type *</label>
                    <select
                      value={prodDeliveryType}
                      onChange={(e) => setProdDeliveryType(e.target.value as any)}
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-white"
                    >
                      <option value="software_license">Software License Key + Download .EXE</option>
                      <option value="vps_server">VPS Server (IP + Administrator / Root RDP)</option>
                      <option value="proxy_credentials">SOCKS5 / HTTP Proxy IP:Port:User:Pass</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-slate-300 mb-1 font-bold">Download Package URL</label>
                    <input
                      type="text"
                      value={prodDownloadUrl}
                      onChange={(e) => setProdDownloadUrl(e.target.value)}
                      placeholder="https://downloads.tatkalsupermaster.com/..."
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-white font-mono"
                    />
                  </div>
                </div>

                <div className="flex items-center justify-end space-x-3 pt-4 border-t border-slate-800">
                  <button
                    type="button"
                    onClick={() => setIsAddProductModalOpen(false)}
                    className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl font-bold"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-6 py-2 bg-gradient-to-r from-blue-600 to-cyan-500 hover:from-blue-500 hover:to-cyan-400 text-white rounded-xl font-bold shadow-lg shadow-blue-900/40"
                  >
                    {editingProduct ? 'Save Changes' : 'Create Product'}
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

      </div>
    </div>
  );
};
