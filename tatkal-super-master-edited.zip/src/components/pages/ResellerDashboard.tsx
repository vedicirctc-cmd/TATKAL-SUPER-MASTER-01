import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { 
  Building2, 
  Wallet, 
  Plus, 
  Download, 
  Copy, 
  Key, 
  Server, 
  Zap, 
  CheckCircle2, 
  TrendingUp, 
  Layers, 
  Tag, 
  ShieldCheck,
  CreditCard,
  Smartphone,
  ArrowRight,
  Code,
  FileSpreadsheet,
  RefreshCw,
  Award
} from 'lucide-react';

export const ResellerDashboard: React.FC = () => {
  const { 
    user, 
    products, 
    resellerTransactions = [], 
    resellerWholesaleOrders = [], 
    resellerTx = [],
    resellerOrders = [],
    rechargeResellerWallet, 
    purchaseResellerBulk, 
    formatPrice, 
    currency, 
    addToast,
    setCurrentPage
  } = useApp();

  // Recharge modal / form state
  const [isRechargeModalOpen, setIsRechargeModalOpen] = useState(false);
  const [rechargeAmount, setRechargeAmount] = useState('10000');
  const [rechargeGateway, setRechargeGateway] = useState<'razorpay' | 'phonepe' | 'upi'>('razorpay');
  const [isRecharging, setIsRecharging] = useState(false);

  // Bulk order state
  const [selectedProductId, setSelectedProductId] = useState(products[0]?.id || '');
  const [bulkQuantity, setBulkQuantity] = useState(10);
  const [isProcessingBulk, setIsProcessingBulk] = useState(false);
  const [provisionedBatchKeys, setProvisionedBatchKeys] = useState<string[]>([]);

  const selectedProduct = products.find(p => p.id === selectedProductId) || products[0];
  const resellerTier = user?.resellerTier || 'gold';
  const discountRate = resellerTier === 'platinum' ? 0.40 : resellerTier === 'gold' ? 0.30 : 0.20;

  const unitRetailPrice = selectedProduct?.priceINR || 999;
  const unitWholesalePrice = Math.round(unitRetailPrice * (1 - discountRate));
  const bulkTotalRetail = unitRetailPrice * bulkQuantity;
  const bulkTotalWholesale = unitWholesalePrice * bulkQuantity;
  const bulkSavings = bulkTotalRetail - bulkTotalWholesale;

  const handleRecharge = (e: React.FormEvent) => {
    e.preventDefault();
    const amt = Number(rechargeAmount);
    if (!amt || amt < 500) {
      addToast('error', 'Invalid Amount', 'Minimum wallet recharge for Resellers is ₹500.');
      return;
    }

    setIsRecharging(true);
    setTimeout(() => {
      rechargeResellerWallet(amt, rechargeGateway);
      setIsRecharging(false);
      setIsRechargeModalOpen(false);
    }, 1200);
  };

  const handleExecuteBulkOrder = () => {
    if (!user || user.walletBalance < bulkTotalWholesale) {
      addToast('error', 'Insufficient Wallet Balance', `Your balance is ₹${user?.walletBalance || 0}. You need ₹${bulkTotalWholesale}. Please recharge wallet.`);
      setIsRechargeModalOpen(true);
      return;
    }

    setIsProcessingBulk(true);

    setTimeout(() => {
      const res = purchaseResellerBulk(selectedProduct.id, bulkQuantity);
      setIsProcessingBulk(false);
      if (res.success && res.keys) {
        setProvisionedBatchKeys(res.keys);
      }
    }, 1500);
  };

  const handleCopy = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    addToast('info', 'Copied!', `${label} copied to clipboard.`);
  };

  const handleExportCSV = () => {
    if (!provisionedBatchKeys.length) return;
    const csvContent = "data:text/csv;charset=utf-8,Item Name,Generated License/Credential,Status\n" 
      + provisionedBatchKeys.map((k, i) => `"${selectedProduct.name} #${i+1}","${k}","ACTIVE"`).join("\n");
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `tsm_bulk_keys_${Date.now()}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    addToast('success', 'Exported', 'CSV file downloaded successfully.');
  };

  return (
    <div className="min-h-screen bg-[#050811] text-slate-100 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        
        {/* Reseller Hero Header */}
        <div className="rounded-2xl bg-gradient-to-r from-amber-950/60 via-slate-900 to-blue-950/70 border border-amber-500/40 p-6 sm:p-8 flex flex-col md:flex-row md:items-center justify-between gap-6 shadow-2xl">
          <div className="space-y-2">
            <div className="flex items-center space-x-2">
              <span className="text-xs font-mono bg-amber-500/20 text-amber-300 border border-amber-500/40 px-3 py-0.5 rounded-full font-bold flex items-center space-x-1">
                <Award className="w-3.5 h-3.5 text-amber-400" />
                <span>B2B WHOLESALE RESELLER PORTAL</span>
              </span>
              <span className="text-xs text-slate-400 font-mono">Agency: {user?.resellerAgencyName || 'Super Tatkal Solutions'}</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-black text-white">
              Wholesale Licenses, VPS Nodes & API Allocation
            </h1>
            <p className="text-xs text-slate-400 max-w-2xl">
              Purchase Tatkal software licenses, Windows VPS servers, and residential proxies at wholesale rates (up to 40% OFF). Re-brand and distribute to your own customers.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-4">
            <div className="p-4 rounded-xl bg-slate-900/90 border border-amber-500/30 space-y-1">
              <span className="text-[10px] text-slate-400 font-bold uppercase flex items-center space-x-1">
                <Wallet className="w-3.5 h-3.5 text-amber-400" />
                <span>Reseller Wallet Balance</span>
              </span>
              <div className="text-2xl font-black text-emerald-400 font-mono">
                {formatPrice(user?.walletBalance || 48500, (user?.walletBalance || 48500) / 85)}
              </div>
            </div>

            <button
              onClick={() => setIsRechargeModalOpen(true)}
              className="px-5 py-3 rounded-xl bg-gradient-to-r from-amber-600 to-amber-500 hover:from-amber-500 hover:to-amber-400 text-slate-950 font-black text-xs shadow-lg shadow-amber-900/40 transition-all flex items-center space-x-1.5 active:scale-98"
            >
              <Plus className="w-4 h-4" />
              <span>Instant Wallet Recharge</span>
            </button>
          </div>
        </div>

        {/* Reseller Tier & Wholesale Metrics */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
          <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-2">
            <div className="flex items-center justify-between text-slate-400 text-xs">
              <span>Partner Tier</span>
              <Award className="w-4 h-4 text-amber-400" />
            </div>
            <div className="text-2xl font-black text-white uppercase font-mono text-amber-300">
              {resellerTier} Partner
            </div>
            <div className="text-[11px] text-emerald-400 font-bold">
              {Math.round(discountRate * 100)}% Instant Wholesale Margin
            </div>
          </div>

          <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-2">
            <div className="flex items-center justify-between text-slate-400 text-xs">
              <span>Total Bulk Keys Dispatched</span>
              <Key className="w-4 h-4 text-cyan-400" />
            </div>
            <div className="text-2xl font-black text-white font-mono">
              284 Licenses
            </div>
            <div className="text-[11px] text-slate-400">
              Across 18 Sub-Agents & Portals
            </div>
          </div>

          <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-2">
            <div className="flex items-center justify-between text-slate-400 text-xs">
              <span>Total Wholesale Savings</span>
              <TrendingUp className="w-4 h-4 text-emerald-400" />
            </div>
            <div className="text-2xl font-black text-emerald-400 font-mono">
              ₹84,200 saved
            </div>
            <div className="text-[11px] text-slate-400">
              Compared to Standard Retail MRP
            </div>
          </div>

          <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-2">
            <div className="flex items-center justify-between text-slate-400 text-xs">
              <span>B2B Reseller API Key</span>
              <Code className="w-4 h-4 text-purple-400" />
            </div>
            <div className="text-xs font-mono text-cyan-300 truncate bg-black/40 p-1.5 rounded border border-slate-800">
              {user?.resellerApiKey || 'tsm_live_key_9921827419'}
            </div>
            <button
              onClick={() => handleCopy(user?.resellerApiKey || 'tsm_live_key_9921827419', 'Reseller API Key')}
              className="text-[10px] text-blue-400 hover:underline flex items-center space-x-1"
            >
              <Copy className="w-3 h-3" />
              <span>Copy API Authentication Key</span>
            </button>
          </div>
        </div>

        {/* Wholesale Bulk Order Machine */}
        <div className="p-6 sm:p-8 rounded-2xl bg-slate-900/90 border border-blue-500/30 space-y-6 shadow-2xl">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-800">
            <div>
              <h3 className="text-lg font-black text-white flex items-center space-x-2">
                <Zap className="w-5 h-5 text-amber-400" />
                <span>Instant 1-Click Wholesale Bulk Provisioning</span>
              </h3>
              <p className="text-xs text-slate-400">
                Select your required software package or VPS tier, select bulk quantity, and provision keys instantaneously.
              </p>
            </div>

            <span className="px-3 py-1 bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 rounded-lg text-xs font-mono font-bold">
              Automated Zero-Latency Batch Generator
            </span>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Left selector */}
            <div className="lg:col-span-2 space-y-4 text-xs">
              <div>
                <label className="block text-slate-300 font-bold mb-1.5">Select Product / Digital Service</label>
                <select
                  value={selectedProductId}
                  onChange={(e) => setSelectedProductId(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-white text-xs font-mono focus:outline-none focus:border-blue-500"
                >
                  {products.map((p) => (
                    <option key={p.id} value={p.id}>
                      {p.name} — MRP ₹{p.priceINR} ({p.stockQuantity} in stock)
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-slate-300 font-bold mb-1.5">
                  Select Bulk Quantity: <strong className="text-cyan-400 font-mono text-sm">{bulkQuantity} Units</strong>
                </label>
                <div className="grid grid-cols-5 gap-2">
                  {[5, 10, 25, 50, 100].map((qty) => (
                    <button
                      key={qty}
                      type="button"
                      onClick={() => setBulkQuantity(qty)}
                      className={`py-2.5 rounded-xl border text-xs font-mono font-bold transition-all ${
                        bulkQuantity === qty
                          ? 'bg-blue-600 border-blue-500 text-white shadow-lg shadow-blue-950'
                          : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-white'
                      }`}
                    >
                      {qty} Licenses
                    </button>
                  ))}
                </div>
              </div>

              <div className="p-4 bg-black/40 rounded-xl border border-slate-800 space-y-2 text-xs">
                <span className="font-bold text-slate-300 block uppercase tracking-wider text-[10px]">
                  Batch Provisioning Specs & Guarantee
                </span>
                <ul className="space-y-1 text-slate-400 text-[11px]">
                  <li>✓ All keys generated with unique AES-256 signatures ready for instant binding</li>
                  <li>✓ VPS credentials provisioned on isolated Mumbai / Delhi subnets with 10Gbps uplink</li>
                  <li>✓ Bulk export available immediately in CSV, TXT, and JSON formats</li>
                </ul>
              </div>
            </div>

            {/* Right Cost Calculation & Trigger */}
            <div className="p-5 rounded-2xl bg-slate-950 border border-slate-800 space-y-4 flex flex-col justify-between">
              <div className="space-y-3 text-xs">
                <span className="text-xs font-bold text-white uppercase tracking-wider block border-b border-slate-800 pb-2">
                  Wholesale Cost Calculation
                </span>

                <div className="flex justify-between text-slate-400">
                  <span>Standard MRP ({bulkQuantity}x)</span>
                  <span className="line-through">₹{bulkTotalRetail.toLocaleString('en-IN')}</span>
                </div>

                <div className="flex justify-between text-emerald-400 font-bold">
                  <span>Wholesale Discount ({Math.round(discountRate * 100)}%)</span>
                  <span>- ₹{bulkSavings.toLocaleString('en-IN')}</span>
                </div>

                <div className="flex justify-between text-slate-400">
                  <span>Unit Wholesale Cost</span>
                  <span className="text-white font-mono font-bold">₹{unitWholesalePrice} / unit</span>
                </div>

                <div className="pt-2 border-t border-slate-800 flex justify-between items-center text-sm">
                  <span className="text-white font-bold">Net Wallet Deduction:</span>
                  <span className="text-xl font-black text-cyan-400 font-mono">
                    ₹{bulkTotalWholesale.toLocaleString('en-IN')}
                  </span>
                </div>
              </div>

              <button
                disabled={isProcessingBulk}
                onClick={handleExecuteBulkOrder}
                className={`w-full py-3.5 rounded-xl font-black text-xs text-white shadow-xl flex items-center justify-center space-x-2 transition-all ${
                  isProcessingBulk
                    ? 'bg-blue-800 cursor-wait'
                    : 'bg-gradient-to-r from-blue-600 via-indigo-600 to-cyan-500 hover:from-blue-500 hover:to-cyan-400 shadow-blue-600/30'
                }`}
              >
                {isProcessingBulk ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    <span>Allocating Batch Keys...</span>
                  </>
                ) : (
                  <>
                    <Zap className="w-4 h-4" />
                    <span>Generate & Debit ₹{bulkTotalWholesale.toLocaleString('en-IN')}</span>
                  </>
                )}
              </button>
            </div>
          </div>

          {/* Newly Generated Keys Output Box */}
          {provisionedBatchKeys.length > 0 && (
            <div className="mt-6 p-5 rounded-2xl bg-slate-950 border border-emerald-500/40 space-y-4 animate-in fade-in">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-800">
                <div className="flex items-center space-x-2">
                  <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                  <h4 className="text-sm font-extrabold text-white">
                    Batch Successfully Generated ({provisionedBatchKeys.length} Credentials)
                  </h4>
                </div>

                <div className="flex items-center space-x-2">
                  <button
                    onClick={handleExportCSV}
                    className="px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-bold flex items-center space-x-1.5 shadow-lg shadow-emerald-900/30"
                  >
                    <FileSpreadsheet className="w-3.5 h-3.5" />
                    <span>Download CSV</span>
                  </button>
                  <button
                    onClick={() => handleCopy(provisionedBatchKeys.join('\n'), 'All Batch Keys')}
                    className="px-3.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-white rounded-lg text-xs font-bold flex items-center space-x-1.5"
                  >
                    <Copy className="w-3.5 h-3.5" />
                    <span>Copy All</span>
                  </button>
                </div>
              </div>

              <div className="max-h-48 overflow-y-auto p-3 bg-black/60 rounded-xl border border-slate-800 font-mono text-xs text-cyan-300 space-y-1 select-all">
                {provisionedBatchKeys.map((key, i) => (
                  <div key={i} className="flex justify-between hover:bg-slate-900/50 p-1 rounded">
                    <span>{i + 1}. {key}</span>
                    <span className="text-emerald-400 font-bold">READY</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Reseller Wallet & Wholesale Orders History */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Wallet Ledger */}
          <div className="p-6 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-4">
            <h3 className="text-base font-bold text-white flex items-center space-x-2">
              <Wallet className="w-4 h-4 text-cyan-400" />
              <span>Wallet Recharge & Deduction Ledger</span>
            </h3>

            <div className="rounded-xl border border-slate-800 overflow-hidden">
              <table className="w-full text-left text-xs font-mono">
                <thead className="bg-slate-950 text-slate-400 uppercase border-b border-slate-800">
                  <tr>
                    <th className="p-3">Ref ID</th>
                    <th className="p-3">Type</th>
                    <th className="p-3">Amount</th>
                    <th className="p-3">Method</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800">
                  {(resellerTransactions || resellerTx || []).map((tx) => (
                    <tr key={tx.id} className="hover:bg-slate-800/40">
                      <td className="p-3 text-cyan-300">{tx.id}</td>
                      <td className="p-3">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                          tx.type === 'credit' ? 'bg-emerald-500/20 text-emerald-400' : 'bg-red-500/20 text-red-400'
                        }`}>
                          {tx.type}
                        </span>
                      </td>
                      <td className="p-3 font-bold text-white">
                        {tx.type === 'credit' ? '+' : '-'}₹{(tx.amount || 0).toLocaleString('en-IN')}
                      </td>
                      <td className="p-3 text-slate-400 uppercase">{tx.paymentGateway || tx.type || 'SYSTEM'}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Wholesale Batch Orders */}
          <div className="p-6 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-4">
            <h3 className="text-base font-bold text-white flex items-center space-x-2">
              <Layers className="w-4 h-4 text-amber-400" />
              <span>Recent Bulk Wholesale Dispatches</span>
            </h3>

            <div className="rounded-xl border border-slate-800 overflow-hidden">
              <table className="w-full text-left text-xs font-mono">
                <thead className="bg-slate-950 text-slate-400 uppercase border-b border-slate-800">
                  <tr>
                    <th className="p-3">Batch ID</th>
                    <th className="p-3">Product</th>
                    <th className="p-3">Quantity</th>
                    <th className="p-3">Total Paid</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800">
                  {(resellerWholesaleOrders || resellerOrders || []).map((ord) => (
                    <tr key={ord.id} className="hover:bg-slate-800/40">
                      <td className="p-3 text-amber-300">{ord.id}</td>
                      <td className="p-3 text-white font-sans">{ord.productName}</td>
                      <td className="p-3 text-cyan-300 font-bold">{ord.quantity} Units</td>
                      <td className="p-3 font-bold text-emerald-400">
                        ₹{(ord.totalDeducted || 0).toLocaleString('en-IN')}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        {/* MODAL: WALLET RECHARGE */}
        {isRechargeModalOpen && (
          <div className="fixed inset-0 z-50 overflow-y-auto bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
            <div className="relative w-full max-w-md bg-[#090e1a] border border-amber-500/40 rounded-2xl shadow-2xl overflow-hidden my-6">
              <div className="bg-gradient-to-r from-amber-900/90 to-slate-900 px-6 py-4 border-b border-amber-500/20 flex items-center justify-between">
                <h3 className="text-base font-extrabold text-white flex items-center space-x-2">
                  <Wallet className="w-4 h-4 text-amber-400" />
                  <span>Recharge Reseller Balance</span>
                </h3>
                <button
                  onClick={() => setIsRechargeModalOpen(false)}
                  className="text-slate-400 hover:text-white"
                >
                  ✕
                </button>
              </div>

              <form onSubmit={handleRecharge} className="p-6 space-y-4 text-xs">
                <div>
                  <label className="block text-slate-300 font-bold mb-1.5">Enter Amount (INR)</label>
                  <input
                    type="number"
                    min="500"
                    step="500"
                    required
                    value={rechargeAmount}
                    onChange={(e) => setRechargeAmount(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-white font-mono text-base font-bold focus:outline-none focus:border-amber-500"
                  />
                  <div className="flex gap-2 mt-2">
                    {['5000', '10000', '25000', '50000'].map((quickAmt) => (
                      <button
                        key={quickAmt}
                        type="button"
                        onClick={() => setRechargeAmount(quickAmt)}
                        className="px-2.5 py-1 bg-slate-900 hover:bg-slate-800 text-slate-300 rounded font-mono text-[11px]"
                      >
                        +₹{quickAmt}
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="block text-slate-300 font-bold mb-1.5">Payment Gateway</label>
                  <div className="grid grid-cols-3 gap-2">
                    <button
                      type="button"
                      onClick={() => setRechargeGateway('razorpay')}
                      className={`p-2.5 rounded-xl border text-[11px] font-bold flex flex-col items-center justify-center space-y-1 ${
                        rechargeGateway === 'razorpay'
                          ? 'bg-blue-600/20 border-blue-500 text-white'
                          : 'bg-slate-950 border-slate-800 text-slate-400'
                      }`}
                    >
                      <CreditCard className="w-4 h-4 text-blue-400" />
                      <span>Razorpay</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => setRechargeGateway('phonepe')}
                      className={`p-2.5 rounded-xl border text-[11px] font-bold flex flex-col items-center justify-center space-y-1 ${
                        rechargeGateway === 'phonepe'
                          ? 'bg-purple-600/20 border-purple-500 text-white'
                          : 'bg-slate-950 border-slate-800 text-slate-400'
                      }`}
                    >
                      <Smartphone className="w-4 h-4 text-purple-400" />
                      <span>PhonePe</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => setRechargeGateway('upi')}
                      className={`p-2.5 rounded-xl border text-[11px] font-bold flex flex-col items-center justify-center space-y-1 ${
                        rechargeGateway === 'upi'
                          ? 'bg-emerald-600/20 border-emerald-500 text-white'
                          : 'bg-slate-950 border-slate-800 text-slate-400'
                      }`}
                    >
                      <Zap className="w-4 h-4 text-emerald-400" />
                      <span>Instant UPI</span>
                    </button>
                  </div>
                </div>

                <div className="p-3 bg-emerald-950/30 border border-emerald-500/20 rounded-xl text-[11px] text-emerald-300">
                  ✓ Instant balance credit upon biometric or OTP confirmation. 0% surcharge.
                </div>

                <button
                  type="submit"
                  disabled={isRecharging}
                  className="w-full py-3 bg-gradient-to-r from-amber-600 to-amber-500 hover:from-amber-500 hover:to-amber-400 text-slate-950 font-black rounded-xl text-xs shadow-lg shadow-amber-900/40 flex items-center justify-center space-x-2"
                >
                  {isRecharging ? (
                    <span>Processing Gateway Capture...</span>
                  ) : (
                    <span>Proceed to Pay ₹{Number(rechargeAmount || 0).toLocaleString('en-IN')}</span>
                  )}
                </button>
              </form>
            </div>
          </div>
        )}

      </div>
    </div>
  );
};
