import React, { useState, useMemo } from 'react';
import { useApp } from '../../context/AppContext';
import { 
  Server, 
  Cpu, 
  HardDrive, 
  Activity, 
  Zap, 
  Check, 
  ArrowRight, 
  ShieldCheck, 
  Globe, 
  Sparkles,
  Layers,
  Terminal,
  Monitor,
  Search,
  Filter,
  RefreshCw,
  Database,
  Flame,
  CheckCircle2,
  AlertTriangle,
  XCircle,
  Clock,
  SlidersHorizontal,
  ChevronRight,
  Award,
  Crown
} from 'lucide-react';
import { VpsInventoryItem, VpsCategoryPlan } from '../../types';
import { getServerTypeFromItem } from '../../data/inventoryDb';

export const VpsHostingPage: React.FC = () => {
  const { 
    inventory, 
    categoryPlans,
    serverCategories,
    getPlansForServer,
    getStartingPriceForServer,
    openCheckoutWithInventory, 
    formatPrice, 
    currency, 
    addToast,
    setCurrentPage
  } = useApp();

  // Search, filter, and sort states
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedStockFilter, setSelectedStockFilter] = useState<'all' | 'high' | 'medium' | 'low' | 'instock'>('all');
  const [selectedLocation, setSelectedLocation] = useState<string>('all');
  const [sortBy, setSortBy] = useState<'stock-desc' | 'stock-asc' | 'label' | 'ip' | 'price-asc'>('stock-desc');

  // Selected RAM configuration per card (mapped by serverId or _id)
  const [cardRamSelection, setCardRamSelection] = useState<Record<string, string>>({});

  // Categories list
  const categoryFilters = [
    { id: 'all', label: 'All Server Types' },
    { id: 'Diamond', label: '💎 Diamond Pro AMD (3.1GHz)' },
    { id: 'Gold', label: '⭐ Gold Servers (3.0GHz)' },
    { id: 'Normal', label: '⚡ Normal Linux VPS' }
  ];

  // Aggregate stats
  const totalStock = useMemo(() => {
    return inventory.reduce((acc, item) => acc + (item.isActive ? item.availableStock : 0), 0);
  }, [inventory]);

  const activeNodesCount = useMemo(() => {
    return inventory.filter(i => i.isActive).length;
  }, [inventory]);

  const lowStockCount = useMemo(() => {
    return inventory.filter(i => i.isActive && i.availableStock > 0 && i.availableStock < 20).length;
  }, [inventory]);

  // Filtered and sorted inventory list
  const filteredInventory = useMemo(() => {
    return inventory.filter(item => {
      // Active check
      if (!item.isActive) return false;

      const serverType = getServerTypeFromItem(item);

      // Search term
      if (searchTerm.trim()) {
        const query = searchTerm.toLowerCase();
        const matchIp = item.ipRange.toLowerCase().includes(query);
        const matchLabel = item.serverLabel.toLowerCase().includes(query);
        const matchCat = item.category.toLowerCase().includes(query);
        const matchLoc = (item.location || '').toLowerCase().includes(query);
        if (!matchIp && !matchLabel && !matchCat && !matchLoc) return false;
      }

      // Category filter
      if (selectedCategory !== 'all') {
        if (selectedCategory === 'Diamond' && serverType !== 'diamond') return false;
        if (selectedCategory === 'Gold' && serverType !== 'gold') return false;
        if (selectedCategory === 'Normal' && serverType !== 'normal') return false;
      }

      // Location filter
      if (selectedLocation !== 'all') {
        if (item.location !== selectedLocation) {
          return false;
        }
      }

      // Stock status filter
      if (selectedStockFilter === 'high' && item.availableStock < 100) return false;
      if (selectedStockFilter === 'medium' && (item.availableStock < 20 || item.availableStock >= 100)) return false;
      if (selectedStockFilter === 'low' && (item.availableStock >= 20 || item.availableStock <= 0)) return false;
      if (selectedStockFilter === 'instock' && item.availableStock <= 0) return false;

      return true;
    }).sort((a, b) => {
      if (sortBy === 'stock-desc') return b.availableStock - a.availableStock;
      if (sortBy === 'stock-asc') return a.availableStock - b.availableStock;
      if (sortBy === 'label') return a.serverLabel.localeCompare(b.serverLabel);
      if (sortBy === 'ip') return a.ipRange.localeCompare(b.ipRange);
      if (sortBy === 'price-asc') return getStartingPriceForServer(a) - getStartingPriceForServer(b);
      return 0;
    });
  }, [inventory, searchTerm, selectedCategory, selectedLocation, selectedStockFilter, sortBy, getStartingPriceForServer]);

  // Helper to get stock badge classes
  const getStockBadge = (stock: number) => {
    if (stock <= 0) {
      return {
        label: '0 Out of Stock',
        badgeClass: 'bg-rose-950/80 text-rose-300 border-rose-800/80',
        dotClass: 'bg-rose-500',
        tag: 'Sold Out'
      };
    }
    if (stock >= 100) {
      return {
        label: `${stock} Stock Available`,
        badgeClass: 'bg-emerald-950/70 text-emerald-300 border-emerald-500/40 shadow-sm shadow-emerald-950',
        dotClass: 'bg-emerald-400 animate-pulse',
        tag: 'High Stock'
      };
    }
    if (stock >= 20) {
      return {
        label: `${stock} Stock Available`,
        badgeClass: 'bg-amber-950/70 text-amber-300 border-amber-500/40',
        dotClass: 'bg-amber-400',
        tag: 'Fast Selling'
      };
    }
    return {
      label: `Only ${stock} Left! Low Stock`,
      badgeClass: 'bg-rose-900/80 text-rose-200 border-rose-500/50 animate-pulse shadow-sm shadow-rose-950',
      dotClass: 'bg-rose-400',
      tag: 'Selling Fast'
    };
  };

  const handleCardRamChange = (nodeId: string, ram: string) => {
    setCardRamSelection(prev => ({
      ...prev,
      [nodeId]: ram
    }));
  };

  const handleBuy = (item: VpsInventoryItem) => {
    if (item.availableStock <= 0) {
      addToast('error', 'Sold Out', `${item.ipRange} is currently out of stock. Please select another high-speed subnet.`);
      return;
    }
    
    // Resolve valid plan for this server type
    const availablePlans = getPlansForServer(item);
    const selectedRam = cardRamSelection[item._id || item.serverId] || (availablePlans[0]?.ram || '8 GB');
    openCheckoutWithInventory(item, selectedRam);
  };

  return (
    <div id="vps-marketplace-page" className="min-h-screen bg-[#050811] text-slate-100 py-8 sm:py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
        
        {/* TOP HERO & LIVE DATABASE BANNER */}
        <div className="relative rounded-3xl bg-gradient-to-r from-[#0b162c] via-[#091124] to-[#0d1b38] border border-blue-500/30 p-6 sm:p-10 lg:p-12 overflow-hidden shadow-2xl">
          <div className="absolute top-0 right-0 w-96 h-96 bg-blue-500/10 rounded-full blur-3xl pointer-events-none" />
          <div className="absolute bottom-0 left-0 w-80 h-80 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />

          <div className="relative z-10 space-y-8">
            
            {/* Live DB Telemetry Badges */}
            <div className="flex flex-wrap items-center gap-2 sm:gap-3 text-xs">
              <div className="inline-flex items-center space-x-2 px-3 py-1.5 rounded-full bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 font-mono font-medium">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
                <span>MongoDB: collection(&quot;inventory&quot;) LIVE</span>
              </div>

              <div className="inline-flex items-center space-x-2 px-3 py-1.5 rounded-full bg-blue-500/15 border border-blue-500/30 text-blue-300 font-mono">
                <Database className="w-3.5 h-3.5 text-blue-400" />
                <span>{activeNodesCount} Active IP Subnets</span>
              </div>

              <div className="inline-flex items-center space-x-2 px-3 py-1.5 rounded-full bg-cyan-500/15 border border-cyan-500/30 text-cyan-300 font-mono">
                <Zap className="w-3.5 h-3.5 text-cyan-400" />
                <span>{totalStock.toLocaleString('en-IN')} Total Instances Ready</span>
              </div>

              {lowStockCount > 0 && (
                <div className="inline-flex items-center space-x-1.5 px-3 py-1.5 rounded-full bg-amber-500/15 border border-amber-500/30 text-amber-300 font-mono">
                  <Flame className="w-3.5 h-3.5 text-amber-400" />
                  <span>{lowStockCount} Subnets in High Demand</span>
                </div>
              )}
            </div>

            {/* Headline */}
            <div className="max-w-3xl space-y-3">
              <h1 className="text-3xl sm:text-4xl lg:text-5xl font-black text-white tracking-tight leading-tight">
                Real-Time VPS Inventory &amp; <span className="bg-gradient-to-r from-blue-400 via-cyan-300 to-amber-300 bg-clip-text text-transparent">IP Marketplace</span>
              </h1>
              <p className="text-slate-300 text-sm sm:text-base leading-relaxed">
                Direct datacenter inventory across Normal Linux VPS, Gold Servers (3.0GHz), and Diamond Pro AMD (3.1GHz). Every node is bound to real-time MongoDB stock with instant automated provisioning.
              </p>
            </div>

            {/* 3-TIER PRICING & SPECIFICATION OVERVIEW */}
            <div className="pt-2">
              <div className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-4 flex items-center space-x-2">
                <Sparkles className="w-4 h-4 text-amber-400" />
                <span>VPS Tier Structure &amp; Dynamic Pricing Engine</span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                
                {/* 1. Linux VPS / Normal Servers */}
                <div className="p-5 rounded-2xl bg-slate-900/90 border border-blue-500/40 shadow-lg shadow-blue-950/40 relative flex flex-col justify-between space-y-4">
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-[11px] font-bold tracking-wider uppercase px-2.5 py-0.5 rounded-full bg-blue-500/20 border border-blue-500/30 text-blue-300">
                        ⚡ STANDARD HIGH-SPEED
                      </span>
                      <span className="text-xs text-slate-400 font-mono">3.8GHz Turbo</span>
                    </div>
                    <h3 className="text-lg font-black text-white">Linux VPS (Normal Servers)</h3>
                    <p className="text-xs text-slate-400">
                      Standard low-latency subnets with 10 Gbps unmetered uplink. Available in 4GB, 8GB, 16GB, and 32GB RAM plans.
                    </p>
                  </div>

                  <div className="space-y-2 pt-2 border-t border-slate-800">
                    <div className="text-[11px] font-semibold text-slate-300 uppercase tracking-wider">Available Plans:</div>
                    <div className="grid grid-cols-2 gap-2 text-xs font-mono">
                      <div className="p-2 rounded-lg bg-slate-950 border border-slate-800 flex justify-between items-center">
                        <span className="text-slate-300">4 GB</span>
                        <strong className="text-cyan-300">{formatPrice(700)}</strong>
                      </div>
                      <div className="p-2 rounded-lg bg-slate-950 border border-slate-800 flex justify-between items-center">
                        <span className="text-slate-300">8 GB</span>
                        <strong className="text-cyan-300">{formatPrice(1399)}</strong>
                      </div>
                      <div className="p-2 rounded-lg bg-slate-950 border border-slate-800 flex justify-between items-center">
                        <span className="text-slate-300">16 GB</span>
                        <strong className="text-cyan-300">{formatPrice(1799)}</strong>
                      </div>
                      <div className="p-2 rounded-lg bg-slate-950 border border-slate-800 flex justify-between items-center">
                        <span className="text-slate-300">32 GB</span>
                        <strong className="text-cyan-300">{formatPrice(2500)}</strong>
                      </div>
                    </div>
                  </div>

                  <div className="text-[11px] text-slate-400 font-mono pt-1">
                    Price Starting From: <strong className="text-emerald-400 font-bold">{formatPrice(700)}/mo</strong>
                  </div>
                </div>

                {/* 2. Gold Server */}
                <div className="p-5 rounded-2xl bg-gradient-to-b from-amber-950/40 via-yellow-950/20 to-[#0c0a17] border border-amber-500/60 shadow-xl shadow-amber-950/30 relative flex flex-col justify-between space-y-4">
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-[11px] font-black tracking-wider uppercase px-2.5 py-0.5 rounded-full bg-amber-500/20 border border-amber-500/50 text-amber-300 flex items-center space-x-1">
                        <Award className="w-3 h-3 text-amber-400 mr-1" />
                        <span>GOLD SERVER 3.0GHz</span>
                      </span>
                      <span className="text-xs text-amber-400 font-bold font-mono">Premium Gold</span>
                    </div>
                    <h3 className="text-lg font-black text-white">Gold Servers</h3>
                    <p className="text-xs text-slate-300">
                      Enterprise AMD Ryzen 9 7950X low-jitter nodes with dedicated line routing. Exclusively available in 8GB and 16GB plans.
                    </p>
                  </div>

                  <div className="space-y-2 pt-2 border-t border-amber-500/30">
                    <div className="text-[11px] font-semibold text-amber-300 uppercase tracking-wider">Available Plans (Exclusive):</div>
                    <div className="grid grid-cols-2 gap-2 text-xs font-mono">
                      <div className="p-2 rounded-lg bg-slate-950/90 border border-amber-500/40 flex justify-between items-center">
                        <span className="text-amber-200">8 GB</span>
                        <strong className="text-amber-400">{formatPrice(1500)}</strong>
                      </div>
                      <div className="p-2 rounded-lg bg-slate-950/90 border border-amber-500/40 flex justify-between items-center">
                        <span className="text-amber-200">16 GB</span>
                        <strong className="text-amber-400">{formatPrice(2199)}</strong>
                      </div>
                    </div>
                  </div>

                  <div className="text-[11px] text-amber-300/80 font-mono pt-1">
                    Price Starting From: <strong className="text-amber-300 font-bold">{formatPrice(1500)}/mo</strong>
                  </div>
                </div>

                {/* 3. Diamond Pro AMD Server */}
                <div className="p-5 rounded-2xl bg-gradient-to-b from-cyan-950/40 via-blue-950/20 to-[#070b16] border border-cyan-400/70 shadow-xl shadow-cyan-950/40 relative flex flex-col justify-between space-y-4">
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-[11px] font-black tracking-wider uppercase px-2.5 py-0.5 rounded-full bg-cyan-500/20 border border-cyan-400/50 text-cyan-300 flex items-center space-x-1">
                        <Crown className="w-3 h-3 text-cyan-300 mr-1" />
                        <span>DIAMOND PRO AMD 3.1GHz</span>
                      </span>
                      <span className="text-xs text-cyan-300 font-bold font-mono">Diamond Blue</span>
                    </div>
                    <h3 className="text-lg font-black text-white">Diamond Pro AMD Servers</h3>
                    <p className="text-xs text-slate-300">
                      Flagship dual cluster AMD EPYC 9654 Genoa + Ryzen 9 with zero packet drop SLA. Exclusively available in 16GB and 32GB plans.
                    </p>
                  </div>

                  <div className="space-y-2 pt-2 border-t border-cyan-500/30">
                    <div className="text-[11px] font-semibold text-cyan-300 uppercase tracking-wider">Available Plans (Exclusive):</div>
                    <div className="grid grid-cols-2 gap-2 text-xs font-mono">
                      <div className="p-2 rounded-lg bg-slate-950/90 border border-cyan-400/40 flex justify-between items-center">
                        <span className="text-cyan-200">16 GB</span>
                        <strong className="text-cyan-300">{formatPrice(2799)}</strong>
                      </div>
                      <div className="p-2 rounded-lg bg-slate-950/90 border border-cyan-400/40 flex justify-between items-center">
                        <span className="text-cyan-200">32 GB</span>
                        <strong className="text-cyan-300">{formatPrice(3199)}</strong>
                      </div>
                    </div>
                  </div>

                  <div className="text-[11px] text-cyan-300/80 font-mono pt-1">
                    Price Starting From: <strong className="text-cyan-300 font-bold">{formatPrice(2799)}/mo</strong>
                  </div>
                </div>

              </div>
            </div>

          </div>
        </div>

        {/* SEARCH, FILTER & CONTROLS TOOLBAR */}
        <div className="bg-slate-900/80 border border-slate-800 p-4 sm:p-6 rounded-2xl space-y-4">
          
          <div className="flex flex-col lg:flex-row gap-4 justify-between items-stretch lg:items-center">
            
            {/* Search Input */}
            <div className="relative flex-1">
              <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Search by IP range (e.g. 103.54, 103.82, 103.184) or Server name..."
                className="w-full pl-10 pr-4 py-2.5 bg-slate-950/80 border border-slate-800 rounded-xl text-xs sm:text-sm text-white placeholder-slate-500 focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
              />
              {searchTerm && (
                <button
                  onClick={() => setSearchTerm('')}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-slate-400 hover:text-white"
                >
                  Clear
                </button>
              )}
            </div>

            {/* Category Filter Pills */}
            <div className="flex flex-wrap items-center gap-1.5">
              {categoryFilters.map((cat) => (
                <button
                  key={cat.id}
                  onClick={() => setSelectedCategory(cat.id)}
                  className={`px-3 py-2 rounded-xl text-xs font-bold transition-all ${
                    selectedCategory === cat.id
                      ? 'bg-blue-600 text-white shadow-md shadow-blue-900/30'
                      : 'bg-slate-950 text-slate-400 hover:text-white border border-slate-800'
                  }`}
                >
                  {cat.label}
                </button>
              ))}
            </div>

          </div>

          {/* Secondary Filter Row: Stock, Location, Sorting */}
          <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-slate-800/80 text-xs">
            
            <div className="flex flex-wrap items-center gap-2">
              <span className="text-slate-400 font-medium">Stock Filter:</span>
              <button
                onClick={() => setSelectedStockFilter('all')}
                className={`px-2.5 py-1 rounded-lg ${selectedStockFilter === 'all' ? 'bg-slate-700 text-white' : 'bg-slate-950 text-slate-400 border border-slate-800'}`}
              >
                All ({inventory.length})
              </button>
              <button
                onClick={() => setSelectedStockFilter('high')}
                className={`px-2.5 py-1 rounded-lg ${selectedStockFilter === 'high' ? 'bg-emerald-600 text-white' : 'bg-slate-950 text-emerald-400 border border-slate-800'}`}
              >
                100+ High Stock
              </button>
              <button
                onClick={() => setSelectedStockFilter('medium')}
                className={`px-2.5 py-1 rounded-lg ${selectedStockFilter === 'medium' ? 'bg-amber-600 text-white' : 'bg-slate-950 text-amber-400 border border-slate-800'}`}
              >
                20-99 Medium
              </button>
              <button
                onClick={() => setSelectedStockFilter('low')}
                className={`px-2.5 py-1 rounded-lg ${selectedStockFilter === 'low' ? 'bg-rose-600 text-white' : 'bg-slate-950 text-rose-400 border border-slate-800'}`}
              >
                &lt;20 Low Stock
              </button>
            </div>

            <div className="flex items-center space-x-3">
              <div className="flex items-center space-x-1.5">
                <span className="text-slate-400">Sort by:</span>
                <select
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value as any)}
                  className="bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1 text-xs text-slate-200 focus:outline-none focus:border-blue-500"
                >
                  <option value="stock-desc">Most Stock Available</option>
                  <option value="stock-asc">Lowest Stock First</option>
                  <option value="price-asc">Price (Lowest First)</option>
                  <option value="label">Server Label (A-Z)</option>
                  <option value="ip">IP Range</option>
                </select>
              </div>

              <div className="text-slate-400 text-xs font-mono">
                Showing <strong className="text-white">{filteredInventory.length}</strong> nodes
              </div>
            </div>

          </div>

        </div>

        {/* INVENTORY MARKETPLACE CARDS GRID */}
        {filteredInventory.length === 0 ? (
          <div className="text-center py-16 bg-slate-900/40 rounded-3xl border border-slate-800 space-y-4">
            <Server className="w-12 h-12 text-slate-600 mx-auto" />
            <h3 className="text-lg font-bold text-white">No Server Nodes Found</h3>
            <p className="text-xs text-slate-400 max-w-md mx-auto">
              No active VPS inventory matches your search query or filter selection. Try clearing filters or searching for another IP subnet.
            </p>
            <button
              onClick={() => {
                setSearchTerm('');
                setSelectedCategory('all');
                setSelectedStockFilter('all');
              }}
              className="px-4 py-2 bg-blue-600 text-white rounded-xl text-xs font-bold hover:bg-blue-500"
            >
              Reset All Filters
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredInventory.map((item) => {
              const serverType = getServerTypeFromItem(item);
              const availablePlans = getPlansForServer(item);
              const defaultRam = availablePlans[0]?.ram || '8 GB';
              const currentRam = cardRamSelection[item._id || item.serverId] || defaultRam;
              
              // Find matching plan for current selection
              const selectedPlan = availablePlans.find(p => p.ram.toLowerCase() === currentRam.toLowerCase()) || availablePlans[0];
              const currentPrice = selectedPlan ? selectedPlan.priceINR : 1200;
              const startingPrice = getStartingPriceForServer(item);
              const stockInfo = getStockBadge(item.availableStock);
              const isOutOfStock = item.availableStock <= 0;

              const isDiamond = serverType === 'diamond';
              const isGold = serverType === 'gold';

              return (
                <div
                  key={item._id || item.serverId}
                  id={`vps-node-${item.serverId}`}
                  className={`rounded-2xl flex flex-col justify-between relative transition-all border ${
                    isDiamond 
                      ? 'bg-gradient-to-b from-[#0f1b3d] via-[#091124] to-[#070b16] border-cyan-400/60 shadow-xl shadow-cyan-950/40 ring-1 ring-cyan-500/20' 
                      : isGold 
                      ? 'bg-gradient-to-b from-[#1f170b] via-[#120e1d] to-[#070b16] border-amber-500/60 shadow-xl shadow-amber-950/30 ring-1 ring-amber-500/20' 
                      : 'bg-slate-900/80 border-slate-800 hover:border-slate-700 shadow-md shadow-slate-950'
                  } p-5 sm:p-6 space-y-5`}
                >
                  
                  {/* Top Badges & Server Identification */}
                  <div className="flex items-start justify-between gap-2">
                    <div className="space-y-1">
                      {isDiamond ? (
                        <span className="text-[10px] font-black tracking-wider uppercase px-2.5 py-0.5 rounded-full bg-cyan-500/20 border border-cyan-400/60 text-cyan-300 inline-flex items-center space-x-1">
                          <Crown className="w-3 h-3 text-cyan-300 mr-1" />
                          <span>DIAMOND PRO AMD 3.1GHz</span>
                        </span>
                      ) : isGold ? (
                        <span className="text-[10px] font-black tracking-wider uppercase px-2.5 py-0.5 rounded-full bg-amber-500/20 border border-amber-500/60 text-amber-300 inline-flex items-center space-x-1">
                          <Award className="w-3 h-3 text-amber-400 mr-1" />
                          <span>GOLD SERVER 3.0GHz</span>
                        </span>
                      ) : (
                        <span className="text-[10px] font-bold tracking-wider uppercase px-2.5 py-0.5 rounded-full bg-blue-500/20 border border-blue-500/40 text-blue-300 inline-flex items-center space-x-1">
                          <Zap className="w-3 h-3 text-blue-400 mr-1" />
                          <span>STANDARD HIGH-SPEED</span>
                        </span>
                      )}

                      <h3 className="text-lg font-black text-white leading-tight">
                        {item.serverLabel}
                      </h3>
                      
                      <div className="flex items-center space-x-2 pt-0.5">
                        <span className="font-mono text-xs font-bold text-cyan-400 bg-cyan-500/10 border border-cyan-500/20 px-2 py-0.5 rounded">
                          IP Range: {item.ipRange}
                        </span>
                        <span className="text-[11px] text-slate-400">
                          • {item.location}
                        </span>
                      </div>
                    </div>

                    {/* Stock Status Badge */}
                    <div className={`shrink-0 px-2.5 py-1 rounded-full border text-[11px] font-mono font-bold flex items-center space-x-1.5 ${stockInfo.badgeClass}`}>
                      <span className={`w-2 h-2 rounded-full ${stockInfo.dotClass}`} />
                      <span>{stockInfo.label}</span>
                    </div>
                  </div>

                  {/* Available Stock & Price Starting From Banner */}
                  <div className="bg-slate-950/70 p-3.5 rounded-xl border border-slate-800/80 flex items-center justify-between">
                    <div>
                      <span className="text-[10px] text-slate-400 uppercase font-semibold block">
                        Price Starting From
                      </span>
                      <div className="flex items-baseline space-x-1">
                        <span className={`text-2xl font-black font-mono ${
                          isDiamond ? 'text-cyan-300' : isGold ? 'text-amber-400' : 'text-white'
                        }`}>
                          {formatPrice(startingPrice)}
                        </span>
                        <span className="text-xs text-slate-400">/month</span>
                      </div>
                    </div>

                    <div className="text-right text-[11px] font-mono">
                      <div className="text-emerald-400 font-bold flex items-center justify-end space-x-1">
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
                        <span>0.8ms - 1.2ms IRCTC</span>
                      </div>
                      <div className="text-slate-400">
                        {isDiamond ? '3.1GHz Boost Line' : isGold ? '3.0GHz Direct Line' : '10Gbps Uplink'}
                      </div>
                    </div>
                  </div>

                  {/* Available Plans for this Server Type (Only valid plans shown!) */}
                  <div className="space-y-1.5">
                    <div className="flex items-center justify-between text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
                      <span>Available Plans ({isDiamond ? 'Diamond Only' : isGold ? 'Gold Only' : 'All Tiers'}):</span>
                      <span className="text-cyan-400 font-mono lowercase">{selectedPlan?.vCpu}</span>
                    </div>

                    <div className={`grid ${availablePlans.length === 2 ? 'grid-cols-2' : 'grid-cols-4'} gap-2`}>
                      {availablePlans.map((plan) => {
                        const isSelected = (selectedPlan?.id === plan.id) || (currentRam === plan.ram);
                        return (
                          <button
                            key={plan.id}
                            type="button"
                            onClick={() => handleCardRamChange(item._id || item.serverId, plan.ram)}
                            className={`py-2 px-2 rounded-xl text-center font-mono transition-all ${
                              isSelected
                                ? isDiamond 
                                  ? 'bg-gradient-to-r from-cyan-600 to-blue-600 text-white shadow-md shadow-cyan-900/50 ring-2 ring-cyan-300'
                                  : isGold
                                  ? 'bg-gradient-to-r from-amber-600 to-yellow-600 text-white shadow-md shadow-amber-900/50 ring-2 ring-amber-300'
                                  : 'bg-blue-600 text-white shadow-md shadow-blue-900/50 ring-2 ring-blue-400'
                                : 'bg-slate-950/90 text-slate-300 hover:text-white border border-slate-800 hover:border-slate-700'
                            }`}
                          >
                            <div className="text-xs font-black">{plan.ram}</div>
                            <div className="text-[10px] opacity-90 font-bold">{formatPrice(plan.priceINR).replace('/month', '')}</div>
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {/* Hardware Specs Summary */}
                  <div className="grid grid-cols-2 gap-2 text-xs font-mono text-slate-300 bg-slate-950/50 p-3 rounded-xl border border-slate-800/60">
                    <div className="flex items-center space-x-1.5">
                      <Cpu className="w-3.5 h-3.5 text-blue-400 shrink-0" />
                      <span className="truncate">{selectedPlan?.vCpu || item.cpu}</span>
                    </div>
                    <div className="flex items-center space-x-1.5">
                      <HardDrive className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                      <span className="truncate">{selectedPlan?.nvme || item.storage}</span>
                    </div>
                    <div className="flex items-center space-x-1.5">
                      <Activity className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                      <span className="truncate">{selectedPlan?.bandwidth || item.bandwidth}</span>
                    </div>
                    <div className="flex items-center space-x-1.5">
                      <Globe className="w-3.5 h-3.5 text-indigo-400 shrink-0" />
                      <span className="truncate">{item.location}</span>
                    </div>
                  </div>

                  {/* Selected Plan Details & Buy Now Action */}
                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-xs font-mono px-1">
                      <span className="text-slate-400">Selected: <strong className="text-white">{selectedPlan?.ram || currentRam} RAM</strong></span>
                      <span className="text-white font-bold">{formatPrice(currentPrice)}<span className="text-slate-400 font-normal">/mo</span></span>
                    </div>

                    {isOutOfStock ? (
                      <button
                        disabled
                        className="w-full py-3 px-4 rounded-xl bg-slate-800/80 text-slate-500 font-bold text-xs flex items-center justify-center space-x-2 cursor-not-allowed border border-slate-700/50"
                      >
                        <XCircle className="w-4 h-4" />
                        <span>Out of Stock (Sold Out)</span>
                      </button>
                    ) : (
                      <button
                        onClick={() => handleBuy(item)}
                        className={`w-full py-3 px-4 rounded-xl font-black text-xs flex items-center justify-center space-x-2 transition-all shadow-lg cursor-pointer ${
                          isDiamond
                            ? 'bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white shadow-cyan-950/50 hover:scale-[1.01]'
                            : isGold
                            ? 'bg-gradient-to-r from-amber-500 to-yellow-600 hover:from-amber-400 hover:to-yellow-500 text-black shadow-amber-950/50 hover:scale-[1.01]'
                            : 'bg-blue-600 hover:bg-blue-500 text-white shadow-blue-950/50 hover:scale-[1.01]'
                        }`}
                      >
                        <Zap className="w-4 h-4" />
                        <span>Buy Now • {formatPrice(currentPrice)}</span>
                        <ArrowRight className="w-3.5 h-3.5 ml-1" />
                      </button>
                    )}

                    <div className="flex items-center justify-center space-x-2 text-[10px] text-slate-400">
                      <ShieldCheck className="w-3 h-3 text-emerald-400" />
                      <span>Instant Stock Deduction &amp; Automated Root Provisioning</span>
                    </div>
                  </div>

                </div>
              );
            })}
          </div>
        )}

        {/* ARCHITECTURE & FEATURE HIGHLIGHTS */}
        <div className="bg-gradient-to-b from-slate-900/60 to-[#070b16] border border-slate-800 rounded-3xl p-8 sm:p-12 space-y-8">
          <div className="max-w-2xl space-y-2">
            <div className="inline-flex items-center space-x-2 text-xs font-bold text-blue-400 uppercase tracking-wider">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Enterprise Datacenter Specs</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-white">
              Engineered for Zero Latency &amp; Highest Booking Speed
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-slate-950/60 p-6 rounded-2xl border border-slate-800/80 space-y-3">
              <div className="w-10 h-10 rounded-xl bg-blue-500/10 border border-blue-500/30 flex items-center justify-center text-blue-400">
                <Zap className="w-5 h-5" />
              </div>
              <h3 className="text-base font-bold text-white">Direct Equinix/CtrlS Gateway</h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                Direct peering with NIXI Mumbai and Delhi internet exchanges delivers stable &lt;1.0ms response times during high-traffic 10:00 AM &amp; 11:00 AM booking windows.
              </p>
            </div>

            <div className="bg-slate-950/60 p-6 rounded-2xl border border-slate-800/80 space-y-3">
              <div className="w-10 h-10 rounded-xl bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400">
                <HardDrive className="w-5 h-5" />
              </div>
              <h3 className="text-base font-bold text-white">Gen4 NVMe High-IOPS Arrays</h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                Samsung Enterprise NVMe storage drives deliver up to 7,000 MB/s read speeds, eliminating disk bottlenecks during multi-tab browser automation.
              </p>
            </div>

            <div className="bg-slate-950/60 p-6 rounded-2xl border border-slate-800/80 space-y-3">
              <div className="w-10 h-10 rounded-xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
                <ShieldCheck className="w-5 h-5" />
              </div>
              <h3 className="text-base font-bold text-white">Real-Time Inventory Lock</h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                Every IP subnet is strictly quota-enforced. When you order, stock decreases automatically, preventing noisy neighbors and IP collisions.
              </p>
            </div>
          </div>

          {/* Quick FAQ Strip */}
          <div className="pt-6 border-t border-slate-800/80 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-400">
            <div className="flex items-center space-x-2">
              <Clock className="w-4 h-4 text-cyan-400 shrink-0" />
              <span>Automated provisioning time: <strong>30-45 seconds</strong> after Razorpay/UPI verification.</span>
            </div>
            <div className="flex items-center space-x-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>Full root SSH access &amp; RDP Windows client support included on all plans.</span>
            </div>
          </div>

        </div>

      </div>
    </div>
  );
};
