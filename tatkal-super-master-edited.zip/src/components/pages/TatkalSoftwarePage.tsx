import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { PLANS_DATA } from '../../data/mockData';
import { 
  Zap, 
  ShieldCheck, 
  Cpu, 
  Clock, 
  Check, 
  Play, 
  ArrowRight, 
  Download, 
  Sparkles, 
  Layers, 
  Lock, 
  RefreshCw,
  FileCode,
  CheckCircle2,
  AlertTriangle
} from 'lucide-react';
import { PlanItem } from '../../types';

export const TatkalSoftwarePage: React.FC = () => {
  const { openCheckout, formatPrice, currency, setIsDemoModalOpen } = useApp();
  const [activeTab, setActiveTab] = useState<'overview' | 'features' | 'requirements'>('overview');

  const tatkalPlans = PLANS_DATA.filter(p => p.category === 'tatkal-software');

  const detailedFeatures = [
    {
      title: 'Ultra-Fast Form Autofill (< 0.4s)',
      desc: 'Injects train number, class, quota, station codes, passenger details, berth preferences, and GSTIN automatically in under 400 milliseconds before normal users even see the form.',
      icon: Zap
    },
    {
      title: 'Zero-Latency OCR & AI Captcha Solver',
      desc: 'Built-in neural network resolves complex visual alphanumeric captchas and NLP audio captchas in sub-seconds with a 99.4% first-time success rate.',
      icon: Cpu
    },
    {
      title: 'Dual-Window 10:00 & 11:00 AM Precision Sync',
      desc: 'High-precision microsecond clock synchronization with NTP Indian Railway server time to trigger login exactly at 09:59:59 and seat selection at 10:00:00.',
      icon: Clock
    },
    {
      title: 'Auto Bank OTP Fast-Forwarding',
      desc: 'Seamlessly captures bank payment OTPs directly via integrated Android bridge or webhook, approving payments in 2.5 seconds without manual typing.',
      icon: ShieldCheck
    },
    {
      title: 'Anti-Detection Fingerprinting Engine',
      desc: 'Emulates genuine human mouse movements, randomized typing cadences, and realistic browser fingerprints to bypass Cloudflare and IRCTC bot filters.',
      icon: Lock
    },
    {
      title: 'Multi-Account Master List Synchronization',
      desc: 'Store up to 50 passenger master profiles and automatically distribute them across multiple IRCTC user accounts with 1-click rotation.',
      icon: Layers
    }
  ];

  const handleBuy = (plan: PlanItem) => {
    openCheckout(plan);
  };

  return (
    <div className="min-h-screen bg-[#050811] text-slate-100 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-16">
        
        {/* Page Hero */}
        <div className="relative rounded-3xl bg-gradient-to-r from-blue-950 via-[#0b1328] to-indigo-950 border border-blue-500/30 p-8 sm:p-12 lg:p-16 overflow-hidden shadow-2xl">
          <div className="max-w-3xl space-y-6 relative z-10">
            <div className="inline-flex items-center space-x-2 px-3.5 py-1.5 rounded-full bg-blue-500/10 border border-blue-500/30 text-cyan-300 text-xs font-bold uppercase tracking-wider">
              <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
              <span>TATKAL SUPER MASTER v4.8 PRO</span>
            </div>

            <h1 className="text-3xl sm:text-5xl font-black text-white tracking-tight leading-tight">
              The Most Advanced <span className="bg-gradient-to-r from-blue-400 via-indigo-300 to-cyan-300 bg-clip-text text-transparent">Tatkal Automation Software</span> in India
            </h1>

            <p className="text-slate-300 text-sm sm:text-base leading-relaxed">
              Designed for individual travelers and authorized travel agencies. Achieve consistent confirmed tickets during high-demand AC (10:00 AM) and Non-AC (11:00 AM) booking slots with zero lag and zero bot bans.
            </p>

            <div className="flex flex-wrap gap-4 pt-2">
              <button
                onClick={() => handleBuy(tatkalPlans[1] || tatkalPlans[0])}
                className="px-7 py-3.5 rounded-xl bg-gradient-to-r from-blue-600 to-cyan-500 hover:from-blue-500 hover:to-cyan-400 text-white font-extrabold text-sm shadow-xl shadow-blue-600/30 transition-all flex items-center space-x-2 active:scale-95"
              >
                <Zap className="w-4 h-4 text-cyan-300" />
                <span>Buy TSM PRO (₹999/mo)</span>
              </button>

              <button
                onClick={() => setIsDemoModalOpen(true)}
                className="px-6 py-3.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-200 hover:text-white border border-slate-700 font-bold text-sm transition-all flex items-center space-x-2"
              >
                <Play className="w-4 h-4 fill-cyan-400 text-cyan-400" />
                <span>Request Live Demo</span>
              </button>
            </div>

            <div className="flex flex-wrap items-center gap-4 pt-4 text-xs text-slate-400 font-medium">
              <span className="flex items-center space-x-1">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                <span>Instant License Key Delivery</span>
              </span>
              <span className="flex items-center space-x-1">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                <span>Windows 10/11 & VPS Ready</span>
              </span>
              <span className="flex items-center space-x-1">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                <span>Free Weekly Updates</span>
              </span>
            </div>
          </div>
        </div>

        {/* Feature Grid Deep Dive */}
        <div className="space-y-8">
          <div className="text-center max-w-3xl mx-auto space-y-2">
            <h2 className="text-2xl sm:text-3xl font-extrabold text-white">
              Engineered Capabilities & Highlights
            </h2>
            <p className="text-xs sm:text-sm text-slate-400">
              Every millisecond counts during the 10:00 AM booking rush. Here is how our architecture wins.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {detailedFeatures.map((feat, idx) => {
              const Icon = feat.icon;
              return (
                <div
                  key={idx}
                  className="p-6 rounded-2xl bg-slate-900/60 border border-slate-800 hover:border-blue-500/40 transition-all flex flex-col justify-between space-y-3"
                >
                  <div className="space-y-3">
                    <div className="w-10 h-10 rounded-xl bg-blue-600/20 border border-blue-500/30 flex items-center justify-center text-cyan-400">
                      <Icon className="w-5 h-5" />
                    </div>
                    <h3 className="text-base font-bold text-white">{feat.title}</h3>
                    <p className="text-xs text-slate-400 leading-relaxed">{feat.desc}</p>
                  </div>
                  <div className="pt-3 border-t border-slate-800/80 flex items-center space-x-1.5 text-[11px] text-emerald-400 font-semibold">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>Included in Pro Edition</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Software Pricing Matrix */}
        <div className="space-y-8">
          <div className="text-center max-w-3xl mx-auto space-y-2">
            <h2 className="text-2xl sm:text-3xl font-extrabold text-white">
              Choose Your Tatkal Software Edition
            </h2>
            <p className="text-xs sm:text-sm text-slate-400">
              Select the plan tailored for your personal travel or commercial ticketing agency volume.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {tatkalPlans.map((plan) => (
              <div
                key={plan.id}
                className={`rounded-2xl p-6 sm:p-8 flex flex-col justify-between relative transition-all ${
                  plan.popular
                    ? 'bg-gradient-to-b from-[#0e1a38] to-[#070b16] border-2 border-blue-500 shadow-2xl shadow-blue-950/80 -translate-y-2'
                    : 'bg-slate-900/60 border border-slate-800'
                }`}
              >
                {plan.badge && (
                  <div className="absolute -top-3.5 left-1/2 -translate-x-1/2 bg-blue-600 text-white text-[10px] font-bold uppercase px-3 py-0.5 rounded-full">
                    {plan.badge}
                  </div>
                )}

                <div className="space-y-6">
                  <div>
                    <h3 className="text-xl font-extrabold text-white">{plan.name}</h3>
                    <p className="text-xs text-slate-400 mt-1 min-h-[36px]">{plan.tagline}</p>
                  </div>

                  <div className="pb-4 border-b border-slate-800">
                    <div className="flex items-baseline space-x-1">
                      <span className="text-3xl font-black text-white font-mono">
                        {formatPrice(plan.priceINR, plan.priceUSD)}
                      </span>
                      <span className="text-xs text-slate-400">{plan.period}</span>
                    </div>
                  </div>

                  {/* Specs */}
                  <div className="space-y-2 bg-black/40 p-3.5 rounded-xl border border-slate-800 text-xs">
                    {plan.specs.map((spec, sIdx) => (
                      <div key={sIdx} className="flex justify-between items-center text-slate-300">
                        <span className="text-slate-400">{spec.label}:</span>
                        <span className="font-bold text-white font-mono">{spec.value}</span>
                      </div>
                    ))}
                  </div>

                  {/* Features */}
                  <div className="space-y-2 text-xs">
                    {plan.features.map((feat, fIdx) => (
                      <div key={fIdx} className="flex items-start space-x-2 text-slate-300">
                        <Check className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                        <span>{feat}</span>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="pt-8">
                  <button
                    onClick={() => handleBuy(plan)}
                    className={`w-full py-3.5 rounded-xl text-xs font-extrabold flex items-center justify-center space-x-2 transition-all ${
                      plan.popular
                        ? 'bg-gradient-to-r from-blue-600 to-cyan-500 hover:from-blue-500 hover:to-cyan-400 text-white shadow-lg shadow-blue-900/50'
                        : 'bg-slate-800 hover:bg-slate-700 text-white'
                    }`}
                  >
                    <span>Instant Buy & Activate</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* System Requirements & Setup Guide */}
        <div className="p-8 rounded-2xl bg-slate-900/60 border border-slate-800 grid grid-cols-1 md:grid-cols-2 gap-8">
          <div className="space-y-3 text-xs">
            <h3 className="text-base font-bold text-white flex items-center space-x-2">
              <FileCode className="w-4 h-4 text-blue-400" />
              <span>System & Hardware Requirements</span>
            </h3>
            <ul className="space-y-2 text-slate-300">
              <li>• <strong>Operating System:</strong> Windows 10, Windows 11, or Windows Server 2019/2022 (64-bit).</li>
              <li>• <strong>RAM:</strong> 2 GB Minimum (4 GB+ Recommended for multi-browser tabs).</li>
              <li>• <strong>Network:</strong> Broadband internet with &lt;40ms ping (or use our Mumbai Windows VPS for &lt;1.8ms ping).</li>
              <li>• <strong>Browser:</strong> Google Chrome, Brave, or Microsoft Edge (Latest builds).</li>
            </ul>
          </div>

          <div className="space-y-3 text-xs">
            <h3 className="text-base font-bold text-white flex items-center space-x-2">
              <Sparkles className="w-4 h-4 text-cyan-400" />
              <span>Quick 3-Step Setup Guide</span>
            </h3>
            <ol className="space-y-2 text-slate-300 list-decimal list-inside">
              <li>Complete instant checkout to receive your license key via Telegram & Email.</li>
              <li>Download the single setup executable file (<code className="text-cyan-300 font-mono">TSM_Pro_Setup.exe</code>).</li>
              <li>Enter your license key and pre-fill your passenger master list before 09:55 AM!</li>
            </ol>
          </div>
        </div>

      </div>
    </div>
  );
};
