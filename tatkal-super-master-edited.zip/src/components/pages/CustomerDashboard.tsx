import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { 
  Server, 
  Key, 
  Terminal, 
  RefreshCw, 
  Play, 
  Square, 
  Copy, 
  Download, 
  FileText, 
  Plus, 
  ShieldCheck, 
  Activity, 
  Clock, 
  Layers,
  ArrowUpRight,
  ExternalLink,
  Globe,
  Wallet,
  Zap,
  CheckCircle2,
  Calendar,
  AlertCircle
} from 'lucide-react';
import { ActiveService } from '../../types';

export const CustomerDashboard: React.FC = () => {
  const { 
    user, 
    activeServices, 
    orders, 
    rebootService, 
    setSelectedServiceForConsole, 
    setSelectedOrderForInvoice, 
    addToast,
    setCurrentPage,
    formatPrice
  } = useApp();

  const [activeTab, setActiveTab] = useState<'services' | 'licenses' | 'orders' | 'settings'>('services');
  const [whitelistIp, setWhitelistIp] = useState('110.224.89.14');

  const copyToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    addToast('success', 'Copied', `${label} copied to clipboard.`);
  };

  const handleAddWhitelist = (e: React.FormEvent) => {
    e.preventDefault();
    addToast('success', 'IP Whitelisted', `${whitelistIp} successfully whitelisted on all active proxies and VPS nodes.`);
  };

  // Helper to calculate days until expiry
  const getDaysLeft = (expiryDateStr: string) => {
    try {
      const exp = new Date(expiryDateStr);
      const now = new Date();
      const diffTime = exp.getTime() - now.getTime();
      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
      return diffDays > 0 ? diffDays : 0;
    } catch {
      return 28;
    }
  };

  return (
    <div id="customer-dashboard-page" className="min-h-screen bg-[#050811] text-slate-100 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        
        {/* User Welcome Top Banner */}
        <div className="rounded-3xl bg-gradient-to-r from-blue-950 via-[#0a1327] to-indigo-950 border border-blue-500/30 p-6 sm:p-8 flex flex-col md:flex-row md:items-center justify-between gap-6 shadow-2xl">
          <div className="space-y-2">
            <div className="flex items-center space-x-2">
              <span className="text-xs font-mono bg-blue-500/20 text-cyan-300 border border-blue-500/30 px-2.5 py-0.5 rounded-full font-bold">
                CLIENT PORTAL
              </span>
              <span className="text-xs text-slate-400 font-mono">User ID: {user?.id || 'usr-901'}</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-black text-white">
              Welcome back, {user?.name || 'Customer'}
            </h1>
            <p className="text-xs text-slate-300 max-w-xl leading-relaxed">
              Manage your active VPS cloud instances, subnet IPs, root credentials, software licenses, and automated invoices.
            </p>
          </div>

          {/* Wallet Balance & Quick Deploy */}
          <div className="flex flex-wrap items-center gap-3">
            <div className="p-3.5 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-0.5">
              <span className="text-[10px] text-slate-400 font-bold uppercase flex items-center space-x-1">
                <Wallet className="w-3 h-3 text-cyan-400" />
                <span>Wallet Balance</span>
              </span>
              <div className="text-xl font-black text-emerald-400 font-mono">
                {formatPrice(user?.walletBalance || 1250, (user?.walletBalance || 1250) / 80)}
              </div>
            </div>

            <button
              onClick={() => {
                setCurrentPage('vps-hosting');
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              className="px-5 py-3.5 rounded-2xl bg-gradient-to-r from-blue-600 to-cyan-500 hover:from-blue-500 hover:to-cyan-400 text-white text-xs font-black shadow-lg shadow-blue-900/50 transition-all flex items-center space-x-2 active:scale-98"
            >
              <Plus className="w-4 h-4" />
              <span>Deploy New VPS Node</span>
            </button>
          </div>
        </div>

        {/* Dashboard Navigation Tabs */}
        <div className="flex flex-wrap items-center gap-2 border-b border-slate-800 pb-3">
          <button
            onClick={() => setActiveTab('services')}
            className={`px-4 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center space-x-2 ${
              activeTab === 'services'
                ? 'bg-blue-600 text-white shadow-md shadow-blue-950'
                : 'bg-slate-900/80 text-slate-400 hover:text-white border border-slate-800'
            }`}
          >
            <Server className="w-3.5 h-3.5" />
            <span>My VPS &amp; Active Services ({activeServices.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('licenses')}
            className={`px-4 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center space-x-2 ${
              activeTab === 'licenses'
                ? 'bg-blue-600 text-white shadow-md shadow-blue-950'
                : 'bg-slate-900/80 text-slate-400 hover:text-white border border-slate-800'
            }`}
          >
            <Key className="w-3.5 h-3.5" />
            <span>Software Licenses</span>
          </button>

          <button
            onClick={() => setActiveTab('orders')}
            className={`px-4 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center space-x-2 ${
              activeTab === 'orders'
                ? 'bg-blue-600 text-white shadow-md shadow-blue-950'
                : 'bg-slate-900/80 text-slate-400 hover:text-white border border-slate-800'
            }`}
          >
            <FileText className="w-3.5 h-3.5" />
            <span>Order History &amp; Invoices ({orders.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('settings')}
            className={`px-4 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center space-x-2 ${
              activeTab === 'settings'
                ? 'bg-blue-600 text-white shadow-md shadow-blue-950'
                : 'bg-slate-900/80 text-slate-400 hover:text-white border border-slate-800'
            }`}
          >
            <Globe className="w-3.5 h-3.5" />
            <span>Proxy IP Whitelist</span>
          </button>
        </div>

        {/* ========================================================================= */}
        {/* TAB 1: MY VPS & ACTIVE SERVICES                                           */}
        {/* ========================================================================= */}
        {activeTab === 'services' && (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-base font-bold text-white">Your Provisioned VPS &amp; Dedicated Instances</h2>
                <p className="text-xs text-slate-400">Low-latency Mumbai datacenter nodes with direct RDP/SSH management.</p>
              </div>
              <button
                onClick={() => {
                  setCurrentPage('vps-hosting');
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }}
                className="text-xs font-bold text-cyan-400 hover:underline flex items-center space-x-1"
              >
                <span>Browse VPS Inventory Marketplace</span>
                <ArrowUpRight className="w-3.5 h-3.5" />
              </button>
            </div>

            {activeServices.length === 0 ? (
              <div className="p-12 text-center bg-slate-900/40 border border-slate-800 rounded-3xl space-y-4">
                <Server className="w-12 h-12 text-slate-600 mx-auto" />
                <h3 className="text-base font-bold text-white">No Active VPS Services Yet</h3>
                <p className="text-xs text-slate-400 max-w-sm mx-auto">
                  Deploy your first ultra low-latency VPS instance with instant delivery in 45 seconds.
                </p>
                <button
                  onClick={() => {
                    setCurrentPage('vps-hosting');
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                  className="px-5 py-2.5 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-bold shadow-lg"
                >
                  Deploy VPS Instance
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-1 gap-5">
                {activeServices.map((svc) => {
                  const daysLeft = getDaysLeft(svc.expiryDate);

                  return (
                    <div
                      key={svc.id}
                      className="rounded-3xl bg-slate-900/80 border border-slate-800 hover:border-blue-500/40 p-6 sm:p-8 space-y-6 transition-all shadow-xl"
                    >
                      
                      {/* Service Header */}
                      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
                        <div className="space-y-1.5">
                          <div className="flex flex-wrap items-center gap-2">
                            <span className="text-lg font-extrabold text-white">{svc.serviceName}</span>
                            <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-mono font-bold uppercase ${
                              svc.status === 'active'
                                ? 'bg-emerald-500/15 border border-emerald-500/30 text-emerald-400'
                                : 'bg-amber-500/15 border border-amber-500/30 text-amber-400'
                            }`}>
                              ● {svc.status}
                            </span>
                            <span className="text-xs text-slate-400 font-mono">
                              📍 {svc.location}
                            </span>
                          </div>

                          <p className="text-xs text-slate-300 font-mono">
                            Subnet IP: <strong className="text-cyan-400">{svc.ipAddress || '103.54.26.14'}</strong> • Port: <strong className="text-slate-200">{svc.port || 3389}</strong>
                          </p>
                        </div>

                        {/* Renewal Reminder & Action Buttons */}
                        <div className="flex flex-wrap items-center gap-2.5">
                          
                          {/* Renewal Status Badge */}
                          <div className="px-3 py-1.5 rounded-xl bg-slate-950 border border-slate-800 text-xs font-mono flex items-center space-x-1.5">
                            <Calendar className="w-3.5 h-3.5 text-cyan-400" />
                            <span className="text-slate-400">Renews in:</span>
                            <span className={`font-bold ${daysLeft <= 5 ? 'text-rose-400 animate-pulse' : 'text-emerald-400'}`}>
                              {daysLeft} days ({svc.expiryDate})
                            </span>
                          </div>

                          <button
                            onClick={() => setSelectedServiceForConsole(svc)}
                            className="px-3.5 py-2 bg-blue-600/20 hover:bg-blue-600/30 text-blue-300 border border-blue-500/30 rounded-xl text-xs font-bold flex items-center space-x-1.5 transition-all"
                          >
                            <Terminal className="w-3.5 h-3.5" />
                            <span>Web Console</span>
                          </button>

                          <button
                            onClick={() => rebootService(svc.id)}
                            className="px-3.5 py-2 bg-amber-600/20 hover:bg-amber-600/30 text-amber-300 border border-amber-500/30 rounded-xl text-xs font-bold flex items-center space-x-1.5 transition-all"
                          >
                            <RefreshCw className="w-3.5 h-3.5" />
                            <span>Reboot Node</span>
                          </button>
                        </div>
                      </div>

                      {/* Resource Gauges & RDP Credentials Access */}
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-4 border-t border-slate-800 text-xs font-mono">
                        
                        {/* Resource Load */}
                        <div className="p-3.5 bg-black/40 rounded-2xl border border-slate-800 space-y-1.5">
                          <span className="text-slate-400 text-[10px] uppercase block font-sans font-bold">Hardware Resource Usage</span>
                          <div className="text-sm font-bold text-white">
                            {svc.usageStats ? `${svc.usageStats.cpuUsage}% CPU • ${svc.usageStats.ramUsage}% RAM` : '4 vCPU EPYC • 8 GB RAM'}
                          </div>
                          <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
                            <div className="bg-blue-500 h-full w-[28%]" />
                          </div>
                        </div>

                        {/* Gateway Ping */}
                        <div className="p-3.5 bg-black/40 rounded-2xl border border-slate-800 space-y-1">
                          <span className="text-slate-400 text-[10px] uppercase block font-sans font-bold">IRCTC Gateway Telemetry</span>
                          <div className="text-sm font-bold text-emerald-400">1.2ms to Gateway</div>
                          <div className="text-[10px] text-slate-400">Equinix/CtrlS Direct Optical Fiber</div>
                        </div>

                        {/* Host & Login Credentials */}
                        <div className="p-3.5 bg-black/40 rounded-2xl border border-slate-800 space-y-1">
                          <span className="text-slate-400 text-[10px] uppercase block font-sans font-bold">Login Credentials</span>
                          <div className="flex items-center justify-between">
                            <span className="text-cyan-300 font-bold font-mono truncate">{svc.ipAddress || '103.54.26.14'}:{svc.port || 3389}</span>
                            <button
                              onClick={() => copyToClipboard(`${svc.ipAddress || '103.54.26.14'}:${svc.port || 3389}`, 'RDP Host')}
                              className="p-1 text-slate-400 hover:text-white"
                              title="Copy Host"
                            >
                              <Copy className="w-3.5 h-3.5" />
                            </button>
                          </div>
                          <div className="flex items-center justify-between text-[11px] text-slate-400">
                            <span>User: <strong className="text-white">{svc.username || 'root'}</strong></span>
                            <span>Pass: <strong className="text-emerald-400">{svc.password || 'Tsk#9921'}</strong></span>
                          </div>
                        </div>

                      </div>

                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}

        {/* ========================================================================= */}
        {/* TAB 2: SOFTWARE LICENSES                                                  */}
        {/* ========================================================================= */}
        {activeTab === 'licenses' && (
          <div className="space-y-4">
            <h2 className="text-base font-bold text-white">Active Tatkal Software Licenses</h2>
            <div className="rounded-2xl bg-slate-900/80 border border-slate-800 p-6 space-y-4">
              <div className="space-y-3 text-xs font-mono">
                {orders.filter(o => o.provisionedCredentials?.licenseKey).length === 0 ? (
                  <p className="text-slate-400 text-xs py-4 text-center">No software licenses purchased yet.</p>
                ) : (
                  orders.filter(o => o.provisionedCredentials?.licenseKey).map((ord) => (
                    <div key={ord.id} className="p-4 bg-black/50 rounded-xl border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                      <div className="space-y-1">
                        <span className="text-white font-bold text-sm block font-sans">{ord.items[0]?.planName || 'Tatkal Pro License'}</span>
                        <p className="text-slate-400">Order Ref: {ord.orderNumber} • Issued on: {ord.date}</p>
                        <div className="flex items-center space-x-2 pt-1">
                          <span className="text-emerald-400 font-bold bg-emerald-500/10 border border-emerald-500/20 px-2 py-0.5 rounded">
                            {ord.provisionedCredentials?.licenseKey}
                          </span>
                          <button
                            onClick={() => copyToClipboard(ord.provisionedCredentials?.licenseKey || '', 'License Key')}
                            className="p-1 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded"
                          >
                            <Copy className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>

                      <div className="flex items-center space-x-2">
                        <button
                          onClick={() => {
                            addToast('success', 'Download Initiated', 'Downloading TSM_Pro_v4.8_Setup.exe (32.4 MB)...');
                          }}
                          className="px-4 py-2 bg-gradient-to-r from-blue-600 to-cyan-500 hover:from-blue-500 hover:to-cyan-400 text-white rounded-xl text-xs font-bold flex items-center space-x-1.5 shadow-md"
                        >
                          <Download className="w-3.5 h-3.5" />
                          <span>Download Setup .EXE</span>
                        </button>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>
        )}

        {/* ========================================================================= */}
        {/* TAB 3: ORDER HISTORY & INVOICES                                           */}
        {/* ========================================================================= */}
        {activeTab === 'orders' && (
          <div className="space-y-4">
            <h2 className="text-base font-bold text-white">Billing History &amp; GST Tax Invoices</h2>
            <div className="rounded-2xl bg-slate-900/80 border border-slate-800 overflow-hidden shadow-xl">
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-950 text-slate-400 uppercase font-mono border-b border-slate-800">
                    <tr>
                      <th className="p-4">Order ID</th>
                      <th className="p-4">Service Plan</th>
                      <th className="p-4">Date</th>
                      <th className="p-4">Amount</th>
                      <th className="p-4">Payment Method</th>
                      <th className="p-4">Status</th>
                      <th className="p-4 text-right">Invoice</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800 font-mono">
                    {orders.map((ord) => (
                      <tr key={ord.id} className="hover:bg-slate-800/40 transition-colors">
                        <td className="p-4 font-bold text-white">{ord.orderNumber}</td>
                        <td className="p-4 text-cyan-300">{ord.items[0]?.planName}</td>
                        <td className="p-4 text-slate-400">{ord.date}</td>
                        <td className="p-4 text-white font-bold">{formatPrice(ord.total, ord.total / 80)}</td>
                        <td className="p-4 text-slate-400 uppercase">{ord.paymentMethod}</td>
                        <td className="p-4">
                          <span className="px-2 py-0.5 rounded text-[10px] bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 font-bold uppercase">
                            {ord.fulfillmentStatus}
                          </span>
                        </td>
                        <td className="p-4 text-right">
                          <button
                            onClick={() => setSelectedOrderForInvoice(ord)}
                            className="px-3 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white rounded-lg text-[11px] border border-slate-700 inline-flex items-center space-x-1"
                          >
                            <FileText className="w-3 h-3 text-blue-400" />
                            <span>PDF</span>
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* ========================================================================= */}
        {/* TAB 4: IP WHITELISTING & API                                              */}
        {/* ========================================================================= */}
        {activeTab === 'settings' && (
          <div className="space-y-6">
            <div className="rounded-2xl bg-slate-900/80 border border-slate-800 p-6 sm:p-8 space-y-6">
              <div className="space-y-1">
                <h2 className="text-base font-bold text-white">Residential Proxy IP Whitelist Manager</h2>
                <p className="text-xs text-slate-400">
                  Whitelist your current home/office IP address to authorize SOCKS5 and HTTP proxy connections without user/password authentication.
                </p>
              </div>

              <form onSubmit={handleAddWhitelist} className="flex flex-col sm:flex-row gap-3">
                <input
                  type="text"
                  value={whitelistIp}
                  onChange={(e) => setWhitelistIp(e.target.value)}
                  placeholder="Enter IP (e.g. 110.224.89.14)"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-2.5 text-xs text-white font-mono focus:outline-none focus:border-blue-500"
                />
                <button
                  type="submit"
                  className="px-6 py-2.5 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-bold shrink-0 shadow-lg shadow-blue-900/40"
                >
                  Save Whitelist IP
                </button>
              </form>
            </div>
          </div>
        )}

      </div>
    </div>
  );
};
