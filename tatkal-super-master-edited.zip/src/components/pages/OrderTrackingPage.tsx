import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { 
  Search, 
  Package, 
  CheckCircle2, 
  Clock, 
  FileText, 
  Server, 
  Copy, 
  ExternalLink, 
  Terminal,
  ShieldCheck,
  AlertCircle
} from 'lucide-react';
import { Order } from '../../types';

export const OrderTrackingPage: React.FC = () => {
  const { 
    orders, 
    setSelectedOrderForInvoice, 
    setSelectedServiceForConsole, 
    activeServices, 
    addToast,
    trackOrderNumber,
    setTrackOrderNumber,
    formatPrice
  } = useApp();

  const [searchQuery, setSearchQuery] = useState(trackOrderNumber || (orders[0]?.orderNumber || 'TSM-2026-88219'));
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(orders[0] || null);
  const [hasSearched, setHasSearched] = useState(true);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    setHasSearched(true);
    const query = searchQuery.trim().toLowerCase();
    const found = orders.find(o => 
      o.id.toLowerCase() === query || 
      o.orderNumber.toLowerCase() === query ||
      o.customerEmail.toLowerCase() === query ||
      o.customerPhone?.toLowerCase() === query
    );
    setSelectedOrder(found || null);
  };

  const copyToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    addToast('success', 'Copied to Clipboard', `${label} successfully copied.`);
  };

  const handleOpenConsole = (ip: string, name: string) => {
    const srv = activeServices.find(s => s.ipAddress === ip) || activeServices[0];
    setSelectedServiceForConsole(srv);
  };

  return (
    <div className="min-h-screen bg-[#050811] text-slate-100 py-12">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 space-y-10">
        
        {/* Header */}
        <div className="text-center space-y-3">
          <div className="inline-flex items-center space-x-2 px-3.5 py-1.5 rounded-full bg-blue-500/10 border border-blue-500/30 text-cyan-300 text-xs font-bold uppercase tracking-wider">
            <Package className="w-3.5 h-3.5 text-cyan-400" />
            <span>Instant Fulfillment Tracking</span>
          </div>

          <h1 className="text-3xl sm:text-4xl font-black text-white tracking-tight">
            Track Order & Retrieve Credentials
          </h1>

          <p className="text-slate-400 text-xs sm:text-sm max-w-xl mx-auto">
            Enter your Order ID (e.g., <code className="text-cyan-300 font-mono">TSM-2026-88219</code>) or your registered Email address to inspect active service credentials.
          </p>
        </div>

        {/* Search Bar */}
        <form onSubmit={handleSearch} className="flex gap-2">
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-500 absolute left-3.5 top-3.5" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search Order ID (e.g. TSM-2026-88219) or Email..."
              className="w-full bg-slate-900 border border-slate-800 rounded-xl pl-10 pr-4 py-3 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-blue-500 font-mono"
            />
          </div>
          <button
            type="submit"
            className="px-6 py-3 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-bold shrink-0 transition-all shadow-lg shadow-blue-900/40"
          >
            Track Order
          </button>
        </form>

        {/* Search Results Display */}
        {hasSearched && (
          <div>
            {!selectedOrder ? (
              <div className="p-8 text-center bg-slate-900/60 rounded-2xl border border-slate-800 text-xs text-slate-400 space-y-3">
                <AlertCircle className="w-8 h-8 text-amber-400 mx-auto" />
                <p className="text-slate-200 font-bold text-sm">No Order Found Matching "{searchQuery}"</p>
                <p>Please double check your Order ID from your confirmation email or Telegram notification.</p>
                {orders[0] && (
                  <div className="pt-2">
                    <span className="text-[11px] text-slate-500">Sample test order: </span>
                    <button 
                      type="button"
                      onClick={() => {
                        setSearchQuery(orders[0].orderNumber);
                        setSelectedOrder(orders[0]);
                      }}
                      className="text-blue-400 font-mono hover:underline text-xs ml-1"
                    >
                      {orders[0].orderNumber}
                    </button>
                  </div>
                )}
              </div>
            ) : (
              <div className="rounded-2xl bg-slate-900/80 border border-blue-500/30 p-6 sm:p-8 space-y-8 shadow-2xl">
                
                {/* Order Top Summary */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-slate-800">
                  <div className="space-y-1">
                    <div className="flex items-center space-x-2">
                      <h2 className="text-lg font-black text-white font-mono">{selectedOrder.orderNumber}</h2>
                      <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase bg-emerald-500/15 border border-emerald-500/30 text-emerald-400">
                        {selectedOrder.fulfillmentStatus}
                      </span>
                    </div>
                    <p className="text-xs text-slate-400">
                      Ordered on {selectedOrder.date} by {selectedOrder.customerName} ({selectedOrder.customerEmail})
                    </p>
                  </div>

                  <div className="flex items-center space-x-2">
                    <button
                      onClick={() => setSelectedOrderForInvoice(selectedOrder)}
                      className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white rounded-xl text-xs font-bold border border-slate-700 flex items-center space-x-1.5 transition-all"
                    >
                      <FileText className="w-3.5 h-3.5 text-blue-400" />
                      <span>View Tax Invoice</span>
                    </button>
                  </div>
                </div>

                {/* Provisioning Timeline */}
                <div className="space-y-3">
                  <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider">Automated Provisioning Timeline</h3>
                  <div className="grid grid-cols-1 sm:grid-cols-4 gap-3 text-xs">
                    {selectedOrder.trackingTimeline.map((step, sIdx) => (
                      <div key={sIdx} className="p-3 bg-slate-950 border border-emerald-500/40 rounded-xl space-y-1">
                        <div className="flex items-center space-x-1.5 text-emerald-400 font-bold text-[11px]">
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          <span>{sIdx + 1}. {step.step}</span>
                        </div>
                        <p className="text-[10px] text-slate-400 font-mono">{step.description}</p>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Credentials / Delivery Box */}
                <div className="p-5 bg-black/60 rounded-xl border border-blue-500/30 space-y-4">
                  <div className="flex items-center justify-between">
                    <h3 className="text-xs font-bold text-white uppercase tracking-wider flex items-center space-x-2">
                      <ShieldCheck className="w-4 h-4 text-cyan-400" />
                      <span>Allocated Credentials & Access Keys</span>
                    </h3>
                    <span className="text-[10px] text-emerald-400 font-mono">Auto-Synced</span>
                  </div>

                  <div className="space-y-3 text-xs font-mono">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between p-3 bg-slate-900 rounded-lg border border-slate-800 gap-2">
                      <div>
                        <span className="text-slate-400 text-[10px] block uppercase">Product / Service</span>
                        <span className="text-white font-bold">{selectedOrder.items[0]?.planName || 'Tatkal Super Master Plan'}</span>
                      </div>
                      <span className="text-cyan-400 font-bold text-[11px]">{selectedOrder.items[0]?.category}</span>
                    </div>

                    {selectedOrder.provisionedCredentials?.licenseKey && (
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between p-3 bg-slate-900 rounded-lg border border-slate-800 gap-2">
                        <div>
                          <span className="text-slate-400 text-[10px] block uppercase">Software License Key</span>
                          <span className="text-emerald-400 font-bold">{selectedOrder.provisionedCredentials.licenseKey}</span>
                        </div>
                        <button
                          onClick={() => copyToClipboard(selectedOrder.provisionedCredentials?.licenseKey || '', 'License Key')}
                          className="px-3 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded text-[11px] flex items-center space-x-1 self-start sm:self-auto"
                        >
                          <Copy className="w-3 h-3" />
                          <span>Copy Key</span>
                        </button>
                      </div>
                    )}

                    {selectedOrder.provisionedCredentials?.ip && (
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between p-3 bg-slate-900 rounded-lg border border-slate-800 gap-2">
                        <div>
                          <span className="text-slate-400 text-[10px] block uppercase">Dedicated IP / RDP Host</span>
                          <span className="text-cyan-400 font-bold">
                            {selectedOrder.provisionedCredentials.ip}:{selectedOrder.provisionedCredentials.port || 3389}
                          </span>
                        </div>
                        <div className="flex items-center space-x-2">
                          <button
                            onClick={() => copyToClipboard(`${selectedOrder.provisionedCredentials?.ip}:${selectedOrder.provisionedCredentials?.port || 3389}`, 'RDP IP')}
                            className="px-3 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded text-[11px] flex items-center space-x-1"
                          >
                            <Copy className="w-3 h-3" />
                            <span>Copy IP</span>
                          </button>
                          <button
                            onClick={() => handleOpenConsole(selectedOrder.provisionedCredentials?.ip || '', selectedOrder.items[0]?.planName || '')}
                            className="px-3 py-1 bg-blue-600 hover:bg-blue-500 text-white rounded text-[11px] flex items-center space-x-1"
                          >
                            <Terminal className="w-3 h-3" />
                            <span>Console</span>
                          </button>
                        </div>
                      </div>
                    )}
                  </div>
                </div>

                {/* Need Help Footer */}
                <div className="pt-2 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-slate-400">
                  <p>Have issues connecting or need software setup assistance?</p>
                  <a
                    href={`https://t.me/tatkalsupermaster919876543210?text=Hi%2C%20need%20help%20with%20Order%20${selectedOrder.orderNumber}`}
                    target="_blank"
                    rel="noreferrer"
                    className="text-cyan-400 hover:underline font-bold"
                  >
                    Contact Order Support on Telegram →
                  </a>
                </div>

              </div>
            )}
          </div>
        )}

      </div>
    </div>
  );
};
