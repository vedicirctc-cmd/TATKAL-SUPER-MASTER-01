import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { PLANS_DATA } from '../../data/mockData';
import { 
  Globe, 
  Wifi, 
  Network, 
  ShieldCheck, 
  Zap, 
  Check, 
  ArrowRight, 
  Activity, 
  Sparkles,
  Search,
  CheckCircle2,
  RefreshCw
} from 'lucide-react';
import { PlanItem } from '../../types';

export const IpServicesPage: React.FC = () => {
  const { openCheckout, formatPrice } = useApp();
  const [selectedIsp, setSelectedIsp] = useState('Jio Fibernet & 5G (High Trust)');
  const [protocol, setProtocol] = useState('HTTP / HTTPS & SOCKS5 Dual');
  const [testIpInput, setTestIpInput] = useState('');
  const [testResult, setTestResult] = useState<{ score: number; clean: boolean; isp: string } | null>(null);
  const [isTesting, setIsTesting] = useState(false);

  const ipPlans = PLANS_DATA.filter(p => 
    p.category === 'residential-ip' || 
    p.category === 'static-ip' || 
    p.category === 'datacenter-proxy'
  );

  const handleTestIp = (e: React.FormEvent) => {
    e.preventDefault();
    setIsTesting(true);
    setTimeout(() => {
      setTestResult({
        score: 0,
        clean: true,
        isp: 'Reliance Jio Infocomm Ltd (Mumbai Circle)'
      });
      setIsTesting(false);
    }, 1000);
  };

  const handleOrder = (plan: PlanItem) => {
    openCheckout(plan);
  };

  return (
    <div className="min-h-screen bg-[#050811] text-slate-100 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-16">
        
        {/* Page Hero */}
        <div className="rounded-3xl bg-gradient-to-r from-blue-950 via-[#0b142a] to-emerald-950/60 border border-blue-500/30 p-8 sm:p-12 lg:p-16 overflow-hidden shadow-2xl relative">
          <div className="max-w-3xl space-y-6 relative z-10">
            <div className="inline-flex items-center space-x-2 px-3.5 py-1.5 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs font-bold uppercase tracking-wider">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
              <span>100% Genuine ISP Residential Clean IPs</span>
            </div>

            <h1 className="text-3xl sm:text-5xl font-black text-white tracking-tight leading-tight">
              Pristine Indian <span className="bg-gradient-to-r from-emerald-400 via-teal-300 to-cyan-300 bg-clip-text text-transparent">Residential & Static IPs</span>
            </h1>

            <p className="text-slate-300 text-sm sm:text-base leading-relaxed">
              Bypass anti-bot captchas, rate limits, and IP blocks. Our clean residential proxies are routed directly through genuine Indian home internet connections (Jio, Airtel, ACT, BSNL) with a guaranteed 0 fraud score.
            </p>

            <div className="flex flex-wrap gap-4 pt-2">
              <button
                onClick={() => handleOrder(ipPlans[0])}
                className="px-7 py-3.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-500 hover:from-emerald-500 hover:to-teal-400 text-white font-extrabold text-sm shadow-xl shadow-emerald-900/40 transition-all flex items-center space-x-2 active:scale-95"
              >
                <Globe className="w-4 h-4 text-emerald-200" />
                <span>Buy 5 Clean Residential IPs (₹599)</span>
              </button>

              <button
                onClick={() => handleOrder(ipPlans[1])}
                className="px-6 py-3.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-200 hover:text-white border border-slate-700 font-bold text-sm transition-all flex items-center space-x-2"
              >
                <Wifi className="w-4 h-4 text-blue-400" />
                <span>Dedicated Static IP (₹349)</span>
              </button>
            </div>

            <div className="flex flex-wrap items-center gap-4 pt-4 text-xs text-slate-400 font-medium">
              <span className="flex items-center space-x-1">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                <span>Zero Detection / Zero Fraud Score</span>
              </span>
              <span className="flex items-center space-x-1">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                <span>HTTP(S) & SOCKS5 Support</span>
              </span>
              <span className="flex items-center space-x-1">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                <span>Instant Auto-Whitelisting</span>
              </span>
            </div>
          </div>
        </div>

        {/* Live Clean IP Score Checker Widget */}
        <div className="p-6 sm:p-8 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h3 className="text-base font-bold text-white flex items-center space-x-2">
                <Activity className="w-4 h-4 text-cyan-400" />
                <span>Test IP Cleanliness & Fraud Score Lookup</span>
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                Verify any IP address against railway anti-bot databases, Cloudflare score, and spam blacklists.
              </p>
            </div>
          </div>

          <form onSubmit={handleTestIp} className="flex flex-col sm:flex-row gap-3">
            <input
              type="text"
              value={testIpInput}
              onChange={(e) => setTestIpInput(e.target.value)}
              placeholder="Enter IP (e.g. 157.34.192.88) or click Test Sample"
              className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500 font-mono"
            />
            <button
              type="submit"
              disabled={isTesting}
              className="px-6 py-3 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold shrink-0 transition-all flex items-center justify-center space-x-2 shadow-lg shadow-emerald-950"
            >
              <RefreshCw className={`w-4 h-4 ${isTesting ? 'animate-spin' : ''}`} />
              <span>{isTesting ? 'Scanning Database...' : 'Check IP Score'}</span>
            </button>
          </form>

          {testResult && (
            <div className="p-4 bg-black/60 rounded-xl border border-emerald-500/30 grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs font-mono animate-in fade-in duration-150">
              <div>
                <span className="text-slate-400 block text-[10px]">FRAUD / BOT SCORE</span>
                <span className="text-emerald-400 font-bold text-sm">0 / 100 (100% CLEAN)</span>
              </div>
              <div>
                <span className="text-slate-400 block text-[10px]">ISP NETWORK</span>
                <span className="text-white font-bold">{testResult.isp}</span>
              </div>
              <div>
                <span className="text-slate-400 block text-[10px]">IRCTC DETECTION STATUS</span>
                <span className="text-emerald-400 font-bold">PASS (GENUINE RESIDENTIAL)</span>
              </div>
            </div>
          )}
        </div>

        {/* IP Plans Catalog */}
        <div className="space-y-8">
          <div className="text-center max-w-3xl mx-auto space-y-2">
            <h2 className="text-2xl sm:text-3xl font-extrabold text-white">
              Residential, Static & Datacenter IP Plans
            </h2>
            <p className="text-xs sm:text-sm text-slate-400">
              Instantly provision clean proxies for browser extensions, Tatkal software, and automated tools.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {ipPlans.map((plan) => (
              <div
                key={plan.id}
                className={`rounded-2xl p-6 sm:p-8 flex flex-col justify-between relative transition-all ${
                  plan.popular
                    ? 'bg-gradient-to-b from-[#0b241e] via-[#071310] to-[#050811] border-2 border-emerald-500 shadow-2xl shadow-emerald-950/80 -translate-y-2'
                    : 'bg-slate-900/60 border border-slate-800'
                }`}
              >
                {plan.badge && (
                  <div className="absolute -top-3.5 left-1/2 -translate-x-1/2 bg-emerald-600 text-white text-[10px] font-bold uppercase px-3 py-0.5 rounded-full shadow-md">
                    {plan.badge}
                  </div>
                )}

                <div className="space-y-6">
                  <div>
                    <h3 className="text-xl font-extrabold text-white">{plan.name}</h3>
                    <p className="text-xs text-slate-400 mt-1 min-h-[36px]">{plan.tagline}</p>
                  </div>

                  <div className="pb-4 border-b border-slate-800">
                    <div className="flex items-baseline space-x-1">
                      <span className="text-3xl font-black text-white font-mono">
                        {formatPrice(plan.priceINR, plan.priceUSD)}
                      </span>
                      <span className="text-xs text-slate-400">{plan.period}</span>
                    </div>
                  </div>

                  {/* Specs */}
                  <div className="space-y-2 bg-black/40 p-3.5 rounded-xl border border-slate-800 text-xs font-mono">
                    {plan.specs.map((spec, sIdx) => (
                      <div key={sIdx} className="flex justify-between items-center text-slate-300">
                        <span className="text-slate-400">{spec.label}:</span>
                        <span className="font-bold text-white">{spec.value}</span>
                      </div>
                    ))}
                  </div>

                  {/* Features */}
                  <div className="space-y-2 text-xs">
                    {plan.features.map((feat, fIdx) => (
                      <div key={fIdx} className="flex items-start space-x-2 text-slate-300">
                        <Check className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                        <span>{feat}</span>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="pt-8">
                  <button
                    onClick={() => handleOrder(plan)}
                    className={`w-full py-3.5 rounded-xl text-xs font-extrabold flex items-center justify-center space-x-2 transition-all ${
                      plan.popular
                        ? 'bg-gradient-to-r from-emerald-600 to-teal-500 hover:from-emerald-500 hover:to-teal-400 text-white shadow-lg shadow-emerald-950/60'
                        : 'bg-slate-800 hover:bg-slate-700 text-white'
                    }`}
                  >
                    <span>Instant Order & Allocate</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>

      </div>
    </div>
  );
};
