import React from 'react';
import { Hero } from '../home/Hero';
import { Features } from '../home/Features';
import { ServicesGrid } from '../home/ServicesGrid';
import { LiveInfrastructure } from '../home/LiveInfrastructure';
import { PricingSection } from '../home/PricingSection';
import { WhyChooseUs } from '../home/WhyChooseUs';
import { Testimonials } from '../home/Testimonials';
import { FaqSection } from '../home/FaqSection';
import { ContactCta } from '../home/ContactCta';

export const HomePage: React.FC = () => {
  return (
    <div className="min-h-screen bg-[#050811] text-slate-100">
      <Hero />
      <Features />
      <ServicesGrid />
      <LiveInfrastructure />
      <PricingSection />
      <WhyChooseUs />
      <Testimonials />
      <FaqSection />
      <ContactCta />
    </div>
  );
};
