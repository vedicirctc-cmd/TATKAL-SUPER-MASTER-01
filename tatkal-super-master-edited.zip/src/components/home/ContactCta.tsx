import React from 'react';
import { useApp } from '../../context/AppContext';
import { 
  Zap, 
  MessageSquare, 
  Send, 
  ArrowRight, 
  Sparkles, 
  ShieldCheck, 
  PhoneCall, 
  Mail,
  CheckCircle2
} from 'lucide-react';
import { PLANS_DATA } from '../../data/mockData';

export const ContactCta: React.FC = () => {
  const { setCurrentPage, openCheckout } = useApp();

  const handleQuickBuy = () => {
    const proPlan = PLANS_DATA.find(p => p.id === 'tatkal-pro') || PLANS_DATA[0];
    openCheckout(proPlan);
  };

  return (
    <section className="py-20 bg-gradient-to-b from-[#060a14] via-[#0b1429] to-[#04070f] relative overflow-hidden">
      {/* Background glow lines */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-full max-w-7xl h-96 bg-blue-600/10 rounded-full blur-3xl pointer-events-none" />

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="rounded-3xl bg-gradient-to-r from-blue-950 via-[#0d162f] to-indigo-950 border border-blue-500/40 p-8 sm:p-12 lg:p-16 shadow-2xl shadow-blue-950/90 text-center space-y-8">
          
          {/* Tag */}
          <div className="inline-flex items-center space-x-2 px-3.5 py-1.5 rounded-full bg-cyan-500/15 border border-cyan-500/30 text-cyan-300 text-xs font-bold uppercase tracking-wider">
            <Zap className="w-3.5 h-3.5 text-cyan-400" />
            <span>Ready for the Next 10:00 AM Tatkal Rush?</span>
          </div>

          {/* Heading */}
          <div className="max-w-3xl mx-auto space-y-4">
            <h2 className="text-3xl sm:text-5xl font-black text-white tracking-tight leading-tight">
              Get Your Instant License & High-Speed Mumbai VPS in <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-cyan-400">Under 60 Seconds</span>
            </h2>
            <p className="text-slate-300 text-sm sm:text-base leading-relaxed max-w-2xl mx-auto">
              Join thousands of satisfied travel agents and power users who achieve a 98%+ confirmed booking ratio with our zero-latency automation tools.
            </p>
          </div>

          {/* Value Badges */}
          <div className="flex flex-wrap items-center justify-center gap-4 text-xs font-semibold text-slate-300">
            <div className="flex items-center space-x-1.5 bg-black/40 px-3 py-1.5 rounded-lg border border-slate-800">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span>Instant Automated Activation</span>
            </div>
            <div className="flex items-center space-x-1.5 bg-black/40 px-3 py-1.5 rounded-lg border border-slate-800">
              <CheckCircle2 className="w-4 h-4 text-blue-400" />
              <span>UPI & Card Supported</span>
            </div>
            <div className="flex items-center space-x-1.5 bg-black/40 px-3 py-1.5 rounded-lg border border-slate-800">
              <CheckCircle2 className="w-4 h-4 text-cyan-400" />
              <span>100% Guaranteed Clean IPs</span>
            </div>
          </div>

          {/* Big Action Buttons */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-2">
            <button
              id="cta-buy-now-pro"
              onClick={handleQuickBuy}
              className="w-full sm:w-auto px-8 py-4 rounded-xl bg-gradient-to-r from-blue-600 via-indigo-600 to-cyan-500 hover:from-blue-500 hover:to-cyan-400 text-white font-extrabold text-sm shadow-xl shadow-blue-600/30 hover:shadow-blue-500/50 transition-all flex items-center justify-center space-x-2 active:scale-95 group"
            >
              <span>Buy Tatkal Super Master PRO (₹999/mo)</span>
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </button>

            <a
              href="https://t.me/tatkalsupermaster919876543210?text=Hi%20Tatkal%20Super%20Master%2C%20I%20want%20to%20buy%20Tatkal%20Software%20and%20VPS%20today."
              target="_blank"
              rel="noreferrer"
              className="w-full sm:w-auto px-6 py-4 rounded-xl bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-300 border border-emerald-500/40 font-bold text-sm transition-all flex items-center justify-center space-x-2 shadow-lg shadow-emerald-950"
            >
              <MessageSquare className="w-4 h-4 text-emerald-400" />
              <span>Chat on Telegram (+91 98765 43210)</span>
            </a>

            <button
              onClick={() => {
                setCurrentPage('contact');
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              className="w-full sm:w-auto px-6 py-4 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-200 border border-slate-800 hover:border-slate-700 font-bold text-sm transition-all flex items-center justify-center space-x-2"
            >
              <Mail className="w-4 h-4 text-blue-400" />
              <span>Contact Sales Desk</span>
            </button>
          </div>

        </div>
      </div>
    </section>
  );
};
