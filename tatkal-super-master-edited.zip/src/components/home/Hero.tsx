import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { 
  Zap, 
  Server, 
  ShieldCheck, 
  ArrowRight, 
  Play, 
  Cpu, 
  Globe, 
  Activity, 
  Sparkles, 
  CheckCircle2, 
  Terminal, 
  MessageSquare,
  Lock
} from 'lucide-react';
import { PLANS_DATA } from '../../data/mockData';

export const Hero: React.FC = () => {
  const { setCurrentPage, openCheckout, setIsDemoModalOpen } = useApp();
  const [ping, setPing] = useState(1.4);

  // Simulate ultra-low live latency fluctuation
  useEffect(() => {
    const interval = setInterval(() => {
      const random = 1.2 + Math.random() * 0.4;
      setPing(parseFloat(random.toFixed(2)));
    }, 2500);
    return () => clearInterval(interval);
  }, []);

  const handleGetStarted = () => {
    const defaultPlan = PLANS_DATA.find(p => p.id === 'tatkal-pro') || PLANS_DATA[0];
    openCheckout(defaultPlan);
  };

  const handleViewPlans = () => {
    const element = document.getElementById('pricing-section');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    } else {
      setCurrentPage('vps-hosting');
    }
  };

  return (
    <section className="relative pt-12 pb-20 md:pt-20 md:pb-28 overflow-hidden bg-radial-gradient">
      {/* Background Decorative Tech Grid */}
      <div className="absolute inset-0 bg-grid-pattern opacity-40 pointer-events-none" />
      
      {/* Glowing Orb Accents */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-blue-600/15 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute top-1/3 right-10 w-80 h-80 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          {/* Left Column: Copy & Conversion */}
          <div className="lg:col-span-7 space-y-6 text-center lg:text-left">
            {/* Top Pill */}
            <div className="inline-flex items-center space-x-2 px-3.5 py-1.5 rounded-full bg-blue-500/10 border border-blue-500/30 text-blue-400 text-xs font-semibold shadow-lg shadow-blue-900/20">
              <span className="w-2 h-2 rounded-full bg-cyan-400 animate-ping" />
              <span>Next-Gen Tatkal Automation & 10Gbps Windows VPS</span>
              <span className="bg-blue-600/30 text-cyan-300 text-[10px] px-1.5 py-0.5 rounded font-mono">v4.8 Turbo</span>
            </div>

            {/* Main Headline */}
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight text-white leading-[1.1]">
              <span className="block">TATKAL</span>
              <span className="bg-gradient-to-r from-blue-400 via-indigo-300 to-cyan-300 bg-clip-text text-transparent">
                SUPER MASTER
              </span>
            </h1>

            {/* Subheadline */}
            <p className="text-base sm:text-lg text-slate-300 max-w-2xl mx-auto lg:mx-0 font-normal leading-relaxed">
              Fast, Secure & Reliable Tatkal Solutions, Windows & Linux VPS Hosting and Premium Residential Clean IP Services. Built for zero-latency IRCTC booking execution.
            </p>

            {/* Key Value Proposition Badges */}
            <div className="flex flex-wrap items-center justify-center lg:justify-start gap-3 pt-1 text-xs text-slate-300">
              <div className="flex items-center space-x-1.5 bg-slate-900/80 border border-slate-800 px-3 py-1.5 rounded-lg">
                <Zap className="w-4 h-4 text-cyan-400" />
                <span>&lt;0.4s Form Auto-Fill</span>
              </div>
              <div className="flex items-center space-x-1.5 bg-slate-900/80 border border-slate-800 px-3 py-1.5 rounded-lg">
                <Server className="w-4 h-4 text-blue-400" />
                <span>10 Gbps Mumbai Equinix Node</span>
              </div>
              <div className="flex items-center space-x-1.5 bg-slate-900/80 border border-slate-800 px-3 py-1.5 rounded-lg">
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
                <span>Zero Anti-Bot Flagging</span>
              </div>
            </div>

            {/* Main Action Buttons */}
            <div className="flex flex-col sm:flex-row items-center justify-center lg:justify-start gap-3.5 pt-3">
              <button
                id="hero-get-started-btn"
                onClick={handleGetStarted}
                className="w-full sm:w-auto px-7 py-3.5 rounded-xl bg-gradient-to-r from-blue-600 via-indigo-600 to-cyan-500 hover:from-blue-500 hover:to-cyan-400 text-white font-extrabold text-sm shadow-xl shadow-blue-600/30 hover:shadow-blue-500/50 transition-all flex items-center justify-center space-x-2 active:scale-95 group"
              >
                <span>Get Started Now</span>
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </button>

              <button
                id="hero-view-plans-btn"
                onClick={handleViewPlans}
                className="w-full sm:w-auto px-6 py-3.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-200 hover:text-white border border-slate-800 hover:border-blue-500/40 text-sm font-bold transition-all flex items-center justify-center space-x-2"
              >
                <span>View Plans & Pricing</span>
              </button>

              <button
                id="hero-demo-modal-btn"
                onClick={() => setIsDemoModalOpen(true)}
                className="w-full sm:w-auto px-5 py-3.5 rounded-xl bg-blue-500/10 hover:bg-blue-500/20 text-cyan-300 border border-blue-500/30 text-sm font-semibold transition-all flex items-center justify-center space-x-2"
              >
                <Play className="w-4 h-4 fill-cyan-400" />
                <span>Live Demo</span>
              </button>
            </div>

            {/* Trust Footer line */}
            <div className="pt-4 flex flex-wrap items-center justify-center lg:justify-start gap-4 text-xs text-slate-400">
              <div className="flex items-center space-x-1">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                <span>Instant &lt;60s Activation</span>
              </div>
              <div className="flex items-center space-x-1">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                <span>100% Verified Clean IPs</span>
              </div>
              <div className="flex items-center space-x-1">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                <span>24/7 VIP Telegram Desk</span>
              </div>
            </div>
          </div>

          {/* Right Column: Interactive Server & Network Visualizer */}
          <div className="lg:col-span-5">
            <div className="relative rounded-2xl bg-[#090f1d] border border-blue-500/30 shadow-2xl shadow-blue-950/80 p-5 space-y-4 glow-blue">
              
              {/* Card Header Bar */}
              <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                <div className="flex items-center space-x-2">
                  <div className="flex space-x-1.5">
                    <span className="w-2.5 h-2.5 rounded-full bg-red-500/80" />
                    <span className="w-2.5 h-2.5 rounded-full bg-yellow-500/80" />
                    <span className="w-2.5 h-2.5 rounded-full bg-emerald-500/80" />
                  </div>
                  <span className="text-[11px] font-mono text-slate-400">node-mb2-equinix.tsm.net</span>
                </div>

                <div className="flex items-center space-x-2 bg-emerald-500/10 border border-emerald-500/30 px-2.5 py-0.5 rounded-full text-[11px] font-mono text-emerald-400 font-bold">
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                  <span>ONLINE ({ping} ms)</span>
                </div>
              </div>

              {/* Real-time Telemetry Metrics */}
              <div className="grid grid-cols-2 gap-2.5 text-xs font-mono">
                <div className="p-3 rounded-xl bg-slate-900/80 border border-slate-800 space-y-1">
                  <span className="text-slate-400 text-[10px] uppercase block">IRCTC Gateway Ping</span>
                  <div className="flex items-baseline space-x-1">
                    <span className="text-xl font-bold text-cyan-400">{ping}</span>
                    <span className="text-xs text-slate-400">ms</span>
                  </div>
                  <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
                    <div className="bg-cyan-400 h-full w-[95%]" />
                  </div>
                </div>

                <div className="p-3 rounded-xl bg-slate-900/80 border border-slate-800 space-y-1">
                  <span className="text-slate-400 text-[10px] uppercase block">Port Uplink</span>
                  <div className="flex items-baseline space-x-1">
                    <span className="text-xl font-bold text-emerald-400">10.0</span>
                    <span className="text-xs text-slate-400">Gbps</span>
                  </div>
                  <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
                    <div className="bg-emerald-400 h-full w-[98%]" />
                  </div>
                </div>
              </div>

              {/* Live Simulated Console Feed */}
              <div className="p-3 bg-black/60 rounded-xl border border-slate-800 font-mono text-[11px] space-y-1.5 text-slate-300">
                <div className="text-cyan-300 flex items-center justify-between">
                  <span>[10:00:00.042] TATKAL ENGINE TRIGGERED</span>
                  <span className="text-[10px] bg-blue-500/20 text-blue-300 px-1 rounded">SUB-SECOND</span>
                </div>
                <div className="text-emerald-400">✓ AI Captcha Solved in 0.14s</div>
                <div className="text-slate-300">✓ Master List Injected: 4 Passengers</div>
                <div className="text-emerald-400">✓ Seat Reserved: B4-32 (CNF Lower Berth)</div>
                <div className="text-cyan-300">✓ Auto-Payment Verified via Direct UPI Gateway</div>
              </div>

              {/* Interactive Quick Action Bar on Card */}
              <div className="pt-2 flex items-center justify-between text-xs">
                <div className="flex items-center space-x-1 text-slate-400">
                  <Lock className="w-3.5 h-3.5 text-emerald-400" />
                  <span>AES-256 Encrypted</span>
                </div>
                <button
                  onClick={() => setCurrentPage('tatkal-software')}
                  className="text-xs text-blue-400 hover:text-blue-300 font-bold flex items-center space-x-1"
                >
                  <span>Explore Software Engine</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
};
