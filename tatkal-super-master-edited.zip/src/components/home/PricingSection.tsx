import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { PLANS_DATA } from '../../data/mockData';
import { 
  Check, 
  Zap, 
  Sparkles, 
  ShieldCheck, 
  ArrowRight, 
  Clock, 
  Server, 
  Layers,
  HelpCircle
} from 'lucide-react';
import { ServiceCategory, PlanItem } from '../../types';

export const PricingSection: React.FC = () => {
  const { openCheckout, formatPrice, currency, setCurrentPage } = useApp();
  const [selectedCategory, setSelectedCategory] = useState<ServiceCategory>('tatkal-software');
  const [isAnnual, setIsAnnual] = useState(false);

  const categories: { id: ServiceCategory; label: string }[] = [
    { id: 'tatkal-software', label: 'Tatkal Software' },
    { id: 'windows-vps', label: 'Windows VPS' },
    { id: 'linux-vps', label: 'Linux VPS' },
    { id: 'residential-ip', label: 'Residential IPs' },
  ];

  const currentPlans = PLANS_DATA.filter(p => {
    if (selectedCategory === 'residential-ip') {
      return p.category === 'residential-ip' || p.category === 'static-ip' || p.category === 'datacenter-proxy';
    }
    return p.category === selectedCategory;
  });

  const handleSelectPlan = (plan: PlanItem) => {
    let finalPlan = { ...plan };
    if (isAnnual) {
      // 20% extra discount on annual
      finalPlan.priceINR = Math.round(plan.priceINR * 12 * 0.8);
      finalPlan.priceUSD = Math.round(plan.priceUSD * 12 * 0.8);
      finalPlan.period = '/year (20% OFF)';
    }
    openCheckout(finalPlan);
  };

  return (
    <section id="pricing-section" className="py-20 bg-[#070b16] relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-3 mb-12">
          <div className="inline-flex items-center space-x-1.5 px-3 py-1 rounded-full bg-blue-500/10 border border-blue-500/20 text-blue-400 text-xs font-bold uppercase tracking-wider">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Transparent Pricing • Instant Automated Delivery</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
            Select the Perfect Plan for Your Needs
          </h2>
          <p className="text-slate-400 text-sm sm:text-base leading-relaxed">
            No hidden setup fees. All plans include automated 24/7 license provisioning and guaranteed Tier-4 low-latency hardware.
          </p>

          {/* Billing Cycle Toggle */}
          <div className="pt-4 flex items-center justify-center space-x-3 text-xs font-bold">
            <span className={!isAnnual ? 'text-white' : 'text-slate-400'}>Monthly Billing</span>
            <button
              onClick={() => setIsAnnual(!isAnnual)}
              className={`w-12 h-6 rounded-full p-1 transition-colors relative ${
                isAnnual ? 'bg-blue-600' : 'bg-slate-800'
              }`}
            >
              <div
                className={`w-4 h-4 rounded-full bg-white transition-transform ${
                  isAnnual ? 'translate-x-6' : 'translate-x-0'
                }`}
              />
            </button>
            <div className="flex items-center space-x-1.5">
              <span className={isAnnual ? 'text-white' : 'text-slate-400'}>Annual Billing</span>
              <span className="text-[10px] bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 px-2 py-0.5 rounded-full">
                Save 20%
              </span>
            </div>
          </div>

          {/* Category Tabs */}
          <div className="pt-4 flex flex-wrap items-center justify-center gap-2">
            {categories.map((cat) => (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.id)}
                className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
                  selectedCategory === cat.id
                    ? 'bg-blue-600 text-white shadow-lg shadow-blue-900/40'
                    : 'bg-slate-900/80 text-slate-400 hover:text-white border border-slate-800'
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>
        </div>

        {/* Pricing Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 items-stretch">
          {currentPlans.map((plan) => {
            const displayPriceINR = isAnnual ? Math.round(plan.priceINR * 12 * 0.8) : plan.priceINR;
            const displayPriceUSD = isAnnual ? Math.round(plan.priceUSD * 12 * 0.8) : plan.priceUSD;
            const displayPeriod = isAnnual ? '/year' : plan.period;

            return (
              <div
                key={plan.id}
                className={`relative rounded-2xl p-6 sm:p-8 flex flex-col justify-between transition-all duration-300 ${
                  plan.popular
                    ? 'bg-gradient-to-b from-[#0f1b36] via-[#091124] to-[#070b16] border-2 border-blue-500 shadow-2xl shadow-blue-950/90 scale-100 md:-translate-y-2'
                    : 'bg-slate-900/60 border border-slate-800 hover:border-slate-700'
                }`}
              >
                {/* Popular / Featured Badge */}
                {plan.badge && (
                  <div className="absolute -top-3.5 left-1/2 -translate-x-1/2 bg-gradient-to-r from-blue-600 to-cyan-500 text-white text-[11px] font-extrabold uppercase px-3 py-0.5 rounded-full shadow-lg shadow-blue-900/50">
                    {plan.badge}
                  </div>
                )}

                <div className="space-y-6">
                  {/* Plan Title & Tagline */}
                  <div>
                    <h3 className="text-xl font-extrabold text-white">{plan.name}</h3>
                    <p className="text-xs text-slate-400 mt-1 leading-relaxed min-h-[36px]">{plan.tagline}</p>
                  </div>

                  {/* Price */}
                  <div className="pt-2 pb-4 border-y border-slate-800/80">
                    <div className="flex items-baseline space-x-1">
                      <span className="text-3xl sm:text-4xl font-black text-white font-mono">
                        {formatPrice(displayPriceINR, displayPriceUSD)}
                      </span>
                      <span className="text-xs text-slate-400 font-medium">{displayPeriod}</span>
                    </div>
                    {plan.originalPriceINR && !isAnnual && (
                      <div className="mt-1 flex items-center space-x-2 text-xs">
                        <span className="text-slate-500 line-through">
                          {formatPrice(plan.originalPriceINR, plan.originalPriceINR / 60)}
                        </span>
                        <span className="text-emerald-400 font-bold">Save 50%</span>
                      </div>
                    )}
                    <div className="mt-2 flex items-center space-x-1 text-[11px] text-cyan-400">
                      <Clock className="w-3.5 h-3.5" />
                      <span>{plan.activationTime}</span>
                    </div>
                  </div>

                  {/* Specs Quick Checklist */}
                  {plan.specs && plan.specs.length > 0 && (
                    <div className="space-y-2 bg-black/40 p-3.5 rounded-xl border border-slate-800 text-xs">
                      {plan.specs.map((spec, sIdx) => (
                        <div key={sIdx} className="flex justify-between items-center text-slate-300">
                          <span className="text-slate-400">{spec.label}:</span>
                          <span className="font-bold text-white font-mono">{spec.value}</span>
                        </div>
                      ))}
                    </div>
                  )}

                  {/* Feature Bullets */}
                  <div className="space-y-2.5">
                    <p className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">Features Included:</p>
                    {plan.features.map((feat, fIdx) => (
                      <div key={fIdx} className="flex items-start space-x-2 text-xs text-slate-300">
                        <Check className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                        <span>{feat}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Buy Button */}
                <div className="pt-8">
                  <button
                    id={`buy-plan-btn-${plan.id}`}
                    onClick={() => handleSelectPlan(plan)}
                    className={`w-full py-3.5 px-4 rounded-xl text-xs font-extrabold transition-all flex items-center justify-center space-x-2 shadow-lg ${
                      plan.popular
                        ? 'bg-gradient-to-r from-blue-600 via-indigo-600 to-cyan-500 hover:from-blue-500 hover:to-cyan-400 text-white shadow-blue-900/40 active:scale-98'
                        : 'bg-slate-800 hover:bg-slate-700 text-white border border-slate-700 active:scale-98'
                    }`}
                  >
                    <Zap className="w-4 h-4 text-cyan-300" />
                    <span>Instant Purchase & Activate</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>

        {/* Custom Requirements Banner */}
        <div className="mt-12 p-6 rounded-2xl bg-gradient-to-r from-blue-950/50 via-slate-900 to-indigo-950/50 border border-blue-500/20 flex flex-col sm:flex-row items-center justify-between gap-4 text-center sm:text-left">
          <div className="space-y-1">
            <h4 className="text-base font-bold text-white">Need a Custom Enterprise Configuration or 100+ IPs?</h4>
            <p className="text-xs text-slate-400">
              We provide tailored bare-metal clusters, dedicated subnets, and wholesale agency licensing with custom SLAs.
            </p>
          </div>
          <button
            onClick={() => {
              setCurrentPage('contact');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            className="px-6 py-2.5 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-bold shrink-0 transition-all shadow-lg shadow-blue-900/30"
          >
            Contact Enterprise Sales
          </button>
        </div>

      </div>
    </section>
  );
};
