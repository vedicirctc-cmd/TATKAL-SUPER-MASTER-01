import React from 'react';
import { COMPANY_STATS } from '../../data/mockData';
import { 
  ShieldCheck, 
  Zap, 
  Headphones, 
  Lock, 
  Server, 
  Smile, 
  CheckCircle2, 
  Sparkles,
  Award,
  ArrowUpRight
} from 'lucide-react';
import { useApp } from '../../context/AppContext';

export const WhyChooseUs: React.FC = () => {
  const { setCurrentPage } = useApp();

  const reasons = [
    {
      icon: Award,
      title: 'Trusted Service',
      desc: 'Serving over 14,500+ travel agencies, operators, and individuals across India since 2021 with consistent 4.9/5 star ratings.',
      color: 'from-blue-500 to-indigo-500'
    },
    {
      icon: Zap,
      title: 'Fast Delivery',
      desc: '100% automated hypervisor provisioning. Software licenses, VPS logins, and IP proxies delivered instantly within 60 seconds.',
      color: 'from-cyan-500 to-blue-500'
    },
    {
      icon: Headphones,
      title: 'Premium Support',
      desc: 'Live technical specialists available 24/7 on Telegram, Telegram, and AnyDesk. Specialized morning coverage at 09:30 AM.',
      color: 'from-emerald-500 to-teal-500'
    },
    {
      icon: Lock,
      title: 'Secure Payments',
      desc: 'Support for UPI (Google Pay, PhonePe, Paytm, CRED), NetBanking, and Debit/Credit Cards via 256-bit SSL encrypted gateways.',
      color: 'from-purple-500 to-pink-500'
    },
    {
      icon: Server,
      title: 'Professional Infrastructure',
      desc: 'Hosted in Tier-4 Equinix and CtrlS datacenters with dual power grids, 10Gbps optical feeds, and inline anti-DDoS filters.',
      color: 'from-amber-500 to-orange-500'
    },
    {
      icon: Smile,
      title: 'Customer Satisfaction',
      desc: 'Guaranteed 99.99% hardware SLA uptime and an unmatched 98% confirmed booking ratio during heavy holiday Tatkal rushes.',
      color: 'from-rose-500 to-red-500'
    },
  ];

  return (
    <section className="py-20 bg-[#060a14] border-t border-slate-800/80 relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-3 mb-16">
          <div className="inline-flex items-center space-x-1.5 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs font-bold uppercase tracking-wider">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Unmatched Reliability & SLA</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
            Why Choose TATKAL SUPER MASTER?
          </h2>
          <p className="text-slate-400 text-sm sm:text-base leading-relaxed">
            We don't just provide software and servers — we deliver the mission-critical speed, genuine clean IP network, and 24/7 technical backing you need.
          </p>
        </div>

        {/* 6 Reasons Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-16">
          {reasons.map((reason, idx) => {
            const Icon = reason.icon;
            return (
              <div
                key={idx}
                className="p-6 rounded-2xl bg-slate-900/60 border border-slate-800 hover:border-blue-500/40 transition-all duration-300 hover:-translate-y-1 hover:shadow-xl hover:shadow-blue-950/40 flex flex-col justify-between"
              >
                <div className="space-y-3">
                  <div className={`w-11 h-11 rounded-xl bg-gradient-to-br ${reason.color} p-[1.5px]`}>
                    <div className="w-full h-full bg-[#080d1a] rounded-[10px] flex items-center justify-center">
                      <Icon className="w-5 h-5 text-white" />
                    </div>
                  </div>
                  <h3 className="text-base font-bold text-white">{reason.title}</h3>
                  <p className="text-xs sm:text-sm text-slate-400 leading-relaxed">{reason.desc}</p>
                </div>

                <div className="mt-4 pt-3 border-t border-slate-800/60 flex items-center space-x-1.5 text-xs text-emerald-400 font-semibold">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>Verified Standard</span>
                </div>
              </div>
            );
          })}
        </div>

        {/* Live Company Stats Banner */}
        <div className="rounded-2xl bg-gradient-to-r from-blue-950 via-slate-900 to-indigo-950 border border-blue-500/30 p-8 shadow-2xl">
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-6 text-center">
            {COMPANY_STATS.map((stat, sIdx) => (
              <div key={sIdx} className="space-y-1">
                <div className="text-2xl sm:text-3xl font-black text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-blue-400 font-mono">
                  {stat.value}
                </div>
                <p className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">{stat.label}</p>
              </div>
            ))}
          </div>
        </div>

      </div>
    </section>
  );
};
