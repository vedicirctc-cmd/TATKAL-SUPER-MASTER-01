import React from 'react';
import { useApp } from '../../context/AppContext';
import { 
  Zap, 
  Server, 
  Terminal, 
  HardDrive, 
  Globe, 
  Wifi, 
  Network, 
  Monitor, 
  ArrowRight, 
  Check, 
  Sparkles,
  ChevronRight
} from 'lucide-react';
import { PageView } from '../../types';
import { PLANS_DATA } from '../../data/mockData';

export const ServicesGrid: React.FC = () => {
  const { setCurrentPage, openCheckout, formatPrice } = useApp();

  const services = [
    {
      id: 'tatkal-software',
      title: 'Tatkal Software',
      targetPage: 'tatkal-software' as PageView,
      icon: Zap,
      badge: 'v4.8 Turbo Engine',
      price: '₹499/mo',
      desc: 'Sub-second auto-fill, neural OCR captcha solver, and bank OTP fast-forwarding for guaranteed confirmed tickets.',
      keyPoints: ['<0.4s Form Autofill', 'Auto-Captcha AI Engine', 'Multi-Slot Concurrency'],
      buttonText: 'Configure Software',
      color: 'from-blue-600 to-indigo-600'
    },
    {
      id: 'windows-vps',
      title: 'Windows VPS',
      targetPage: 'vps-hosting' as PageView,
      icon: Server,
      badge: '<1.8ms Latency',
      price: '₹799/mo',
      desc: 'High-speed Windows Server 2022 VPS hosted in Mumbai Equinix MB2 with 10Gbps dedicated port and full RDP access.',
      keyPoints: ['NVMe Gen4 Storage', 'Windows Server 2022', 'Direct RDP Connection'],
      buttonText: 'Deploy Windows VPS',
      color: 'from-cyan-600 to-blue-600'
    },
    {
      id: 'linux-vps',
      title: 'Linux VPS',
      targetPage: 'vps-hosting' as PageView,
      icon: Terminal,
      badge: 'KVM High-Clock',
      price: '₹449/mo',
      desc: 'Low-latency Ubuntu, Debian, and CentOS cloud instances tuned for Python automation, headless bots, and scraper daemons.',
      keyPoints: ['Full Root Access', 'Docker & Python Ready', 'Unmetered 10Gbps Port'],
      buttonText: 'Deploy Linux Node',
      color: 'from-indigo-600 to-purple-600'
    },
    {
      id: 'dedicated-server',
      title: 'Dedicated Server',
      targetPage: 'vps-hosting' as PageView,
      icon: HardDrive,
      badge: 'Bare-Metal Power',
      price: '₹4,999/mo',
      desc: '100% isolated Intel Xeon & AMD EPYC bare-metal machines with IPMI, hardware RAID, and 5 clean static IPv4 addresses.',
      keyPoints: ['64GB ECC RAM', 'Hardware RAID-1 NVMe', 'Carrier Redundancy'],
      buttonText: 'Explore Dedicated',
      color: 'from-amber-600 to-red-600'
    },
    {
      id: 'residential-ip',
      title: 'Residential IP',
      targetPage: 'ip-services' as PageView,
      icon: Globe,
      badge: '100% Genuine ISP',
      price: '₹599/pack',
      desc: 'Authentic Indian residential home IP addresses from Jio, Airtel, and ACT Fibernet with zero fraud score and no bot captchas.',
      keyPoints: ['Jio & Airtel Clean IPs', 'HTTP & SOCKS5 Support', 'Zero Detection Rate'],
      buttonText: 'Get Residential IPs',
      color: 'from-emerald-600 to-teal-600'
    },
    {
      id: 'static-ip',
      title: 'Static IP',
      targetPage: 'ip-services' as PageView,
      icon: Wifi,
      badge: 'Dedicated IPv4',
      price: '₹349/mo',
      desc: 'Fixed permanent static IPv4 address dedicated solely to your device, maintaining unbroken session reputation and low ping.',
      keyPoints: ['100% Dedicated IPv4', 'Configurable rDNS', 'Sub-3ms Mumbai Ping'],
      buttonText: 'Assign Static IP',
      color: 'from-blue-600 to-cyan-600'
    },
    {
      id: 'datacenter-proxy',
      title: 'Datacenter Proxy',
      targetPage: 'ip-services' as PageView,
      icon: Network,
      badge: 'Gigabit Backbone',
      price: '₹499/pack',
      desc: 'Massive throughput datacenter proxies hosted in Tier-4 carrier hubs for high-concurrency ticket monitoring and status polling.',
      keyPoints: ['Unlimited Threads', 'Diverse Class-C Subnets', 'API Auto-Export'],
      buttonText: 'Get DC Proxies',
      color: 'from-purple-600 to-pink-600'
    },
    {
      id: 'rdp-solutions',
      title: 'RDP Solutions',
      targetPage: 'vps-hosting' as PageView,
      icon: Monitor,
      badge: 'Pre-Configured',
      price: '₹699/mo',
      desc: 'Plug-and-play remote desktops pre-loaded with browser profiles, Tatkal extensions, and zero manual installation required.',
      keyPoints: ['Access from Phone/PC', 'Pre-configured Profiles', '60 FPS Rendering'],
      buttonText: 'Connect RDP',
      color: 'from-teal-600 to-blue-600'
    },
  ];

  const handleCardAction = (service: typeof services[0]) => {
    setCurrentPage(service.targetPage);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <section id="services-section" className="py-20 bg-[#070b16] relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-4">
          <div className="space-y-2">
            <div className="inline-flex items-center space-x-1.5 px-3 py-1 rounded-full bg-cyan-500/10 border border-cyan-500/20 text-cyan-400 text-xs font-bold uppercase tracking-wider">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Full-Stack Automation Portfolio</span>
            </div>
            <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
              Our Premium Services & Solutions
            </h2>
            <p className="text-slate-400 text-sm max-w-xl">
              From sub-millisecond cloud hosting to pristine clean IP networks, discover end-to-end tooling crafted for peak booking success.
            </p>
          </div>

          <div className="flex items-center space-x-2">
            <button
              onClick={() => {
                setCurrentPage('tatkal-software');
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              className="px-4 py-2 bg-slate-900 hover:bg-slate-800 border border-slate-800 rounded-lg text-xs font-bold text-slate-300 hover:text-white transition-colors"
            >
              Explore Software
            </button>
            <button
              onClick={() => {
                setCurrentPage('vps-hosting');
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              className="px-4 py-2 bg-blue-600/20 hover:bg-blue-600/30 border border-blue-500/30 rounded-lg text-xs font-bold text-blue-400 hover:text-white transition-colors"
            >
              Compare All VPS
            </button>
          </div>
        </div>

        {/* 8 Service Cards Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {services.map((service, index) => {
            const Icon = service.icon;
            return (
              <div
                key={service.id}
                className="group rounded-2xl bg-slate-900/70 border border-slate-800 hover:border-blue-500/50 p-5 transition-all duration-300 hover:-translate-y-1 hover:shadow-2xl hover:shadow-blue-950/60 flex flex-col justify-between"
              >
                <div className="space-y-4">
                  {/* Icon & Badge Header */}
                  <div className="flex items-center justify-between">
                    <div className={`w-11 h-11 rounded-xl bg-gradient-to-br ${service.color} p-[1.5px] shadow-lg shadow-blue-950`}>
                      <div className="w-full h-full bg-[#080d1a] rounded-[10px] flex items-center justify-center">
                        <Icon className="w-5 h-5 text-white group-hover:scale-110 transition-transform duration-200" />
                      </div>
                    </div>
                    <span className="text-[10px] font-mono font-bold bg-blue-500/10 text-blue-300 border border-blue-500/20 px-2 py-0.5 rounded">
                      {service.badge}
                    </span>
                  </div>

                  {/* Title & Price */}
                  <div>
                    <h3 className="text-base font-bold text-white group-hover:text-cyan-300 transition-colors">
                      {service.title}
                    </h3>
                    <div className="flex items-baseline space-x-1.5 mt-0.5">
                      <span className="text-xs text-slate-400">Starting from</span>
                      <span className="text-sm font-extrabold text-cyan-400 font-mono">{service.price}</span>
                    </div>
                  </div>

                  {/* Description */}
                  <p className="text-xs text-slate-400 leading-relaxed line-clamp-3">
                    {service.desc}
                  </p>

                  {/* Bullet Highlights */}
                  <div className="space-y-1.5 pt-2 border-t border-slate-800/80">
                    {service.keyPoints.map((point, pIdx) => (
                      <div key={pIdx} className="flex items-center space-x-1.5 text-[11px] text-slate-300">
                        <Check className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                        <span>{point}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Card CTA Button */}
                <button
                  onClick={() => handleCardAction(service)}
                  className="mt-5 w-full py-2.5 px-3 rounded-xl bg-slate-800/80 hover:bg-gradient-to-r hover:from-blue-600 hover:to-indigo-600 text-white text-xs font-bold transition-all flex items-center justify-center space-x-1.5 group-hover:shadow-lg group-hover:shadow-blue-900/40"
                >
                  <span>{service.buttonText}</span>
                  <ChevronRight className="w-3.5 h-3.5 group-hover:translate-x-0.5 transition-transform" />
                </button>
              </div>
            );
          })}
        </div>

      </div>
    </section>
  );
};
