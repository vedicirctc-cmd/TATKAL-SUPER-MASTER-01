import React from 'react';
import { 
  Zap, 
  Server, 
  Globe, 
  ShieldCheck, 
  Lock, 
  Headphones, 
  Activity, 
  Sparkles,
  Layers,
  Clock,
  Cpu,
  CheckCircle2
} from 'lucide-react';

export const Features: React.FC = () => {
  const features = [
    {
      icon: Clock,
      title: 'Instant Activation',
      tagline: 'Under 60 Seconds Delivery',
      desc: 'Our automated provisioning cloud allocates your software licenses, RDP credentials, and clean proxy IPs immediately after payment.',
      metric: '< 60s',
      color: 'from-blue-500 to-cyan-400',
      badge: 'Zero Waiting'
    },
    {
      icon: Server,
      title: 'High-Speed Servers',
      tagline: '10 Gbps Tier-4 Carrier Port',
      desc: 'Hosted in premier Mumbai CtrlS and Equinix datacenters directly connected to National Internet Exchange of India (NIXI) backbone.',
      metric: '10 Gbps',
      color: 'from-indigo-500 to-blue-500',
      badge: 'NVMe Gen4'
    },
    {
      icon: Globe,
      title: 'Premium IP Network',
      tagline: 'Clean Indian Residential IPs',
      desc: 'Access pristine Jio, Airtel, and ACT Fibernet residential IPs that bypass bot-detection algorithms and never get flagged.',
      metric: '0.0 Fraud Score',
      color: 'from-cyan-500 to-teal-400',
      badge: 'Jio & Airtel'
    },
    {
      icon: Activity,
      title: '99.9% Uptime SLA',
      tagline: 'Carrier-Grade Redundancy',
      desc: 'Dual power grids, enterprise RAID-1 NVMe storage, and automated hardware failover guarantee your booking sessions run uninterrupted.',
      metric: '99.99%',
      color: 'from-emerald-500 to-cyan-400',
      badge: 'SLA Guaranteed'
    },
    {
      icon: Lock,
      title: 'Secure Infrastructure',
      tagline: 'AES-256 & DDoS Shield',
      desc: '500+ Gbps inline anti-DDoS scrubbing and client-side credential encryption protect your master lists and payment routes.',
      metric: 'AES-256',
      color: 'from-purple-500 to-indigo-500',
      badge: 'Protected'
    },
    {
      icon: Headphones,
      title: '24/7 Customer Support',
      tagline: 'Direct Telegram & Telegram Desks',
      desc: 'Dedicated Senior Automation Engineers available live at 09:30 AM before Tatkal opens to assist you with configurations.',
      metric: '< 2m Reply',
      color: 'from-amber-500 to-orange-400',
      badge: 'VIP Assistance'
    },
  ];

  return (
    <section className="py-20 bg-[#060a14] border-y border-slate-800/80 relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Heading */}
        <div className="text-center max-w-3xl mx-auto space-y-3 mb-16">
          <div className="inline-flex items-center space-x-1.5 px-3 py-1 rounded-full bg-blue-500/10 border border-blue-500/20 text-blue-400 text-xs font-bold uppercase tracking-wider">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Engineered for Peak Performance</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
            Why Professionals Choose <span className="bg-gradient-to-r from-blue-400 to-cyan-400 bg-clip-text text-transparent">TATKAL SUPER MASTER</span>
          </h2>
          <p className="text-slate-400 text-sm sm:text-base leading-relaxed">
            Built from the ground up to solve the critical challenges of latency, server freezes, and IP detection during high-traffic 10:00 AM & 11:00 AM booking windows.
          </p>
        </div>

        {/* Feature Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((feature, idx) => {
            const Icon = feature.icon;
            return (
              <div
                key={idx}
                className="group relative rounded-2xl bg-slate-900/60 border border-slate-800 p-6 hover:border-blue-500/40 transition-all duration-300 hover:-translate-y-1 hover:shadow-2xl hover:shadow-blue-950/50 flex flex-col justify-between"
              >
                {/* Glow on hover */}
                <div className="absolute top-0 right-0 w-32 h-32 bg-blue-500/5 rounded-full blur-2xl group-hover:bg-blue-500/10 transition-all pointer-events-none" />

                <div className="space-y-4">
                  {/* Top Bar with Icon & Badge */}
                  <div className="flex items-center justify-between">
                    <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${feature.color} p-[1.5px] shadow-lg shadow-blue-950`}>
                      <div className="w-full h-full bg-[#080d1a] rounded-[10px] flex items-center justify-center">
                        <Icon className="w-6 h-6 text-white group-hover:scale-110 transition-transform duration-300" />
                      </div>
                    </div>
                    <span className="text-[11px] font-mono font-bold bg-slate-800/80 text-cyan-300 border border-slate-700/60 px-2.5 py-1 rounded-full">
                      {feature.badge}
                    </span>
                  </div>

                  <div>
                    <h3 className="text-lg font-bold text-white group-hover:text-cyan-300 transition-colors">
                      {feature.title}
                    </h3>
                    <p className="text-xs font-semibold text-blue-400 mt-0.5 font-mono">
                      {feature.tagline}
                    </p>
                  </div>

                  <p className="text-xs sm:text-sm text-slate-400 leading-relaxed">
                    {feature.desc}
                  </p>
                </div>

                {/* Bottom Metric Pill */}
                <div className="mt-6 pt-4 border-t border-slate-800/80 flex items-center justify-between text-xs">
                  <span className="text-slate-400 font-medium">Performance SLA</span>
                  <span className="font-mono font-extrabold text-white text-sm bg-slate-900 px-2 py-0.5 rounded border border-slate-800">
                    {feature.metric}
                  </span>
                </div>
              </div>
            );
          })}
        </div>

      </div>
    </section>
  );
};
