import React, { useState } from 'react';
import { DATACENTER_NODES } from '../../data/mockData';
import { Server, Activity, Globe, Shield, RefreshCw, Zap, CheckCircle2 } from 'lucide-react';
import { useApp } from '../../context/AppContext';

export const LiveInfrastructure: React.FC = () => {
  const { setCurrentPage } = useApp();
  const [selectedNode, setSelectedNode] = useState(DATACENTER_NODES[0]);
  const [isTesting, setIsTesting] = useState(false);
  const [liveNodes, setLiveNodes] = useState(DATACENTER_NODES);

  const runLatencyTest = () => {
    setIsTesting(true);
    setTimeout(() => {
      setLiveNodes(prev => prev.map(node => ({
        ...node,
        latencyMs: parseFloat((node.latencyMs * (0.95 + Math.random() * 0.1)).toFixed(2))
      })));
      setIsTesting(false);
    }, 1200);
  };

  return (
    <section className="py-20 bg-[#050913] border-b border-slate-800/80 relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-4">
          <div className="space-y-2">
            <div className="inline-flex items-center space-x-1.5 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs font-bold uppercase tracking-wider">
              <Activity className="w-3.5 h-3.5" />
              <span>Global Tier-4 Carrier Infrastructure</span>
            </div>
            <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
              Real-Time Datacenter Latency Map
            </h2>
            <p className="text-slate-400 text-sm max-w-xl">
              Equinix, CtrlS, and Nesco datacenter nodes with direct high-capacity optical peering to Indian Railways core gateway routers.
            </p>
          </div>

          <button
            onClick={runLatencyTest}
            disabled={isTesting}
            className="self-start md:self-auto px-4 py-2.5 bg-slate-900 hover:bg-slate-800 border border-slate-700 rounded-xl text-xs font-bold text-slate-200 flex items-center space-x-2 transition-all active:scale-95"
          >
            <RefreshCw className={`w-4 h-4 text-cyan-400 ${isTesting ? 'animate-spin' : ''}`} />
            <span>{isTesting ? 'Running Live Ping Test...' : 'Test Network Ping Now'}</span>
          </button>
        </div>

        {/* Interactive Grid & Telemetry */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          
          {/* Datacenter Nodes List */}
          <div className="lg:col-span-5 space-y-3">
            {liveNodes.map((node) => {
              const isSelected = selectedNode.id === node.id;
              return (
                <div
                  key={node.id}
                  onClick={() => setSelectedNode(node)}
                  className={`p-4 rounded-xl border transition-all cursor-pointer flex items-center justify-between ${
                    isSelected 
                      ? 'bg-blue-600/15 border-blue-500/60 shadow-lg shadow-blue-950/80' 
                      : 'bg-slate-900/60 border-slate-800 hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-center space-x-3">
                    <div className={`w-9 h-9 rounded-lg flex items-center justify-center ${
                      isSelected ? 'bg-blue-600 text-white' : 'bg-slate-800 text-slate-400'
                    }`}>
                      <Server className="w-4 h-4" />
                    </div>
                    <div>
                      <div className="flex items-center space-x-2">
                        <span className="text-xs font-bold text-white">{node.city}</span>
                        {node.city.includes('Mumbai') && (
                          <span className="text-[9px] bg-cyan-500/20 text-cyan-400 border border-cyan-500/30 px-1.5 py-0.2 rounded font-mono font-bold">
                            PRIMARY
                          </span>
                        )}
                      </div>
                      <span className="text-[11px] text-slate-400">{node.country} • {node.bandwidthGbps} Gbps Uplink</span>
                    </div>
                  </div>

                  <div className="text-right">
                    <div className="flex items-center space-x-1 justify-end font-mono">
                      <span className={`text-sm font-extrabold ${node.latencyMs < 5 ? 'text-emerald-400' : 'text-cyan-400'}`}>
                        {node.latencyMs}
                      </span>
                      <span className="text-[10px] text-slate-400">ms</span>
                    </div>
                    <span className="text-[10px] text-emerald-400 flex items-center justify-end space-x-1">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                      <span>{node.status}</span>
                    </span>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Detailed Selected Node Telemetry Card */}
          <div className="lg:col-span-7">
            <div className="rounded-2xl bg-gradient-to-b from-[#0d1527] to-[#070b16] border border-blue-500/30 p-6 sm:p-8 space-y-6 shadow-2xl shadow-blue-950/90 relative overflow-hidden">
              <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-slate-800">
                <div>
                  <span className="text-xs font-bold text-blue-400 uppercase tracking-wider block">Selected Core Router Node</span>
                  <h3 className="text-xl font-extrabold text-white">{selectedNode.city}</h3>
                </div>
                <div className="px-3 py-1.5 bg-emerald-500/15 border border-emerald-500/30 rounded-xl flex items-center space-x-2 text-xs font-mono font-bold text-emerald-400">
                  <Activity className="w-4 h-4 animate-pulse" />
                  <span>SLA HEALTH: 99.999%</span>
                </div>
              </div>

              {/* Specs Grid */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-xs font-mono">
                <div className="p-3 bg-slate-900/80 rounded-xl border border-slate-800 space-y-1">
                  <span className="text-[10px] text-slate-400 uppercase block">Round-Trip Ping</span>
                  <div className="text-lg font-bold text-cyan-400">{selectedNode.latencyMs} ms</div>
                  <span className="text-[10px] text-emerald-400">Ultra-Low Jitter</span>
                </div>
                <div className="p-3 bg-slate-900/80 rounded-xl border border-slate-800 space-y-1">
                  <span className="text-[10px] text-slate-400 uppercase block">Port Capacity</span>
                  <div className="text-lg font-bold text-white">{selectedNode.bandwidthGbps} Gbps</div>
                  <span className="text-[10px] text-slate-400">Redundant Fiber</span>
                </div>
                <div className="p-3 bg-slate-900/80 rounded-xl border border-slate-800 space-y-1">
                  <span className="text-[10px] text-slate-400 uppercase block">Packet Loss</span>
                  <div className="text-lg font-bold text-emerald-400">0.00%</div>
                  <span className="text-[10px] text-slate-400">BGP4 Route Tuned</span>
                </div>
                <div className="p-3 bg-slate-900/80 rounded-xl border border-slate-800 space-y-1">
                  <span className="text-[10px] text-slate-400 uppercase block">Anti-DDoS</span>
                  <div className="text-lg font-bold text-purple-400">500 Gbps</div>
                  <span className="text-[10px] text-slate-400">Always Active</span>
                </div>
              </div>

              {/* Live Trace Benchmark Log */}
              <div className="p-4 bg-black/70 rounded-xl border border-slate-800/80 font-mono text-[11px] space-y-1 text-slate-300">
                <div className="text-slate-400 pb-1 border-b border-slate-800/60 flex items-center justify-between">
                  <span>Traceroute Hop to IRCTC Master Core (103.138.8.10)</span>
                  <span className="text-emerald-400 font-bold">OPTIMAL PATH</span>
                </div>
                <div>1. 10.0.0.1 (TSM Core Gateway) &lt;0.2ms</div>
                <div>2. 103.145.78.1 (NIXI Mumbai Optical Peering) 0.6ms</div>
                <div className="text-cyan-400 font-bold">3. 103.138.8.10 (Railway Gateway Destination) {selectedNode.latencyMs}ms [0% Jitter]</div>
              </div>

              <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-2">
                <p className="text-xs text-slate-400">
                  Deploying on our Mumbai node gives you the fastest physical proximity to the railway reservation servers in the country.
                </p>
                <button
                  onClick={() => {
                    setCurrentPage('vps-hosting');
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                  className="w-full sm:w-auto px-5 py-2.5 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-bold shrink-0 transition-all shadow-lg shadow-blue-900/40"
                >
                  Deploy VPS on This Node
                </button>
              </div>
            </div>
          </div>

        </div>

      </div>
    </section>
  );
};
