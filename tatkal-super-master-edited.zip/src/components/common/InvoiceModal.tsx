import React from 'react';
import { useApp } from '../../context/AppContext';
import { X, Printer, Download, CheckCircle2, ShieldCheck, Zap } from 'lucide-react';

export const InvoiceModal: React.FC = () => {
  const { selectedOrderForInvoice, setSelectedOrderForInvoice, formatPrice, currency } = useApp();

  if (!selectedOrderForInvoice) return null;

  const order = selectedOrderForInvoice;

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/85 backdrop-blur-md flex items-center justify-center p-4">
      <div 
        id="tax-invoice-container"
        className="relative w-full max-w-3xl bg-[#090e1a] border border-blue-500/40 rounded-2xl shadow-2xl shadow-blue-950/90 overflow-hidden my-8"
      >
        {/* Top Control Bar */}
        <div className="bg-slate-900 px-6 py-3 border-b border-slate-800 flex items-center justify-between print:hidden">
          <div className="flex items-center space-x-2 text-xs text-slate-300">
            <span className="font-bold text-white">Official Tax Invoice & Receipt</span>
            <span className="text-slate-500">•</span>
            <span className="font-mono text-cyan-400">{order.orderNumber}</span>
          </div>
          <div className="flex items-center space-x-2">
            <button
              onClick={handlePrint}
              className="px-3 py-1.5 bg-blue-600 hover:bg-blue-500 text-white rounded-lg text-xs font-semibold flex items-center space-x-1.5"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print / PDF</span>
            </button>
            <button
              onClick={() => setSelectedOrderForInvoice(null)}
              className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Invoice Body */}
        <div className="p-8 space-y-8 bg-[#090e1a] text-slate-200 print:bg-white print:text-black">
          {/* Header */}
          <div className="flex flex-col sm:flex-row justify-between items-start gap-4 pb-6 border-b border-slate-800 print:border-gray-200">
            <div>
              <div className="flex items-center space-x-2">
                <div className="w-9 h-9 rounded-lg bg-blue-600 flex items-center justify-center text-white font-bold">
                  <Zap className="w-5 h-5" />
                </div>
                <div>
                  <h2 className="text-xl font-extrabold text-white print:text-black">TATKAL SUPER MASTER</h2>
                  <p className="text-xs text-slate-400 print:text-gray-600">Enterprise VPS & Tatkal Automation Solutions</p>
                </div>
              </div>
              <div className="mt-3 text-xs text-slate-400 print:text-gray-600 space-y-0.5">
                <p>Nesco IT Park, Western Express Hwy, Goregaon</p>
                <p>Mumbai, Maharashtra 400063, India</p>
                <p>GSTIN: 27AABCT8921M1ZX</p>
                <p>support@tatkalsupermaster.com</p>
              </div>
            </div>

            <div className="text-left sm:text-right space-y-1 text-xs">
              <div className="inline-block px-3 py-1 bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 rounded-full font-bold text-[11px] mb-1">
                PAID & FULFILLED
              </div>
              <p className="text-sm font-bold text-white print:text-black">INVOICE #: <span className="font-mono text-cyan-400 print:text-black">{order.orderNumber}</span></p>
              <p className="text-slate-400 print:text-gray-600">Date: {order.date}</p>
              <p className="text-slate-400 print:text-gray-600">Txn Ref: <span className="font-mono">{order.transactionId}</span></p>
              <p className="text-slate-400 print:text-gray-600">Payment: <span className="uppercase font-semibold text-slate-200 print:text-black">{order.paymentMethod}</span></p>
            </div>
          </div>

          {/* Billed To */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
            <div className="p-4 bg-slate-900/60 rounded-xl border border-slate-800 print:bg-gray-50 print:border-gray-200">
              <p className="font-bold text-slate-400 print:text-gray-500 uppercase tracking-wider text-[10px]">Billed To</p>
              <p className="text-sm font-bold text-white print:text-black mt-1">{order.customerName}</p>
              <p className="text-slate-300 print:text-gray-700">{order.customerEmail}</p>
              <p className="text-slate-400 print:text-gray-600">{order.customerPhone}</p>
            </div>

            <div className="p-4 bg-slate-900/60 rounded-xl border border-slate-800 print:bg-gray-50 print:border-gray-200">
              <p className="font-bold text-slate-400 print:text-gray-500 uppercase tracking-wider text-[10px]">Service Delivery Node</p>
              <p className="text-sm font-bold text-white print:text-black mt-1">Mumbai MB2 / High-Speed Cloud Node</p>
              <p className="text-slate-300 print:text-gray-700 font-mono">
                {order.provisionedCredentials?.ip ? `Host: ${order.provisionedCredentials.ip}` : 'Auto-Assigned Cloud Cluster'}
              </p>
              <p className="text-emerald-400 print:text-green-700 font-semibold">Active & Verified SLA 99.99%</p>
            </div>
          </div>

          {/* Itemized Table */}
          <div className="border border-slate-800 rounded-xl overflow-hidden print:border-gray-200">
            <table className="w-full text-xs text-left">
              <thead className="bg-slate-900 text-slate-400 font-bold uppercase print:bg-gray-100 print:text-gray-700">
                <tr>
                  <th className="p-3">Description</th>
                  <th className="p-3 text-center">Billing Cycle</th>
                  <th className="p-3 text-center">Qty</th>
                  <th className="p-3 text-right">Unit Price</th>
                  <th className="p-3 text-right">Amount</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800 print:divide-gray-200">
                {order.items.map((item, idx) => (
                  <tr key={idx} className="hover:bg-slate-900/30">
                    <td className="p-3">
                      <div className="font-bold text-white print:text-black">{item.planName}</div>
                      <div className="text-[11px] text-slate-400 print:text-gray-600">
                        Category: {item.category} • Instant Node Activation Included
                      </div>
                    </td>
                    <td className="p-3 text-center uppercase text-slate-300 print:text-gray-700">{item.billingCycle}</td>
                    <td className="p-3 text-center text-slate-300 print:text-gray-700">{item.quantity}</td>
                    <td className="p-3 text-right text-slate-300 print:text-gray-700">
                      {order.currency === 'USD' ? `$${item.price}` : `₹${item.price.toLocaleString('en-IN')}`}
                    </td>
                    <td className="p-3 text-right font-bold text-white print:text-black">
                      {order.currency === 'USD' ? `$${item.price * item.quantity}` : `₹${(item.price * item.quantity).toLocaleString('en-IN')}`}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Total Summary */}
          <div className="flex justify-end">
            <div className="w-full sm:w-72 space-y-2 text-xs">
              <div className="flex justify-between text-slate-400 print:text-gray-600">
                <span>Subtotal:</span>
                <span className="font-mono">
                  {order.currency === 'USD' ? `$${order.subtotal}` : `₹${order.subtotal.toLocaleString('en-IN')}`}
                </span>
              </div>
              {order.discount > 0 && (
                <div className="flex justify-between text-emerald-400 print:text-green-600 font-semibold">
                  <span>Discount ({order.couponApplied || 'Promo'}):</span>
                  <span className="font-mono">
                    - {order.currency === 'USD' ? `$${order.discount}` : `₹${order.discount.toLocaleString('en-IN')}`}
                  </span>
                </div>
              )}
              <div className="flex justify-between text-slate-400 print:text-gray-600">
                <span>GST (18% inclusive / subsidized):</span>
                <span className="font-mono">₹0.00</span>
              </div>
              <div className="pt-2 border-t border-slate-800 print:border-gray-300 flex justify-between text-sm font-extrabold text-white print:text-black">
                <span>Total Paid:</span>
                <span className="font-mono text-cyan-400 print:text-black text-base">
                  {order.currency === 'USD' ? `$${order.total}` : `₹${order.total.toLocaleString('en-IN')}`}
                </span>
              </div>
            </div>
          </div>

          {/* Footer Note */}
          <div className="pt-6 border-t border-slate-800 print:border-gray-200 text-center text-xs text-slate-500 print:text-gray-500">
            <p>Thank you for choosing TATKAL SUPER MASTER. This is a computer-generated tax invoice and requires no physical signature.</p>
            <p className="mt-1">For renewal or 24/7 technical queries, contact support@tatkalsupermaster.com or Telegram: +91 98765 43210</p>
          </div>
        </div>
      </div>
    </div>
  );
};
