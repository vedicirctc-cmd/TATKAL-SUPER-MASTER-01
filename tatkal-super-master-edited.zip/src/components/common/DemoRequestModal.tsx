import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { X, Play, Clock, Sparkles, CheckCircle2, ShieldAlert } from 'lucide-react';

export const DemoRequestModal: React.FC = () => {
  const { isDemoModalOpen, setIsDemoModalOpen, addToast } = useApp();
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [preferredSlot, setPreferredSlot] = useState('09:45 AM (Pre-Tatkal AC Slot)');
  const [isSubmitted, setIsSubmitted] = useState(false);

  if (!isDemoModalOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !phone) {
      addToast('error', 'Fields Required', 'Please provide your name and Telegram number.');
      return;
    }

    setIsSubmitted(true);
    addToast('success', 'Demo Scheduled!', 'Our Senior Tech Executive will connect with you via AnyDesk/Telegram 15 mins prior to the slot.');
  };

  const handleClose = () => {
    setIsDemoModalOpen(false);
    setIsSubmitted(false);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
      <div className="relative w-full max-w-lg bg-[#090e1a] border border-blue-500/40 rounded-2xl shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="bg-gradient-to-r from-blue-900 to-indigo-900 px-6 py-4 border-b border-blue-500/20 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 rounded-lg bg-blue-500/20 flex items-center justify-center text-cyan-400">
              <Play className="w-4 h-4 fill-cyan-400" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white">Book a Live 1-on-1 Software Demo</h3>
              <p className="text-xs text-blue-200">See Tatkal Super Master v4.8 in action with live simulated 10:00 AM booking</p>
            </div>
          </div>
          <button onClick={handleClose} className="p-1 rounded text-slate-400 hover:text-white">
            <X className="w-5 h-5" />
          </button>
        </div>

        {isSubmitted ? (
          <div className="p-6 text-center space-y-4">
            <div className="w-14 h-14 bg-emerald-500/20 border border-emerald-500/40 rounded-full flex items-center justify-center mx-auto text-emerald-400">
              <CheckCircle2 className="w-8 h-8" />
            </div>
            <h4 className="text-lg font-bold text-white">Demo Confirmed for {preferredSlot}!</h4>
            <p className="text-xs text-slate-400">
              We have dispatched your VIP Demo room credentials and AnyDesk screen share guide to <strong className="text-white">{phone}</strong> on Telegram.
            </p>
            <button
              onClick={handleClose}
              className="w-full py-2.5 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-bold transition-all"
            >
              Done
            </button>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="p-6 space-y-4 text-xs text-slate-300">
            <div className="p-3 bg-blue-950/40 border border-blue-800/40 rounded-xl space-y-1">
              <div className="font-bold text-cyan-300 flex items-center space-x-1">
                <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                <span>What you will witness in the demo:</span>
              </div>
              <ul className="list-disc list-inside text-[11px] text-slate-300 space-y-0.5">
                <li>Under 0.4 second automatic form autofill</li>
                <li>Zero-delay AI neural captcha solving engine</li>
                <li>Sub-2ms Mumbai VPS network throughput test</li>
                <li>Auto-bank OTP interception on test gateway</li>
              </ul>
            </div>

            <div>
              <label className="block text-slate-400 mb-1">Your Full Name</label>
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g. Vikram Sharma"
                className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2.5 text-white focus:outline-none focus:border-blue-500"
              />
            </div>

            <div>
              <label className="block text-slate-400 mb-1">Telegram Number (For AnyDesk Link)</label>
              <input
                type="tel"
                required
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="+91 98765 43210"
                className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2.5 text-white focus:outline-none focus:border-blue-500"
              />
            </div>

            <div>
              <label className="block text-slate-400 mb-1">Preferred Time Slot</label>
              <select
                value={preferredSlot}
                onChange={(e) => setPreferredSlot(e.target.value)}
                className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2.5 text-white focus:outline-none focus:border-blue-500"
              >
                <option value="09:45 AM (Pre-Tatkal AC Slot)">09:45 AM (Pre-Tatkal AC Slot - High Demand)</option>
                <option value="10:45 AM (Pre-Tatkal Non-AC Slot)">10:45 AM (Pre-Tatkal Non-AC Slot)</option>
                <option value="02:00 PM (Afternoon Detailed Walkthrough)">02:00 PM (Afternoon Detailed Walkthrough)</option>
                <option value="06:00 PM (Evening Agency Q&A)">06:00 PM (Evening Agency Q&A)</option>
              </select>
            </div>

            <button
              type="submit"
              className="w-full py-3 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white rounded-xl font-bold shadow-lg shadow-blue-900/40 transition-all flex items-center justify-center space-x-2"
            >
              <Clock className="w-4 h-4" />
              <span>Confirm Free Demo Request</span>
            </button>
          </form>
        )}
      </div>
    </div>
  );
};
