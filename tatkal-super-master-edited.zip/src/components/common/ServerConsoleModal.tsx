import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { X, Terminal, Play, RotateCw, Square, Shield, Check, Copy } from 'lucide-react';

export const ServerConsoleModal: React.FC = () => {
  const { selectedServiceForConsole, setSelectedServiceForConsole, rebootService, addToast } = useApp();
  const [logs, setLogs] = useState<string[]>([]);
  const [commandInput, setCommandInput] = useState('');

  const service = selectedServiceForConsole;

  useEffect(() => {
    if (service) {
      setLogs([
        `[${new Date().toLocaleTimeString()}] TSM-Hypervisor: Initializing remote console session for ${service.serviceName}...`,
        `[${new Date().toLocaleTimeString()}] Host Node: Mumbai Equinix MB2 Carrier Hotel (CtrlS)`,
        `[${new Date().toLocaleTimeString()}] Network Interface: eth0 (10Gbps Uplink - 0% packet loss)`,
        `[${new Date().toLocaleTimeString()}] IRCTC Gateway Ping: 1.42ms (TCP handshake latency: 0.8ms)`,
        `[${new Date().toLocaleTimeString()}] Anti-DDoS Filter: Enabled & Shielding (500Gbps Scrubbing)`,
        `[${new Date().toLocaleTimeString()}] RDP Service: LISTENING on port ${service.port || 3389}`,
        `[${new Date().toLocaleTimeString()}] TSM Automation Daemon v4.8: RUNNING (PID 4892)`,
        `[${new Date().toLocaleTimeString()}] Session ready. Type 'help' or 'status' for diagnostic queries.`
      ]);
    }
  }, [service]);

  if (!service) return null;

  const handleCommand = (e: React.FormEvent) => {
    e.preventDefault();
    if (!commandInput.trim()) return;

    const cmd = commandInput.trim().toLowerCase();
    const time = new Date().toLocaleTimeString();
    const newLogs = [...logs, `> ${commandInput}`];

    if (cmd === 'help') {
      newLogs.push(
        `[${time}] Available commands:`,
        `  status      - Display current server CPU, RAM, & Network telemetry`,
        `  ping-irctc  - Execute live low-latency ICMP ping test to Indian Railway Gateways`,
        `  restart-rdp - Restart Remote Desktop service`,
        `  clear       - Clear terminal screen`,
        `  reboot      - Send hardware reboot signal`
      );
    } else if (cmd === 'status') {
      newLogs.push(
        `[${time}] SYSTEM STATUS: HEALTHY`,
        `  CPU Load: 14.2% (AMD EPYC 4.2GHz 4-Cores)`,
        `  RAM Usage: 3.8GB / 8.0GB (47.5%)`,
        `  Disk Read/Write: NVMe Gen4 (4,820 MB/s)`,
        `  Public IPv4: ${service.ipAddress || '103.145.78.112'}`
      );
    } else if (cmd === 'ping-irctc') {
      newLogs.push(
        `[${time}] PING irctc.co.in (103.138.8.10) 56(84) bytes of data.`,
        `[${time}] 64 bytes from 103.138.8.10: icmp_seq=1 ttl=58 time=1.38 ms`,
        `[${time}] 64 bytes from 103.138.8.10: icmp_seq=2 ttl=58 time=1.42 ms`,
        `[${time}] 64 bytes from 103.138.8.10: icmp_seq=3 ttl=58 time=1.35 ms`,
        `[${time}] --- irctc.co.in ping statistics --- 0% packet loss, rtt min/avg/max = 1.35/1.38/1.42 ms (OPTIMAL)`
      );
    } else if (cmd === 'restart-rdp') {
      newLogs.push(
        `[${time}] Stopping TermService... [OK]`,
        `[${time}] Restarting Remote Desktop Gateway... [OK]`,
        `[${time}] Listening on 0.0.0.0:${service.port || 3389} with TLS 1.3 encryption.`
      );
    } else if (cmd === 'reboot') {
      rebootService(service.id);
      newLogs.push(`[${time}] HARDWARE REBOOT SIGNAL TRIGGERED. Server rebooting...`);
    } else if (cmd === 'clear') {
      setLogs([`[${time}] Terminal cleared.`]);
      setCommandInput('');
      return;
    } else {
      newLogs.push(`[${time}] Command not recognized: '${cmd}'. Type 'help' for available commands.`);
    }

    setLogs(newLogs);
    setCommandInput('');
  };

  const handleCopyCredentials = () => {
    const text = `IP: ${service.ipAddress || '103.145.78.112'}:${service.port || 3389}\nUser: ${service.username || 'Administrator'}\nPass: ${service.password || 'TSM_WinVps_#2026Secure!'}`;
    navigator.clipboard.writeText(text);
    addToast('info', 'Credentials Copied', 'RDP connection details copied to clipboard.');
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/85 backdrop-blur-md flex items-center justify-center p-4">
      <div className="relative w-full max-w-3xl bg-[#090e1a] border border-blue-500/40 rounded-2xl shadow-2xl overflow-hidden font-mono text-xs">
        {/* Top Header */}
        <div className="bg-slate-900 px-6 py-3 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center space-x-2 text-slate-300">
            <Terminal className="w-4 h-4 text-cyan-400" />
            <span className="font-bold text-white">Live Web Console / Terminal</span>
            <span className="text-slate-500">•</span>
            <span className="text-emerald-400 font-semibold">{service.serviceName}</span>
          </div>

          <div className="flex items-center space-x-2">
            <button
              onClick={handleCopyCredentials}
              className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded text-[11px] font-sans flex items-center space-x-1"
            >
              <Copy className="w-3 h-3" />
              <span>Copy RDP Details</span>
            </button>
            <button
              onClick={() => rebootService(service.id)}
              className="px-2.5 py-1 bg-amber-600/20 text-amber-400 border border-amber-500/30 hover:bg-amber-600/30 rounded text-[11px] font-sans flex items-center space-x-1"
            >
              <RotateCw className="w-3 h-3" />
              <span>Reboot Node</span>
            </button>
            <button
              onClick={() => setSelectedServiceForConsole(null)}
              className="p-1 rounded text-slate-400 hover:text-white"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Terminal Output Area */}
        <div className="p-4 bg-black/90 text-emerald-400 h-80 overflow-y-auto space-y-1 font-mono text-xs select-text">
          {logs.map((log, i) => (
            <div key={i} className={`${log.startsWith('>') ? 'text-cyan-300 font-bold' : ''}`}>
              {log}
            </div>
          ))}
        </div>

        {/* Input Bar */}
        <form onSubmit={handleCommand} className="p-3 bg-slate-950 border-t border-slate-800 flex items-center space-x-2">
          <span className="text-cyan-400 font-bold">{service.username || 'root'}@tsm-node:~$</span>
          <input
            type="text"
            value={commandInput}
            onChange={(e) => setCommandInput(e.target.value)}
            placeholder="Type 'help', 'status', 'ping-irctc', or 'reboot'..."
            className="w-full bg-transparent text-white focus:outline-none font-mono text-xs placeholder-slate-600"
          />
          <button
            type="submit"
            className="px-3 py-1 bg-blue-600 hover:bg-blue-500 text-white rounded text-[11px] font-sans font-bold"
          >
            Execute
          </button>
        </form>
      </div>
    </div>
  );
};
