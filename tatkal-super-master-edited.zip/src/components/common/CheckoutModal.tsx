import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { 
  X, 
  ShieldCheck, 
  Zap, 
  QrCode, 
  CreditCard, 
  Smartphone, 
  Building, 
  Sparkles, 
  Lock, 
  Check, 
  Tag, 
  Copy, 
  Download, 
  FileText,
  Clock,
  ArrowRight,
  Package,
  AlertCircle,
  CheckCircle2,
  Send,
  Globe,
  Server,
  RefreshCw
} from 'lucide-react';
import { Order } from '../../types';

export const CheckoutModal: React.FC = () => {
  const { 
    isCheckoutOpen, 
    closeCheckout, 
    selectedPlanForCheckout, 
    products,
    currency, 
    formatPrice,
    user,
    appliedCoupon,
    applyCoupon,
    removeCoupon,
    calculateDiscount,
    completeOrder,
    setSelectedOrderForInvoice,
    setCurrentPage,
    addToast
  } = useApp();

  const [paymentGateway, setPaymentGateway] = useState<'razorpay' | 'phonepe' | 'cashfree' | 'payu' | 'upi_qr' | 'wallet'>('razorpay');
  const [paymentSubMethod, setPaymentSubMethod] = useState<'upi' | 'card' | 'netbanking' | 'wallet'>('upi');
  
  const [couponInput, setCouponInput] = useState('');
  const [couponError, setCouponError] = useState('');
  
  const [name, setName] = useState(user?.name || '');
  const [email, setEmail] = useState(user?.email || '');
  const [phone, setPhone] = useState(user?.phone || '+91 ');
  
  // Card inputs
  const [cardNumber, setCardNumber] = useState('4532 8901 2345 6789');
  const [cardExpiry, setCardExpiry] = useState('08/28');
  const [cardCvv, setCardCvv] = useState('892');
  const [selectedBank, setSelectedBank] = useState('HDFC Bank');
  const [upiVpa, setUpiVpa] = useState('');

  // Processing state
  const [isProcessing, setIsProcessing] = useState(false);
  const [processingStep, setProcessingStep] = useState(0);
  const [completedOrder, setCompletedOrder] = useState<Order | null>(null);

  // Sync user details on open
  useEffect(() => {
    if (user) {
      if (!name) setName(user.name);
      if (!email) setEmail(user.email);
      if (phone === '+91 ' || !phone) setPhone(user.phone || '+91 98765 43210');
    }
  }, [user, isCheckoutOpen]);

  if (!isCheckoutOpen || !selectedPlanForCheckout) return null;

  // Grab the latest real-time stock from products state
  const liveProduct = products.find(p => p.id === selectedPlanForCheckout.id) || selectedPlanForCheckout;
  const isOutOfStock = liveProduct.stockQuantity <= 0;

  const basePrice = currency === 'USD' ? liveProduct.priceUSD : liveProduct.priceINR;
  const discount = calculateDiscount(basePrice);
  const finalPrice = Math.max(0, basePrice - discount);

  const handleApplyCoupon = (e: React.FormEvent) => {
    e.preventDefault();
    if (!couponInput) return;
    const res = applyCoupon(couponInput);
    if (!res.success) {
      setCouponError(res.message);
    } else {
      setCouponError('');
      setCouponInput('');
    }
  };

  const handlePay = () => {
    if (isOutOfStock) {
      addToast('error', 'Out of Stock', 'This product is currently out of stock. Please select another plan.');
      return;
    }
    if (!email || !email.includes('@')) {
      addToast('error', 'Email Required', 'Please enter a valid email for digital license & invoice delivery.');
      return;
    }
    if (!phone || phone.length < 8) {
      addToast('error', 'Phone Required', 'Please enter your Telegram mobile number for instant license dispatch.');
      return;
    }

    if (paymentGateway === 'wallet' && (!user || user.walletBalance < finalPrice)) {
      addToast('error', 'Insufficient Wallet Balance', `Your wallet has ₹${user?.walletBalance || 0}. You need ₹${finalPrice}.`);
      return;
    }

    setIsProcessing(true);
    setProcessingStep(1); // Verifying payment

    setTimeout(() => {
      setProcessingStep(2); // Auto reducing stock in DB
    }, 800);

    setTimeout(() => {
      setProcessingStep(3); // Generating digital license / VPS credentials
    }, 1500);

    setTimeout(() => {
      try {
        const order = completeOrder({
          method: paymentGateway === 'wallet' ? 'wallet' : 
                  paymentGateway === 'upi_qr' ? 'upi' :
                  paymentGateway === 'phonepe' ? 'phonepe' :
                  paymentGateway === 'cashfree' ? 'cashfree' :
                  paymentGateway === 'payu' ? 'payu' : 'razorpay',
          customerName: name || 'Valued Customer',
          customerEmail: email,
          customerPhone: phone
        });
        setCompletedOrder(order);
      } catch (err: any) {
        addToast('error', 'Payment Failed', err.message || 'Payment processing error');
      } finally {
        setIsProcessing(false);
        setProcessingStep(0);
      }
    }, 2200);
  };

  const handleCopy = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    addToast('info', 'Copied!', `${label} copied to clipboard.`);
  };

  const handleViewInvoice = (order: Order) => {
    setSelectedOrderForInvoice(order);
    closeCheckout();
  };

  const handleGoToDashboard = () => {
    closeCheckout();
    setCurrentPage('dashboard');
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/85 backdrop-blur-md flex items-center justify-center p-4">
      <div 
        id="checkout-modal-container"
        className="relative w-full max-w-2xl bg-[#090e1a] border border-blue-500/30 rounded-2xl shadow-2xl shadow-blue-950/90 overflow-hidden my-6"
      >
        {/* Modal Header */}
        <div className="bg-gradient-to-r from-blue-900/90 via-indigo-900/90 to-slate-900 px-6 py-4 border-b border-blue-500/20 flex items-center justify-between">
          <div className="flex items-center space-x-2.5">
            <div className="w-9 h-9 rounded-xl bg-blue-500/20 border border-blue-500/40 flex items-center justify-center shadow-lg shadow-blue-500/20">
              <Lock className="w-4 h-4 text-cyan-400" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h3 className="text-base font-extrabold text-white">Instant Checkout Gateway</h3>
                <span className="text-[10px] bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 px-2 py-0.5 rounded-full font-mono font-bold flex items-center space-x-1">
                  <Zap className="w-3 h-3" />
                  <span>Auto-Delivery &lt;30s</span>
                </span>
              </div>
              <p className="text-xs text-slate-300">Razorpay / Cashfree / PhonePe / PayU 256-Bit Encrypted</p>
            </div>
          </div>
          <button
            onClick={closeCheckout}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Content - Completed Order View */}
        {completedOrder ? (
          <div className="p-6 space-y-6 text-slate-200 animate-in fade-in zoom-in-95 duration-200">
            <div className="text-center space-y-2">
              <div className="w-16 h-16 bg-emerald-500/20 border border-emerald-500/40 rounded-full flex items-center justify-center mx-auto text-emerald-400 shadow-lg shadow-emerald-500/20">
                <CheckCircle2 className="w-9 h-9" />
              </div>
              <h3 className="text-xl font-black text-white">Payment Verified & Digital Asset Delivered!</h3>
              <p className="text-xs text-slate-400">
                Order <span className="font-mono text-cyan-400 font-bold">{completedOrder.orderNumber}</span> fulfilled successfully. Stock auto-reduced in database.
              </p>
            </div>

            {/* Provisioned Credentials Box */}
            <div className="p-4 rounded-xl bg-slate-900/90 border border-blue-500/30 space-y-3.5 shadow-xl">
              <div className="flex items-center justify-between pb-2 border-b border-slate-800">
                <span className="text-xs font-bold text-white uppercase tracking-wider flex items-center space-x-1.5">
                  <Zap className="w-4 h-4 text-cyan-400" />
                  <span>Auto-Generated Digital Delivery</span>
                </span>
                <span className="text-[10px] font-mono bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 px-2 py-0.5 rounded-full font-bold">
                  Status: Active & Ready
                </span>
              </div>

              {/* License Key for Tatkal Software */}
              {completedOrder.provisionedCredentials?.licenseKey && (
                <div className="space-y-1.5">
                  <label className="text-[11px] font-bold text-slate-300 flex items-center justify-between">
                    <span>Software License Activation Key</span>
                    <span className="text-[10px] text-cyan-400 font-mono">AES-256 Cloud License</span>
                  </label>
                  <div className="flex items-center space-x-2">
                    <input
                      readOnly
                      value={completedOrder.provisionedCredentials.licenseKey}
                      className="w-full font-mono text-xs bg-black/60 border border-slate-700 rounded-lg p-2.5 text-cyan-300 select-all font-bold"
                    />
                    <button
                      onClick={() => handleCopy(completedOrder.provisionedCredentials!.licenseKey!, 'License Key')}
                      className="px-3.5 py-2.5 bg-blue-600 hover:bg-blue-500 text-white rounded-lg text-xs font-bold flex items-center space-x-1 shadow-lg shadow-blue-900/30 shrink-0"
                    >
                      <Copy className="w-3.5 h-3.5" />
                      <span>Copy</span>
                    </button>
                  </div>
                </div>
              )}

              {/* Software Download Link */}
              {completedOrder.provisionedCredentials?.downloadLink && (
                <div className="pt-1">
                  <a
                    href={completedOrder.provisionedCredentials.downloadLink}
                    target="_blank"
                    rel="noreferrer"
                    className="w-full py-2.5 bg-gradient-to-r from-blue-600 via-indigo-600 to-cyan-500 hover:from-blue-500 hover:to-cyan-400 text-white rounded-xl text-xs font-black flex items-center justify-center space-x-2 shadow-lg shadow-blue-900/40"
                  >
                    <Download className="w-4 h-4" />
                    <span>Download Software Setup Package (.EXE)</span>
                  </a>
                </div>
              )}

              {/* VPS Credentials */}
              {completedOrder.provisionedCredentials?.ip && (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs font-mono">
                  <div className="p-2.5 bg-black/50 rounded-lg border border-slate-800">
                    <span className="text-[10px] text-slate-400 block font-sans">Server IP & Port:</span>
                    <span className="text-cyan-300 font-bold">{completedOrder.provisionedCredentials.ip}:{completedOrder.provisionedCredentials.port || 3389}</span>
                  </div>
                  <div className="p-2.5 bg-black/50 rounded-lg border border-slate-800">
                    <span className="text-[10px] text-slate-400 block font-sans">Login User / Pass:</span>
                    <span className="text-emerald-400 font-bold">{completedOrder.provisionedCredentials.username} / {completedOrder.provisionedCredentials.password}</span>
                  </div>
                </div>
              )}

              {/* Proxy Credentials */}
              {completedOrder.provisionedCredentials?.proxyString && (
                <div className="space-y-1">
                  <label className="text-[11px] text-slate-400">SOCKS5 Proxy String (IP:Port:User:Pass)</label>
                  <input
                    readOnly
                    value={completedOrder.provisionedCredentials.proxyString}
                    className="w-full font-mono text-xs bg-black/50 border border-slate-700 rounded-lg p-2 text-emerald-400 select-all"
                  />
                </div>
              )}

              {/* Dispatch notification log */}
              <div className="p-3 bg-emerald-950/30 border border-emerald-500/20 rounded-lg space-y-1 text-[11px] text-slate-300">
                <div className="flex items-center space-x-1.5 text-emerald-400 font-bold">
                  <Send className="w-3.5 h-3.5" />
                  <span>Instant Multi-Channel Dispatch Logs:</span>
                </div>
                <ul className="space-y-0.5 text-[10px] text-slate-400 font-mono">
                  <li>✓ Email dispatched to <strong className="text-white">{completedOrder.customerEmail}</strong></li>
                  <li>✓ Telegram payload sent to <strong className="text-white">{completedOrder.customerPhone}</strong></li>
                  <li>✓ Service container mounted to Client Dashboard</li>
                </ul>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="grid grid-cols-2 gap-3">
              <button
                onClick={() => handleViewInvoice(completedOrder)}
                className="py-2.5 px-4 bg-slate-800 hover:bg-slate-700 text-white rounded-xl text-xs font-bold flex items-center justify-center space-x-1.5 transition-all border border-slate-700"
              >
                <FileText className="w-4 h-4 text-blue-400" />
                <span>View GST Tax Invoice</span>
              </button>
              <button
                onClick={handleGoToDashboard}
                className="py-2.5 px-4 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-bold flex items-center justify-center space-x-1.5 transition-all shadow-lg shadow-blue-900/50"
              >
                <span>Go to Client Dashboard</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        ) : (
          /* Main Order Summary & Payment Gateway Form */
          <div className="p-6 space-y-5 text-slate-200">
            {/* Plan Info Card with Stock Alert */}
            <div className="p-4 rounded-xl bg-slate-900/90 border border-slate-800 flex items-start justify-between">
              <div>
                <div className="flex items-center space-x-2">
                  <span className="text-[10px] font-bold uppercase tracking-wider text-blue-400">Selected Product</span>
                  {/* Real-time stock status badge */}
                  {isOutOfStock ? (
                    <span className="text-[10px] bg-red-500/20 text-red-400 border border-red-500/30 px-2 py-0.5 rounded-full font-bold">
                      Out of Stock
                    </span>
                  ) : liveProduct.stockQuantity <= (liveProduct.minStockAlert || 5) ? (
                    <span className="text-[10px] bg-amber-500/20 text-amber-400 border border-amber-500/30 px-2 py-0.5 rounded-full font-bold flex items-center space-x-1">
                      <AlertCircle className="w-3 h-3" />
                      <span>Only {liveProduct.stockQuantity} Units Left!</span>
                    </span>
                  ) : (
                    <span className="text-[10px] bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 px-2 py-0.5 rounded-full font-bold flex items-center space-x-1">
                      <Package className="w-3 h-3" />
                      <span>{liveProduct.stockQuantity} Available in Stock</span>
                    </span>
                  )}
                </div>
                <h4 className="text-base font-extrabold text-white mt-1">{liveProduct.name}</h4>
                <p className="text-xs text-slate-400">{liveProduct.tagline}</p>
                <div className="mt-2 flex items-center space-x-3 text-xs text-emerald-400">
                  <span className="flex items-center space-x-1">
                    <Clock className="w-3.5 h-3.5" />
                    <span>{liveProduct.activationTime}</span>
                  </span>
                  <span className="text-slate-500">•</span>
                  <span className="text-slate-400">Auto-Delivery: <strong>{liveProduct.digitalDeliveryType?.replace('_', ' ').toUpperCase()}</strong></span>
                </div>
              </div>
              <div className="text-right shrink-0">
                <div className="text-lg font-black text-white">
                  {formatPrice(liveProduct.priceINR, liveProduct.priceUSD)}
                </div>
                <span className="text-[10px] text-slate-400">{liveProduct.period}</span>
              </div>
            </div>

            {/* Customer Information Inputs */}
            <div className="space-y-2.5">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-300">1. Instant Delivery Details</h4>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 text-xs">
                <div>
                  <label className="block text-slate-400 mb-1">Your Full Name</label>
                  <input
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="e.g. Rahul Sharma"
                    className="w-full bg-slate-900/90 border border-slate-800 rounded-lg p-2.5 text-white focus:outline-none focus:border-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-slate-400 mb-1">Email (For Invoices & Key)</label>
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="yourname@gmail.com"
                    className="w-full bg-slate-900/90 border border-slate-800 rounded-lg p-2.5 text-white focus:outline-none focus:border-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-slate-400 mb-1">Telegram Mobile No</label>
                  <input
                    type="tel"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="+91 98765 43210"
                    className="w-full bg-slate-900/90 border border-slate-800 rounded-lg p-2.5 text-white focus:outline-none focus:border-blue-500"
                  />
                </div>
              </div>
            </div>

            {/* Payment Gateway Tabs */}
            <div className="space-y-2.5">
              <div className="flex items-center justify-between">
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-300">2. Select Payment Gateway</h4>
                <span className="text-[10px] text-emerald-400 font-mono">0% Gateway Surcharge</span>
              </div>

              {/* Gateway selector buttons */}
              <div className="grid grid-cols-3 sm:grid-cols-6 gap-2">
                <button
                  type="button"
                  onClick={() => { setPaymentGateway('razorpay'); setPaymentSubMethod('upi'); }}
                  className={`p-2 rounded-xl border text-[11px] font-bold flex flex-col items-center justify-center space-y-1 transition-all ${
                    paymentGateway === 'razorpay'
                      ? 'bg-blue-600/20 border-blue-500 text-white shadow-lg shadow-blue-950'
                      : 'bg-slate-900/60 border-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  <CreditCard className="w-4 h-4 text-blue-400" />
                  <span>Razorpay</span>
                </button>

                <button
                  type="button"
                  onClick={() => { setPaymentGateway('phonepe'); setPaymentSubMethod('upi'); }}
                  className={`p-2 rounded-xl border text-[11px] font-bold flex flex-col items-center justify-center space-y-1 transition-all ${
                    paymentGateway === 'phonepe'
                      ? 'bg-purple-600/20 border-purple-500 text-white shadow-lg shadow-purple-950'
                      : 'bg-slate-900/60 border-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  <Smartphone className="w-4 h-4 text-purple-400" />
                  <span>PhonePe</span>
                </button>

                <button
                  type="button"
                  onClick={() => { setPaymentGateway('cashfree'); setPaymentSubMethod('upi'); }}
                  className={`p-2 rounded-xl border text-[11px] font-bold flex flex-col items-center justify-center space-y-1 transition-all ${
                    paymentGateway === 'cashfree'
                      ? 'bg-cyan-600/20 border-cyan-500 text-white shadow-lg shadow-cyan-950'
                      : 'bg-slate-900/60 border-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  <Zap className="w-4 h-4 text-cyan-400" />
                  <span>Cashfree</span>
                </button>

                <button
                  type="button"
                  onClick={() => { setPaymentGateway('payu'); setPaymentSubMethod('upi'); }}
                  className={`p-2 rounded-xl border text-[11px] font-bold flex flex-col items-center justify-center space-y-1 transition-all ${
                    paymentGateway === 'payu'
                      ? 'bg-emerald-600/20 border-emerald-500 text-white shadow-lg shadow-emerald-950'
                      : 'bg-slate-900/60 border-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  <Building className="w-4 h-4 text-emerald-400" />
                  <span>PayU</span>
                </button>

                <button
                  type="button"
                  onClick={() => { setPaymentGateway('upi_qr'); setPaymentSubMethod('upi'); }}
                  className={`p-2 rounded-xl border text-[11px] font-bold flex flex-col items-center justify-center space-y-1 transition-all ${
                    paymentGateway === 'upi_qr'
                      ? 'bg-blue-600/20 border-blue-500 text-white shadow-lg shadow-blue-950'
                      : 'bg-slate-900/60 border-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  <QrCode className="w-4 h-4 text-amber-400" />
                  <span>UPI QR</span>
                </button>

                <button
                  type="button"
                  onClick={() => { setPaymentGateway('wallet'); }}
                  className={`p-2 rounded-xl border text-[11px] font-bold flex flex-col items-center justify-center space-y-1 transition-all ${
                    paymentGateway === 'wallet'
                      ? 'bg-amber-600/20 border-amber-500 text-white shadow-lg shadow-amber-950'
                      : 'bg-slate-900/60 border-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  <Sparkles className="w-4 h-4 text-amber-400" />
                  <span>Wallet ({user ? `₹${user.walletBalance}` : '₹0'})</span>
                </button>
              </div>
            </div>

            {/* Gateway Specific Controls */}
            {paymentGateway === 'razorpay' && (
              <div className="p-3.5 bg-slate-900/90 border border-slate-800 rounded-xl space-y-3">
                <div className="flex items-center justify-between text-xs border-b border-slate-800 pb-2">
                  <span className="font-bold text-white flex items-center space-x-1.5">
                    <span className="w-2 h-2 rounded-full bg-blue-400 animate-pulse"></span>
                    <span>Razorpay Trusted Indian Gateway</span>
                  </span>
                  <div className="flex items-center space-x-1">
                    {['upi', 'card', 'netbanking'].map((sub) => (
                      <button
                        key={sub}
                        type="button"
                        onClick={() => setPaymentSubMethod(sub as any)}
                        className={`px-2.5 py-1 rounded text-[11px] font-bold capitalize ${
                          paymentSubMethod === sub 
                            ? 'bg-blue-600 text-white' 
                            : 'bg-slate-800 text-slate-400 hover:text-white'
                        }`}
                      >
                        {sub}
                      </button>
                    ))}
                  </div>
                </div>

                {paymentSubMethod === 'upi' && (
                  <div className="space-y-2 text-xs">
                    <label className="text-slate-400 block">Enter UPI ID (VPA)</label>
                    <div className="flex space-x-2">
                      <input
                        type="text"
                        value={upiVpa}
                        onChange={(e) => setUpiVpa(e.target.value)}
                        placeholder="e.g. yourname@oksbi or 9876543210@paytm"
                        className="w-full bg-black/50 border border-slate-700 rounded-lg p-2 text-white text-xs focus:outline-none focus:border-blue-500"
                      />
                      <span className="px-3 py-2 bg-slate-800 text-slate-300 rounded-lg text-xs font-mono shrink-0 flex items-center">
                        Auto-Verify
                      </span>
                    </div>
                    <div className="flex items-center space-x-2 pt-1">
                      <span className="text-[10px] text-slate-400">Supported:</span>
                      <span className="text-[10px] text-slate-300 bg-slate-800 px-1.5 py-0.5 rounded">Google Pay</span>
                      <span className="text-[10px] text-slate-300 bg-slate-800 px-1.5 py-0.5 rounded">PhonePe</span>
                      <span className="text-[10px] text-slate-300 bg-slate-800 px-1.5 py-0.5 rounded">Paytm</span>
                      <span className="text-[10px] text-slate-300 bg-slate-800 px-1.5 py-0.5 rounded">CRED</span>
                    </div>
                  </div>
                )}

                {paymentSubMethod === 'card' && (
                  <div className="space-y-2 text-xs">
                    <div>
                      <label className="text-slate-400 block mb-1">Card Number (Visa / Mastercard / RuPay)</label>
                      <input
                        type="text"
                        value={cardNumber}
                        onChange={(e) => setCardNumber(e.target.value)}
                        className="w-full bg-black/50 border border-slate-700 rounded-lg p-2 text-white font-mono"
                      />
                    </div>
                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <label className="text-slate-400 block mb-1">Expiry (MM/YY)</label>
                        <input
                          type="text"
                          value={cardExpiry}
                          onChange={(e) => setCardExpiry(e.target.value)}
                          className="w-full bg-black/50 border border-slate-700 rounded-lg p-2 text-white font-mono"
                        />
                      </div>
                      <div>
                        <label className="text-slate-400 block mb-1">CVV</label>
                        <input
                          type="password"
                          value={cardCvv}
                          onChange={(e) => setCardCvv(e.target.value)}
                          className="w-full bg-black/50 border border-slate-700 rounded-lg p-2 text-white font-mono"
                        />
                      </div>
                    </div>
                  </div>
                )}

                {paymentSubMethod === 'netbanking' && (
                  <div className="space-y-2 text-xs">
                    <label className="text-slate-400 block">Select Your Bank</label>
                    <select
                      value={selectedBank}
                      onChange={(e) => setSelectedBank(e.target.value)}
                      className="w-full bg-black/50 border border-slate-700 rounded-lg p-2 text-white"
                    >
                      <option value="HDFC Bank">HDFC Bank</option>
                      <option value="State Bank of India">State Bank of India (SBI)</option>
                      <option value="ICICI Bank">ICICI Bank</option>
                      <option value="Axis Bank">Axis Bank</option>
                      <option value="Kotak Mahindra Bank">Kotak Mahindra Bank</option>
                      <option value="Punjab National Bank">Punjab National Bank</option>
                    </select>
                  </div>
                )}
              </div>
            )}

            {/* UPI QR Gateway */}
            {paymentGateway === 'upi_qr' && (
              <div className="p-4 bg-slate-900/90 border border-slate-800 rounded-xl flex flex-col sm:flex-row items-center gap-4">
                <div className="bg-white p-2 rounded-lg shadow-inner flex flex-col items-center shrink-0">
                  <div className="w-28 h-28 bg-slate-900 rounded p-1 flex items-center justify-center relative overflow-hidden">
                    <QrCode className="w-24 h-24 text-white" />
                  </div>
                  <span className="text-[9px] font-bold text-slate-800 mt-1 uppercase">Scan with Any UPI App</span>
                </div>
                <div className="space-y-1.5 text-xs">
                  <div className="flex items-center space-x-1.5 text-emerald-400 font-bold">
                    <Check className="w-3.5 h-3.5" />
                    <span>Dynamic Auto-Verifying UPI QR</span>
                  </div>
                  <p className="text-slate-400 text-[11px]">
                    Scan using Google Pay, PhonePe, Paytm, CRED or BHIM. Your payment is automatically captured within 5 seconds.
                  </p>
                  <div className="flex items-center space-x-2 pt-1 font-mono text-[11px] text-slate-300">
                    <span className="text-slate-400">VPA:</span>
                    <span className="text-cyan-400 font-bold">tatkalmaster@icici</span>
                    <button 
                      onClick={() => handleCopy('tatkalmaster@icici', 'UPI VPA')}
                      className="text-blue-400 hover:underline text-[10px]"
                    >
                      Copy VPA
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* PhonePe Gateway Box */}
            {paymentGateway === 'phonepe' && (
              <div className="p-3.5 bg-purple-950/20 border border-purple-500/30 rounded-xl space-y-2 text-xs">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-purple-300">PhonePe Direct UPI PG</span>
                  <span className="text-[10px] bg-purple-500/20 text-purple-300 px-2 py-0.5 rounded">High Success Rate (99.8%)</span>
                </div>
                <p className="text-slate-400 text-[11px]">
                  Seamless app-to-app UPI payment intent. Auto-redirects back with verified token upon biometric authorization.
                </p>
              </div>
            )}

            {/* Cashfree Gateway Box */}
            {paymentGateway === 'cashfree' && (
              <div className="p-3.5 bg-cyan-950/20 border border-cyan-500/30 rounded-xl space-y-2 text-xs">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-cyan-300">Cashfree Auto-Collect Engine</span>
                  <span className="text-[10px] bg-cyan-500/20 text-cyan-300 px-2 py-0.5 rounded">Instant Verification</span>
                </div>
                <p className="text-slate-400 text-[11px]">
                  Supports UPI Auto-Collect, BharatQR, and Instant NetBanking webhooks with sub-second webhook triggers.
                </p>
              </div>
            )}

            {/* PayU Gateway Box */}
            {paymentGateway === 'payu' && (
              <div className="p-3.5 bg-emerald-950/20 border border-emerald-500/30 rounded-xl space-y-2 text-xs">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-emerald-300">PayU Money Enterprise Gateway</span>
                  <span className="text-[10px] bg-emerald-500/20 text-emerald-300 px-2 py-0.5 rounded">3D Secure 2.0</span>
                </div>
                <p className="text-slate-400 text-[11px]">
                  Enterprise-grade high concurrency payment router with zero-downtime multi-acquirer failover.
                </p>
              </div>
            )}

            {/* Wallet Payment Box */}
            {paymentGateway === 'wallet' && (
              <div className="p-3.5 bg-amber-950/20 border border-amber-500/30 rounded-xl space-y-2 text-xs">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-amber-300">Prepaid Wallet Instant Checkout</span>
                  <span className="text-white font-mono font-bold">Balance: ₹{user?.walletBalance || 0}</span>
                </div>
                {(!user || user.walletBalance < finalPrice) ? (
                  <p className="text-red-400 text-[11px]">
                    Insufficient balance! You need ₹{finalPrice}. Please switch to Razorpay/PhonePe or recharge your wallet.
                  </p>
                ) : (
                  <p className="text-emerald-400 text-[11px]">
                    ✓ You have sufficient credits. ₹{finalPrice} will be deducted directly with 0 seconds latency!
                  </p>
                )}
              </div>
            )}

            {/* Coupon Code Section */}
            <div className="space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="font-bold text-slate-300 uppercase tracking-wider flex items-center space-x-1">
                  <Tag className="w-3.5 h-3.5 text-amber-400" />
                  <span>Promo Code</span>
                </span>
                <span className="text-[11px] text-slate-400">Available: <strong className="text-amber-400">MASTER20</strong> or <strong className="text-amber-400">WELCOME10</strong></span>
              </div>

              {appliedCoupon ? (
                <div className="flex items-center justify-between p-2.5 bg-emerald-500/10 border border-emerald-500/30 rounded-lg text-xs">
                  <div className="flex items-center space-x-2 text-emerald-300">
                    <Check className="w-4 h-4" />
                    <span>Coupon <strong>{appliedCoupon.code}</strong> applied ({appliedCoupon.discountPercentage}% OFF)</span>
                  </div>
                  <button
                    onClick={removeCoupon}
                    className="text-xs text-red-400 hover:underline font-semibold"
                  >
                    Remove
                  </button>
                </div>
              ) : (
                <form onSubmit={handleApplyCoupon} className="flex items-center space-x-2">
                  <input
                    type="text"
                    value={couponInput}
                    onChange={(e) => setCouponInput(e.target.value.toUpperCase())}
                    placeholder="Enter Coupon Code (e.g. MASTER20)"
                    className="w-full bg-slate-900 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white uppercase focus:outline-none focus:border-blue-500"
                  />
                  <button
                    type="submit"
                    className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-white rounded-lg text-xs font-bold transition-all shrink-0"
                  >
                    Apply
                  </button>
                </form>
              )}
              {couponError && <p className="text-xs text-red-400">{couponError}</p>}
            </div>

            {/* Price Breakdown */}
            <div className="p-3.5 bg-slate-950/80 border border-slate-800 rounded-xl space-y-1.5 text-xs">
              <div className="flex justify-between text-slate-400">
                <span>Product Base Price</span>
                <span>{formatPrice(liveProduct.priceINR, liveProduct.priceUSD)}</span>
              </div>
              {discount > 0 && (
                <div className="flex justify-between text-emerald-400 font-semibold">
                  <span>Coupon Discount</span>
                  <span>- {currency === 'USD' ? `$${discount}` : `₹${discount}`}</span>
                </div>
              )}
              <div className="flex justify-between text-slate-400">
                <span>18% GST (Government Tax)</span>
                <span className="text-emerald-400 font-mono">WAIVED (Promotional 0%)</span>
              </div>
              <div className="pt-2 border-t border-slate-800 flex justify-between items-center text-sm font-extrabold text-white">
                <span>Net Payable Amount</span>
                <span className="text-lg text-cyan-400 font-black">
                  {currency === 'USD' ? `$${finalPrice}` : `₹${finalPrice.toLocaleString('en-IN')}`}
                </span>
              </div>
            </div>

            {/* Processing Steps Overlay / Indicator */}
            {isProcessing && (
              <div className="p-3.5 bg-blue-950/40 border border-blue-500/40 rounded-xl space-y-2 animate-pulse">
                <div className="flex items-center space-x-2 text-xs font-bold text-cyan-300">
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>Processing Automated Order Lifecycle:</span>
                </div>
                <div className="space-y-1 text-[11px] text-slate-300 font-mono pl-6">
                  <div className={processingStep >= 1 ? 'text-emerald-400' : 'text-slate-500'}>
                    {processingStep >= 1 ? '✓' : '○'} 1. Authorizing {paymentGateway.toUpperCase()} payment capture...
                  </div>
                  <div className={processingStep >= 2 ? 'text-emerald-400' : 'text-slate-500'}>
                    {processingStep >= 2 ? '✓' : '○'} 2. Decrementing stock & allocating node in database...
                  </div>
                  <div className={processingStep >= 3 ? 'text-emerald-400' : 'text-slate-500'}>
                    {processingStep >= 3 ? '✓' : '○'} 3. Generating digital license / server credentials...
                  </div>
                </div>
              </div>
            )}

            {/* Pay Button */}
            <button
              id="checkout-confirm-pay-btn"
              disabled={isProcessing || isOutOfStock}
              onClick={handlePay}
              className={`w-full py-3.5 px-6 rounded-xl font-black text-sm text-white shadow-xl flex items-center justify-center space-x-2 transition-all ${
                isOutOfStock
                  ? 'bg-slate-800 cursor-not-allowed opacity-60'
                  : isProcessing
                  ? 'bg-blue-800 cursor-wait opacity-80'
                  : 'bg-gradient-to-r from-blue-600 via-indigo-600 to-cyan-500 hover:from-blue-500 hover:to-cyan-400 shadow-blue-600/30 active:scale-98'
              }`}
            >
              {isOutOfStock ? (
                <span>Out of Stock — Check Back Soon</span>
              ) : isProcessing ? (
                <>
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                  <span>Completing Auto-Provisioning...</span>
                </>
              ) : (
                <>
                  <ShieldCheck className="w-5 h-5" />
                  <span>
                    Pay {currency === 'USD' ? `$${finalPrice}` : `₹${finalPrice.toLocaleString('en-IN')}`} & Instant Deliver
                  </span>
                </>
              )}
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
