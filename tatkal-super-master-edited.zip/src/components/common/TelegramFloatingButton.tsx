import React, { useState } from 'react';
import { Send, MessageCircle, ExternalLink, Sparkles, ShieldCheck } from 'lucide-react';

export const TelegramFloatingButton: React.FC = () => {
  const [isHovered, setIsHovered] = useState(false);
  const telegramUrl = 'https://t.me/tatkalsupermastertatkalsupermaster';

  return (
    <aside aria-label="Support and Help" className="fixed bottom-6 right-6 z-50 flex items-center group">
      {/* Tooltip & Preview Bubble */}
      <div 
        className={`absolute right-full mr-3.5 bottom-1/2 translate-y-1/2 whitespace-nowrap bg-gradient-to-r from-slate-950 via-[#0088cc]/20 to-slate-950 border border-[#229ED9]/40 text-white text-xs font-bold px-3.5 py-2 rounded-xl shadow-2xl backdrop-blur-md transition-all duration-300 pointer-events-none flex items-center space-x-2 ${
          isHovered ? 'opacity-100 translate-x-0' : 'opacity-0 translate-x-2 pointer-events-none sm:group-hover:opacity-100 sm:group-hover:translate-x-0'
        }`}
      >
        <span className="relative flex h-2 w-2">
          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-cyan-400 opacity-75"></span>
          <span className="relative inline-flex rounded-full h-2 w-2 bg-[#229ED9]"></span>
        </span>
        <span className="text-cyan-200">Chat on Telegram</span>
        <span className="text-[10px] text-slate-400 font-mono">@tatkalsupermaster</span>
      </div>

      {/* Floating Action Button */}
      <a
        id="floating-telegram-support-btn"
        href={telegramUrl}
        target="_blank"
        rel="noopener noreferrer"
        onMouseEnter={() => setIsHovered(true)}
        onMouseLeave={() => setIsHovered(false)}
        className="relative flex items-center justify-center w-14 h-14 rounded-full bg-gradient-to-tr from-[#0088cc] via-[#229ED9] to-[#38bdf8] text-white shadow-xl shadow-cyan-950/60 hover:shadow-[#229ED9]/50 hover:scale-105 active:scale-95 transition-all duration-300 focus:outline-none focus:ring-4 focus:ring-[#229ED9]/40"
        title="Chat on Telegram (@tatkalsupermaster)"
        aria-label="Chat on Telegram"
      >
        {/* Animated Pulse Waves */}
        <span className="absolute -inset-1 rounded-full bg-gradient-to-r from-[#0088cc] to-[#38bdf8] opacity-75 blur-sm animate-pulse"></span>
        <span className="absolute -inset-2.5 rounded-full border-2 border-[#229ED9]/40 animate-ping opacity-40"></span>

        {/* Telegram Icon */}
        <div className="relative z-10 flex items-center justify-center">
          <svg 
            className="w-7 h-7 fill-white translate-x-[-1px] translate-y-[1px]" 
            viewBox="0 0 24 24"
          >
            <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm4.64 6.8c-.15 1.58-.8 5.42-1.13 7.19-.14.75-.42 1-.68 1.03-.58.05-1.02-.38-1.58-.75-.88-.58-1.38-.94-2.23-1.5-.99-.65-.35-1.01.22-1.59.15-.15 2.71-2.48 2.76-2.69.01-.03.01-.14-.07-.19-.08-.05-.19-.02-.27 0-.12.03-1.99 1.27-5.62 3.72-.53.36-1.01.54-1.44.53-.47-.01-1.38-.27-2.06-.49-.83-.27-1.49-.42-1.43-.88.03-.24.38-.49 1.03-.75 4.04-1.76 6.74-2.92 8.09-3.49 3.85-1.6 4.65-1.88 5.17-1.89.11 0 .37.03.54.17.14.12.18.28.2.45-.02.07-.02.21-.04.34z"/>
          </svg>
        </div>

        {/* Live Support Online Dot */}
        <span className="absolute top-0 right-0 flex h-3.5 w-3.5 z-20">
          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
          <span className="relative inline-flex rounded-full h-3.5 w-3.5 bg-emerald-500 border-2 border-slate-900"></span>
        </span>
      </a>
    </aside>
  );
};
